/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utility;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import object.ObjFileAss;
import object.ObjFileAssDialogue;
import object.ObjPVideo;

/**
 *
 * @author bnson
 */
public class AssFile {
//    
//    public static boolean process(String pathAssFile, ObjPVideo objPVideo) {
//        System.out.println("== Process Ass File ==");
//        List<String> assFileLines = UtilityFileFolder.readRowTextFileToListString(pathAssFile);
//        ObjFileAss objFileAss = new ObjFileAss(assFileLines);
//        
//        fix(objFileAss);
//        makeTemplateGeneral(objFileAss, objPVideo);
//
//        return true;
//    }
//    
//    private static void fix(ObjFileAss objFileAss) {
//        System.out.println("== Fix Ass File ==");
//        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("H:mm:ss.SS");
//        
//        LocalTime timeEnd;
//        LocalTime timeStart;
//        for (int i = 1; i < objFileAss.getDialogues().size(); i++) {
//            timeEnd = LocalTime.parse(objFileAss.getDialogues().get(i-1).getEnd(), dateTimeFormatter);
//            timeStart = LocalTime.parse(objFileAss.getDialogues().get(i).getStart(), dateTimeFormatter);
//            
//            while (timeStart.isBefore(timeEnd)) {
//                System.out.println("Fix time end: " + timeEnd);
//                timeEnd = timeEnd.minusNanos(10000000);
//                objFileAss.getDialogues().get(i-1).setEnd(timeEnd.format(dateTimeFormatter));
//            }
//
//        }
//        
//        System.out.println("== Fix Ass File End ==");
//    }
//
//    private static void makeTemplateGeneral(ObjFileAss objFileAss, ObjPVideo objPVideo) {
//        List<String> assFileLinesWrite = new ArrayList<>();
//
//        //== PROCESS SETTING
//        for (String assFileLine : objFileAss.getSettings()) {
//            if (assFileLine.contains("PlayResX: ")) {
//                assFileLine = "PlayResX: 1920";
//            }
//
//            if (assFileLine.contains("PlayResY: ")) {
//                assFileLine = "PlayResY: 1080";
//            }
//
//            if (assFileLine.contains("Style: Default")) {
//                assFileLine = "Style: Default," + objPVideo.getFontRow1().getStyle() + "," + objPVideo.getFontRow1().getSize() + ",&H00" + objPVideo.getFontRow1().getColor() + ",&H00FFFFFF,&H000E0E0E,&H00000000,-1,0,0,0,100,100,0,0,1,1,0," + objPVideo.getFontRow1().getAlignment() + ",100,100,25,0";
//            }
//            
//            assFileLinesWrite.add(assFileLine);
//        }
//        
//        //== PROCESS DIALOGUES
//        int index = 0;
//        String assFileLine;
//        for (ObjFileAssDialogue objFileAssDialogue : objFileAss.getDialogues()) {
//            assFileLine = objFileAssDialogue.toString();
//            
//            //== PROCESS TITLE VN
//            if (index == 0 && !objPVideo.getTitleEn().isEmpty() && !objPVideo.getTitleVn().isEmpty()) {
//                String tmpTitle;
//                String tmpTitleNew;
//
//                tmpTitle = assFileLine;
//                String[] tmpArr = tmpTitle.split(",", 10);
//                System.out.println("Title: " + tmpArr[9]);
//                
//                tmpTitle = tmpArr[9];
//                tmpTitleNew = "{\\fs" + objPVideo.getFontTitle().getSize() + "\\c&H" + objPVideo.getFontTitle().getColor() + "&}" + tmpTitle;
//
//                assFileLine = assFileLine.replace(tmpTitle, tmpTitleNew);
//                assFileLine = assFileLine.replace("`", "\\N\\N");
//                assFileLine = assFileLine.replace("★", "\\N\\N");
//                assFileLine = assFileLine.replace("⚊", "\\N\\N");
//                
//            } else {
//                String[] assFileLineArr = assFileLine.split(",",10);
//                String lineText = assFileLineArr[9];
//                String lineTextNew;
//                String row1 = "";
//                String row2 = "";
//                String row3 = "";
//                String row4 = "";
//
//                if (!objPVideo.isHiddenText()) {
//                    String lineTextArr[] = lineText.split("`", -1);
//
//                    row1 = processText(lineTextArr[0]);
//                    if (lineTextArr.length > 1) {
//                        row2 = processText(lineTextArr[1]);
//                    }
//                    if (lineTextArr.length > 2) {
//                        row3 = processText(lineTextArr[2]);
//                    }
//                    if (lineTextArr.length > 3) {
//                        row4 = processText(lineTextArr[3]);
//                    }
//
//                    lineTextNew = row1;
//                    if (!row2.isEmpty()) {
//                        lineTextNew = lineTextNew + "\\N\\N{\\fs" + objPVideo.getFontRow2().getSize() + "\\c&H" + objPVideo.getFontRow2().getColor() + "&}" + row2;
//                    }
//                    if (!row3.isEmpty()) {
//                        lineTextNew = lineTextNew + "{\\fs" + objPVideo.getFontRow2().getSize() + "\\c&H" + objPVideo.getFontRow2().getColor() + "&}" + "\\N\\N" + row3;
//                    }
//                    if (!row4.isEmpty()) {
//                        lineTextNew = lineTextNew + "{\\fs" + objPVideo.getFontRow2().getSize() + "\\c&H" + objPVideo.getFontRow2().getColor() + "&}" + "\\N\\N" + row4;
//                    }
//
//                } else {   
//                    lineTextNew = lineText.replaceAll("\\w", "❒");                    
//                    
//                }
//                assFileLine = assFileLine.replace(lineText, lineTextNew);
//               
//            }
//            
//            assFileLinesWrite.add(assFileLine);
//            index++;
//        }
//
//        String assFileLinesWriteData = String.join("\n", assFileLinesWrite);
//        UtilityFileFolder.writeTextFileWithBufferedWriter(objPVideo.getFileAss(), "UTF-8", assFileLinesWriteData, false);
//        System.out.println("ABCDFDFD");
//    }
//
//    private static String processText(String text) {
//        String rs = text;
//        if (text.contains(":")) {
//            int indexColon = text.indexOf(":");
//            if (indexColon < 12) {
//                rs = "{\\u1\\b1}" + text.substring(0, indexColon + 1) + "{\\u0\\b0}\\N" + text.substring(indexColon + 1);
//            }
//        }
//        return rs;
//    }
}
