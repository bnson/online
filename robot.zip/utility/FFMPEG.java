/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utility;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ASUS
 */
public class FFMPEG {
    
    private final String ffmegPath;
    
    public FFMPEG(String ffmegPath) {
        this.ffmegPath = ffmegPath;
    }
    
    public boolean convertSubSrtToAss(String pathSrt) {
        try {
            //-- ffmpeg -i subtitles.srt subtitles.ass
            String pathAcc = pathSrt.replace(".srt", ".ass");
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathSrt, pathAcc);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }   
    
    public boolean convertSubSrtToAss001(String pathSrt, String pathAss) {
        try {
            //-- ffmpeg -i subtitles.srt subtitles.ass
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathSrt, pathAss);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }        
    
    
    public boolean writeSubToVideo(String pathSub, String pathVideo) {
        try {
            String extension = pathVideo.substring(pathVideo.lastIndexOf("."));
            String pathVideoSub = pathVideo.replace(extension, " Sub" + extension);
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-filter:v", subTitles, pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }  
    
    public boolean writeSubToVideo5(String pathSub, String pathVideo) {
        try {
            String pathVideoSub = pathVideo.replace(" Run Without Subtitle.mp4", ".mp4" );
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-max_muxing_queue_size", "1920", pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }       
    
    public boolean writeSubToVideo2(String pathSub, String pathVideo) {
        try {
            pathVideo = "\"" + pathVideo + "\"";
            String pathVideoSub = pathVideo.replace(".mp4", " Subtitle.mp4" );
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-max_muxing_queue_size", "1920", pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }  
    
    public boolean writeSubToVideo2(String pathSub, String pathVideo, String pathVideoSub) {
        try {
            pathVideo = "\"" + pathVideo + "\"";
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-max_muxing_queue_size", "1920", pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }    

    public boolean writeSubToVideo3(String pathSub, String pathVideo) {
        try {
            String pathVideoSub = pathVideo.replace(" without_sub.mp4", ".mp4" );
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-max_muxing_queue_size", "1920", pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }    

    public boolean writeSubToVideo4(String pathSub, String pathVideo) {
        try {
            String pathVideoSub = pathVideo.replace(".mp4", " Subtitle.mp4" );
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            //ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-max_muxing_queue_size", "1920", pathVideoSub);
            //ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-b:v", "20M", "-c:a", "copy",pathVideoSub);
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-c:v", "libx264", "-crf", "0", "-preset", "veryfast", "-tune", "stillimage", "-c:a", "copy", "-shortest", pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }      
    
    public boolean writeSubToVideo1(String pathSub, String pathVideo) {
        try {
            String extension = pathVideo.substring(pathVideo.lastIndexOf("."));
            String pathVideoSub = pathVideo.replace(" Subtitle" + extension, extension);
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-max_muxing_queue_size", "1920", pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }      
    
    public boolean writeSubToVideo_New_1(String pathSub, String pathVideo) {
        try {
            String extension = pathVideo.substring(pathVideo.lastIndexOf("."));
            String pathVideoSub = pathVideo.replace(extension, " Sub" + extension);
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }     
    
    public boolean writeSubToVideo_Test(String pathSub, String pathVideo) {
        try {
            String extension = pathVideo.substring(pathVideo.lastIndexOf("."));
            String pathVideoSub = pathVideo.replace(extension, " Sub" + extension);
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-max_muxing_queue_size", "1024", pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }      
    
    public boolean mergeMp3AndMp4ToMp4(String pathMp3, String pathMp4) {
        try {
            String pathOutput = pathMp4.replace(".mp4", "_merge_mp3.mp4");
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathMp3, "-i", pathMp4, "-codec", "copy", "-shortest", pathOutput);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;          
    }
    
    public boolean mergeMp3AndMp4ToMp4001(String pathMp3, String pathMp4, String pathVideoCover) {
        try {
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathMp3, "-i", pathVideoCover, "-codec", "copy", "-shortest", pathMp4);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;          
    }    
    
    
    public boolean mergeImageAndMp3ToMp4_Test(String pathImage, String pathMp3) {
        try {
            String pathMp4 = pathMp3.replace(".mp3", ".mp4");
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-r", "1", "-loop", "1", "-i", pathImage, "-i"  ,pathMp3, "-acodec", "copy", "-shortest", pathMp4);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }        
    
    
    public boolean mergeImageAndMp3ToMp4(String pathImage, String pathMp3) {
        try {
            String pathMp4 = pathMp3.replace(".mp3", ".mp4");
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-r", "1", "-loop", "1", "-i", pathImage, "-i"  ,pathMp3, "-acodec", "copy", "-r", "1", "-shortest", "-vf", "scale=1280:720", pathMp4);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }
    
    public boolean mergeImageAndMp3ToMp4_New_3(String pathImage, String pathMp3) {
        try {
            String pathMp4 = pathMp3.replace("Run.mp3", "Run Without Subtitle.mp4");
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-r", "1", "-loop", "1", "-i", pathImage, "-i"  ,pathMp3, "-acodec", "copy", "-r", "1", "-shortest", pathMp4);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }        
    
    public boolean mergeImageAndMp3ToMp4_New_1(String pathImage, String pathMp3) {
        try {
            String pathMp4 = pathMp3.replace(".mp3", ".mp4");
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-r", "1", "-loop", "1", "-i", pathImage, "-i"  ,pathMp3, "-acodec", "copy", "-r", "1", "-shortest", pathMp4);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }    
    
    public boolean mergeImageAndMp3ToMp4_New_2(String pathImage, String pathMp3) {
        try {
            String pathMp4 = pathMp3.replace(".mp3", ".mp4");
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-loop", "1", "-framerate", "1", "-i", pathImage, "-i"  ,pathMp3, "-c:v", "libx264", "-crf", "0", "-preset", "veryfast", "-tune", "stillimage", "-c:a", "copy", "-shortest", pathMp4);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }    
    
    public boolean loopVideo(String loopNumber, String pathVideo) {
        try {
            //-- CMD 001: ffmpeg -stream_loop 4 -i 001.mp4 -c copy -fflags +genpts output.mp4
            String pathVideoLoop = pathVideo.replace(".mp4", "_loop.mp4");
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-stream_loop", loopNumber, "-i", pathVideo, "-c", "copy", "-fflags", "+genpts", pathVideoLoop);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFMPEG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }
    
}
