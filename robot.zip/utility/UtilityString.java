/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utility;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author bnson
 */
public class UtilityString {
    
    
    public static String replaceLineSeparatorToSpace(String str) {
        String line_separator = "[\\n|\\r]";
        return str.trim().replaceAll("\\s+", " ").replaceAll(System.getProperty("line.separator"), " ").replaceAll(line_separator, " ");
    }
    
    public static String replaceLineSeparatorToSpecial(String str) {
        String line_separator = "[\\n|\\r]";
        return str.trim().replaceAll("\\s+", " ").replaceAll(System.getProperty("line.separator"), "#").replaceAll(line_separator, "#");
    }    
    
    public static String trimSpace(String str) {
        String rs = str.trim().replaceAll("[ ]+", " ");
        rs = rs.trim();
        return rs;
    }
    
    public static String removeSpace(String str) {
        return str.replaceAll("[ ]+", "");
    }
    
    public static String removeSpecialChar(String str) {
        String specialChar = "[`\\-=\\[\\];',./~!@#$%^&*()_={}\\\\:\\\"…«»–—”“><?!！„•《〖+]";
        return str.replaceAll(specialChar, " ");
    }
    
    public static Boolean isNumberic(String str) {
        return str.matches("\\d+");
    }   
    
    public static Boolean isAlphabet(String str) {
        return str.matches("\\w+");
    }       
    
    public static String replaceWord(String str, String oldText, String newText) {
        String rs = str;
        String pattern = REGEX_START + Pattern.quote(oldText) + REGEX_END;
        Pattern pFind = Pattern.compile(pattern);
        Matcher mFind;        
        
        mFind = pFind.matcher(rs.toLowerCase());
            if (mFind.find()) {
                String findWord = mFind.group();
                char charFirst = findWord.charAt(0);
                char charEnd = findWord.charAt(findWord.length() - 1);
                System.out.println(charFirst + "-" + findWord + "-" + charEnd);
                if ("\"., ".indexOf(charFirst) != -1) {
                    newText = charFirst + newText;
                }
                if ("\"., ".indexOf(charEnd) != -1) {
                    newText = newText + charEnd;
                }

                rs = rs.replaceAll("(?i)" + pattern,newText);
            }        
        
        return rs;
    }
    
    public static void printList(List<String> list) {
        System.out.println(Arrays.toString(list.toArray()));
    }
    
    public static void printListItem(List<String> list) {
        list.forEach(System.out::println);
    }    
 
    private static final String REGEX_START = "(^|[^aâăẳáảầảấậạẩắẫặẵãàằắbcdđeẹèéẻêễệếềểẽfghiịíĩìỉjklmnoọóòỏơớờợỗôõộổốỡồởpqrstuưụúùứũừửựữủvwxyỵỷỹýỳzAÂĂẲÁẢẦẢẤẬẠẨẮẪẶẴÃÀẰẮBCDĐEẸÈÉẺÊỄỆẾỀỂẼFGHIỊÍĨÌỈJKLMNOỌÓÒỎƠỚỜỢỖÔÕỘỔỐỠỒỞPQRSTUƯỤÚÙỨŨỪỬỰỮỦVWXYỴỶỸÝỲZ])";
    private static final String REGEX_END = "[^aâăẳáảầảấậạẩắẫặẵãàằắbcdđeẹèéẻêễệếềểẽfghiịíĩìỉjklmnoọóòỏơớờợỗôõộổốỡồởpqrstuưụúùứũừửựữủvwxyỵỷỹýỳzAÂĂẲÁẢẦẢẤẬẠẨẮẪẶẴÃÀẰẮBCDĐEẸÈÉẺÊỄỆẾỀỂẼFGHIỊÍĨÌỈJKLMNOỌÓÒỎƠỚỜỢỖÔÕỘỔỐỠỒỞPQRSTUƯỤÚÙỨŨỪỬỰỮỦVWXYỴỶỸÝỲZ]";
        
    
}
