/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utility;

import java.io.IOException;
import java.io.InputStream;

/**
 *
 * @author bnson
 */
public class IDM {

    public IDM() {
    }

    public void download(String folder, String linkDownload, String saveName) {

        String dosCommand = "\"C:\\Program Files (x86)\\Internet Download Manager\\idman.exe\"";
        dosCommand += " /a";
        dosCommand += " /f " + saveName;
        dosCommand += " /p " + "\"" + folder + "\"";
        dosCommand += " /d " + linkDownload;
        dosCommand += " /n";
        dosCommand += " /q";
        //dosCommand += " /h";
        System.out.println("dosCommand: " + dosCommand);
        ExecuteDosCommand(dosCommand);
    }

    private void ExecuteDosCommand(String dosCommand) {
        //System.out.println(dosCommand);     
        try {
            final Process process = Runtime.getRuntime().exec(dosCommand);
            final InputStream in = process.getInputStream();
            int ch;
            while ((ch = in.read()) != -1) {
                System.out.print((char) ch);
            }
        } catch (IOException e) {
            System.out.println(e.toString());
        }
    }

}
