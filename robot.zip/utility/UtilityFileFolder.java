/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utility;

import com.ibm.icu.text.CharsetDetector;
import com.ibm.icu.text.CharsetMatch;
import com.xuggle.xuggler.IContainer;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.io.FileUtils;

/**
 *
 * @author bnson
 */
public class UtilityFileFolder {

    private static final String REGEX_START = "(^|[^aâăẳáảầảấậạẩắẫặẵãàằắbcdđeẹèéẻêễệếềểẽfghiịíĩìỉjklmnoọóòỏơớờợỗôõộổốỡồởpqrstuưụúùứũừửựữủvwxyỵỷỹýỳzAÂĂẲÁẢẦẢẤẬẠẨẮẪẶẴÃÀẰẮBCDĐEẸÈÉẺÊỄỆẾỀỂẼFGHIỊÍĨÌỈJKLMNOỌÓÒỎƠỚỜỢỖÔÕỘỔỐỠỒỞPQRSTUƯỤÚÙỨŨỪỬỰỮỦVWXYỴỶỸÝỲZ])";
    private static final String REGEX_END = "[^aâăẳáảầảấậạẩắẫặẵãàằắbcdđeẹèéẻêễệếềểẽfghiịíĩìỉjklmnoọóòỏơớờợỗôõộổốỡồởpqrstuưụúùứũừửựữủvwxyỵỷỹýỳzAÂĂẲÁẢẦẢẤẬẠẨẮẪẶẴÃÀẰẮBCDĐEẸÈÉẺÊỄỆẾỀỂẼFGHIỊÍĨÌỈJKLMNOỌÓÒỎƠỚỜỢỖÔÕỘỔỐỠỒỞPQRSTUƯỤÚÙỨŨỪỬỰỮỦVWXYỴỶỸÝỲZ]";

    public static List<String> findRowContentText(String text, String pathFile) {
        int from;
        int to;
        int index;

        List<String> listText = new ArrayList();
        List<String> file = readRowTextFileToListString(pathFile);
        Pattern pattern = Pattern.compile(REGEX_START + Pattern.quote(text.toLowerCase()) + REGEX_END);
        Matcher matcher;

        for (String tmp : file) {
            index = -1;
            matcher = pattern.matcher(tmp.toLowerCase());
            if (matcher.find()) {
                //System.out.println("matcher.group()" + matcher.group());
                index = matcher.start();
            }
            if (index != -1) {
                //System.out.println("tmp: " + tmp);
                from = index - 60;
                if (from < 0) {
                    from = 0;
                }
                to = index + 60;
                if (to > tmp.length()) {
                    to = tmp.length();
                }
                listText.add(tmp.substring(from, to));
            }
        }
        return listText;
    }

    public static void copyDirectory(String sourceDirectoryLocation, String destinationDirectoryLocation) {
        try {
            Files.walk(Paths.get(sourceDirectoryLocation))
                    .forEach(source -> {
                        try {
                            Path destination = Paths.get(destinationDirectoryLocation, source.toString()
                                    .substring(sourceDirectoryLocation.length()));

                            Files.copy(source, destination);
                        } catch (IOException ex) {
                            Logger.getLogger(UtilityFileFolder.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void copyDirectory(File sourceDirectory, File destinationDirectory) throws IOException {
        if (!destinationDirectory.exists()) {
            destinationDirectory.mkdir();
        }
        for (String f : sourceDirectory.list()) {
            copyDirectoryCompatibityMode(new File(sourceDirectory, f), new File(destinationDirectory, f));
        }
    }

    public static void copyDirectoryCompatibityMode(File source, File destination) {
        try {
            if (source.isDirectory()) {
                copyDirectory(source, destination);
            } else {
                copyFile(source, destination);
            }
        } catch (IOException ex) {
            Logger.getLogger(UtilityFileFolder.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void copyFile(File sourceFile, File destinationFile) throws IOException {
        try ( InputStream in = new FileInputStream(sourceFile);  OutputStream out = new FileOutputStream(destinationFile)) {
            byte[] buf = new byte[1024];
            int length;
            while ((length = in.read(buf)) > 0) {
                out.write(buf, 0, length);
            }
        }
    }

    public static void copyFile(String sourceFile, String destinationFile) {
        File source = new File(sourceFile);
        File dest = new File(destinationFile);
        try {
            FileUtils.copyFile(source, dest);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static long getMediaDuration(String path) {
        IContainer container = IContainer.make();
        container.open(path, IContainer.Type.READ, null);
        return container.getDuration();
    }

    public static List<String> findContentIn(String pathFile) {
        //String pFind1 = "<|>|》|《|»|«|〖|〗|【|】|〔|〕";
        List<String> rs = new ArrayList();
        List<String> file = readRowTextFileToListString(pathFile);
        Pattern p = Pattern.compile("(\\(([^\\(\\)]+)\\)|\\[([^\\[\\]]+)\\]|[<|>|》|《|»|«|〖|〗|【|】|〔|〕]([^<>》《»«〖〗【】〔〕]+)[<|>|》|《|»|«|〖|〗|【|】|〔|〕])");

        file.stream().map((row) -> p.matcher(row)).forEachOrdered((m) -> {
            while (m.find()) {
                rs.add("" + m.group(1) + "※" + pathFile);
                //rs.add(m.group(1));
                //System.out.println("Find: " + m.group(1));                
            }
        });

        return rs;
    }

    public static List<String> findContentInParentheses(String pathFile) {
        List<String> rs = new ArrayList();
        List<String> file = readRowTextFileToListString(pathFile);
        Pattern p = Pattern.compile("\\(([^\\(\\)]+)\\)");

        file.stream().map((row) -> p.matcher(row)).forEachOrdered((m) -> {
            while (m.find()) {
                rs.add("(" + m.group(1) + ")※" + pathFile);
                //System.out.println("Find: " + m.group(1));                
            }
        });

        return rs;
    }

    public static List<String> findContentInBracket(String pathFile) {
        List<String> rs = new ArrayList();
        List<String> file = readRowTextFileToListString(pathFile);
        Pattern p = Pattern.compile("\\[([^\\[\\]]+)\\]");

        file.stream().map((row) -> p.matcher(row)).forEachOrdered((m) -> {
            while (m.find()) {
                rs.add("[" + m.group(1) + "]※" + pathFile);
                //System.out.println("Find: " + m.group(1));                
            }
        });

        return rs;
    }

    //=======================================================
    // extension = "": get all full path of file in folder.
    // subDirectory = TRUE/FALSE: get/not get full path of file in sub folder.
    //=======================================================
    public static List<String> getListPathFileInFolder(String pathFolder, String extension, boolean subDirectory) {
        List<String> rs = null;
        File folder = new File(pathFolder);

        if (folder.exists() && folder.isDirectory()) {
            rs = new ArrayList<>();
            List<File> files = Arrays.asList(folder.listFiles());

            for (File file : files) {
                //System.out.println("tmp: " + file.getAbsolutePath());
                if (file.isFile()) {
                    if (extension.isEmpty()) {
                        rs.add(file.getAbsolutePath());
                    } else {
                        if (file.getAbsolutePath().toLowerCase().endsWith(extension.toLowerCase())) {
                            rs.add(file.getAbsolutePath());
                        }
                    }
                } else if (file.isDirectory() && subDirectory) {
                    rs.addAll(getListPathFileInFolder(file.getAbsolutePath(), extension, subDirectory));
                }
            }

        }

        Collections.sort(rs, new UtilityWindowsExplorerComparator());
        return rs;
    }

    public static List<String> getListPathFileInFolder(String pathFolder, String extension, String startWith, boolean subDirectory) {
        List<String> rs = null;
        File folder = new File(pathFolder);

        if (folder.exists() && folder.isDirectory()) {
            rs = new ArrayList<>();
            List<File> files = Arrays.asList(folder.listFiles());

            for (File file : files) {
                if (file.isFile()) {
                    if (extension.isEmpty()) {
                        rs.add(file.getAbsolutePath());
                    } else {
                        if (file.getAbsolutePath().toLowerCase().endsWith(extension.toLowerCase())
                                && file.getName().toLowerCase().startsWith(startWith.toLowerCase())) {
                            rs.add(file.getAbsolutePath());
                        }
                    }
                } else if (file.isDirectory() && subDirectory) {
                    rs.addAll(getListPathFileInFolder(file.getAbsolutePath(), extension, startWith, subDirectory));
                }
            }

        }

        Collections.sort(rs, new UtilityWindowsExplorerComparator());
        return rs;
    }

    public static List<String> getListFileNameInFolder(String pathFolder, String extension, boolean subDirectory) {
        List<String> rs = null;
        File folder = new File(pathFolder);

        if (folder.exists() && folder.isDirectory()) {
            rs = new ArrayList<>();
            List<File> files = Arrays.asList(folder.listFiles());

            for (File file : files) {
                if (file.isFile()) {
                    if (extension.isEmpty()) {
                        rs.add(file.getName());
                    } else {
                        if (file.getName().toLowerCase().endsWith(extension.toLowerCase())) {
                            rs.add(file.getName());
                        }
                    }
                } else if (file.isDirectory() && subDirectory) {
                    rs.addAll(getListFileNameInFolder(file.getPath(), extension, subDirectory));
                }
            }

        }

        Collections.sort(rs, new UtilityWindowsExplorerComparator());
        return rs;
    }

    public static boolean isExistsFolder(String pathFolder) {
        File file = new File(pathFolder);
        return file.exists() && file.isDirectory();
    }

    public static List<String> readRowTextFileToListString(String pathFile) {
        List<String> rs = null;
        File file = new File(pathFile);
        if (file.exists() && file.isFile()
                && (file.getAbsolutePath().toLowerCase().endsWith("txt")
                || file.getAbsolutePath().toLowerCase().endsWith("ass"))) {
            rs = new ArrayList<>();
            BufferedReader reader = null;
            String encoding = detectEncoding(file.getAbsolutePath());
            //System.out.println("encoding: " + encoding);

            try {
                if (!encoding.isEmpty()) {
                    reader = new BufferedReader(new InputStreamReader(new FileInputStream(pathFile), "UTF-8"));
                } else {
                    reader = new BufferedReader(new FileReader(pathFile));
                }

                for (String line = reader.readLine(); line != null; line = reader.readLine()) {
                    //line = line.toLowerCase();
                    rs.add(line);
                }
            } catch (FileNotFoundException ex) {
                Logger.getLogger(UtilityFileFolder.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(UtilityFileFolder.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException ex) {
                    Logger.getLogger(UtilityFileFolder.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

        return rs;
    }

    public static List<String> convertTextFileToListWord(String pathFile) {
        List<String> rs = new ArrayList<>();

        if (isExistsFile(pathFile)) {
            String tmp = UtilityString.trimSpace(UtilityString.replaceLineSeparatorToSpace(readTextFileToString_ReadAllBytes(pathFile)));
            tmp = UtilityString.trimSpace(UtilityString.removeSpecialChar(tmp));
            rs = parseList(tmp, " ");
        }

        return rs;
    }

    public static List<String> parseList(String str, String separator) {
        List<String> rs = new ArrayList<>(Arrays.asList(str.split(separator)));
        return rs;
    }

    public static String detectEncoding(String pathFile) {
        String encoding = null;
        File file = new File(pathFile);

        if (file.exists() && file.isFile()) {
            InputStream in = null;
            try {
                in = new BufferedInputStream(new FileInputStream(pathFile));
                CharsetDetector detector = new CharsetDetector();
                detector.setText(in);

                CharsetMatch charsetMatch = detector.detect();

                if (charsetMatch != null) {
                    encoding = charsetMatch.getName();
                }
            } catch (FileNotFoundException ex) {
                Logger.getLogger(UtilityFileFolder.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(UtilityFileFolder.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    if (in != null) {
                        in.close();
                    }
                } catch (IOException ex) {
                    Logger.getLogger(UtilityFileFolder.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }
        return encoding;
    }

    public static void writeTextFileWithApache(String pathFile, String encoding, String content, boolean override) {
        try {
            File file = new File(pathFile);
            FileUtils.writeStringToFile(file, content, encoding, override);
        } catch (IOException ex) {
            ex.printStackTrace(System.out);
        }
    }

    public static void writeTextFileWithBufferedWriter(String pathFile, String encoding, String content, boolean append) {
        BufferedWriter bw = null;

        try {
            if (pathFile.toLowerCase().endsWith(".txt")
                    || pathFile.toLowerCase().endsWith(".ass")
                    || pathFile.toLowerCase().endsWith(".json")
                    || pathFile.toLowerCase().endsWith(".html")) {
                File f = new File(pathFile);
                Boolean fileExists = isExistsFile(pathFile);

                if (fileExists) {
                    encoding = detectEncoding(pathFile);
                    System.out.println("Encoding: " + encoding);
                } else {
                    f.createNewFile();
                    System.out.println("MESSAGE[.] File is created.");
                }

                if (encoding.toLowerCase().contains("utf-8-bom")) {
                    encoding = "UTF-8";
                    byte[] BOM = {(byte) 0xEF, (byte) 0xBB, (byte) 0xBF};
                    content = new String(BOM) + content;
                }

                bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f, append), encoding));
                bw.write(content);
                bw.newLine();

            } else {
                System.out.println("WARNING[.] File isn't text file.");
            }

        } catch (UnsupportedEncodingException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (bw != null) {
                    bw.flush();
                    bw.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(UtilityFileFolder.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

    public static Boolean isExistsFile(String pathFile) {
        File f = new File(pathFile);
        return (f.exists() && f.isFile());
    }

    public static String readTextFileToString_ReadAllBytes(String path) {
        String content = "";

        if (isExistsFile(path)) {
            String encoding = detectEncoding(path);
            byte[] contentByte;

            try {
                contentByte = Files.readAllBytes(Paths.get(path));

                if (!encoding.isEmpty()) {
                    content = new String(contentByte, encoding);
                } else {
                    content = new String(contentByte);
                }

            } catch (IOException ex) {
                Logger.getLogger(UtilityFileFolder.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return content;

    }

    public static Boolean createDirectory(String folderPath) {
        Boolean rs = true;
        Path path = Paths.get(folderPath);
        //if directory exists?
        if (!Files.exists(path)) {
            try {
                Files.createDirectories(path);
            } catch (IOException e) {
                //fail to create directory
                rs = false;
            }
        }
        return rs;
    }

    public static boolean moveFile(String sourcePath, String targetPath) {
        boolean fileMoved = true;
        try {
            Files.move(Paths.get(sourcePath), Paths.get(targetPath), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            fileMoved = false;
        }
        return fileMoved;
    }

}
