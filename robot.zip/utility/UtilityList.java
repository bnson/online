/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utility;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author bnson
 */
public class UtilityList {
    
    public static void print(java.util.List<String> list) {
        list.forEach((_item) -> {
            //System.out.println("list: " + _item);
            System.out.println(_item);
        });        
    }      
    
    public static List<String> parseList(String str, String separator) {
        List<String> rs = new ArrayList<>(Arrays.asList(str.split(separator)));
        return rs;
    }
    
    public static List<String> removeDuplication(List<String> list) {
            //Set<String> hs = new HashSet<>();
            Set<String> hs = new LinkedHashSet<>(list);
            hs.addAll(list);
            list.clear();
            list.addAll(hs);  
            
            return list;
    }
    
    public static void trimSpace(List<String> listString) {
        ListIterator<String> it = listString.listIterator();
        while (it.hasNext()) {
            it.set(UtilityString.trimSpace(it.next()));
        }

    }    
    
    public static void replaceAll(List<String> listString, String patternString, String newText) {
        ListIterator<String> it = listString.listIterator();
        while (it.hasNext()) {
            it.set(it.next().replaceAll(patternString,newText));
        }
    }     
    
    public static List<String> findWordInRow(List<String> listString, String findText) {
        List<String> listText =  new ArrayList();
        int from = 0;
        int to = 0;
        int index;
        
        for (String tmp : listString) {
            
            index = tmp.toLowerCase().indexOf(findText.toLowerCase());
            if (index != -1) {
                //System.out.println("tmp: " + tmp);
                from = index-60;
                if (from < 0) {
                    from = 0;
                }
                
                to = index+60;
                if (to > tmp.length()) {
                    to = tmp.length();
                }
                listText.add(tmp.substring(from, to));
            }
            
            
        }      
        
        return listText;
    }
    
    public static List<String> findText(List<String> listString, String patternString) {
        Pattern p = Pattern.compile(patternString); 
        List<String> listText =  new ArrayList();
        
        for (String tmp : listString) {
            Matcher m = p.matcher(tmp);
            while (m.find()) {
                listText.add("(" + m.group(1) + ")");
                //System.out.println("Find: " + m.group(1));
            }
        }      
        
        return listText;
    }
    
    public static void replace(List<String> listString, String oldText, String newText) {
        
        ListIterator<String> it = listString.listIterator();
        while (it.hasNext()) {
            it.set(it.next().replace(oldText,newText));
        }

    }     
    
    public static void removeNumberic(List<String> listString) {
        for (Iterator<String> iter = listString.listIterator(); iter.hasNext();) {
            String tmp = iter.next();
            if (UtilityString.isNumberic(tmp)) {
                iter.remove();
            }
        }
       
    }    

    public static java.util.Comparator<java.io.File> COMPARATOR_SORT_FILE_NATURAL = new java.util.Comparator<java.io.File>() {
        @Override
        @SuppressWarnings("empty-statement")
        public int compare(java.io.File o1, java.io.File o2) {;
            return COMPARATOR_SORT_STRING_NATURAL.compare(o1.getName(), o2.getName());
        }
        
        private final java.util.Comparator<String> COMPARATOR_SORT_STRING_NATURAL = new stringComparator_WindowsExplorer();
    };
    
    public static java.util.Comparator<String> COMPARATOR_SORT_STRING_NATURAL = new stringComparator_WindowsExplorer();
    public static java.util.Comparator<String> COMPARATOR_SORT_STRING_LENGTH = new stringComparator_Length();
    
    
            


    
}
