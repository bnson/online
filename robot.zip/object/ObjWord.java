/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author bnson
 */
public class ObjWord implements Cloneable {

    String en;
    List<String> vn;
    List<String> classes;
    List<String> pronounceUs;
    List<String> pronounceUk;

    public String getEn() {
        return en;
    }

    public void setEn(String en) {
        this.en = en;
    }

    public List<String> getVn() {
        if (vn == null) {
            vn = new ArrayList<>();
        }
        return vn;
    }
    
    public void setVn(String vn) {
        if (this.vn == null) {
            this.vn = new ArrayList<>();
        }
        
        if (!vn.isEmpty()) {
            this.vn.addAll(Arrays.asList(vn.split("↨")));
        }
        
    }      

    public List<String> getClasses() {
        if (classes == null) {
            classes = new ArrayList<>();
        }        
        return classes;
    }
    
    public void setClasses(String classes) {
        if (this.classes == null) {
            this.classes = new ArrayList<>();
        }
        
        if (!classes.isEmpty()) {
            this.classes.addAll(Arrays.asList(classes.split("↨")));
        }
        
    }

    public List<String> getPronounceUs() {
        if (pronounceUs == null) {
            pronounceUs = new ArrayList<>();
        }        
        return pronounceUs;
    }
    
    public void setPronounceUs(String pronounceUs) {
        if (this.pronounceUs == null) {
            this.pronounceUs = new ArrayList<>();
        }
        
        if (!pronounceUs.isEmpty()) {
            this.pronounceUs.addAll(Arrays.asList(pronounceUs.split("↨")));
        }
        
    }    

    public List<String> getPronounceUk() {
        if (pronounceUk == null) {
            pronounceUk = new ArrayList<>();
        }        
        return pronounceUk;
    }
    
    public void setPronounceUk(String pronounceUk) {
        if (this.pronounceUk == null) {
            this.pronounceUk = new ArrayList<>();
        }
        
        if (!pronounceUk.isEmpty()) {
            this.pronounceUk.addAll(Arrays.asList(pronounceUk.split("↨")));
        }
        
    }     
    
    public String getDataForWebContentRaw() {
        String rs = en;
        
        if (this.vn != null) {
            rs += "↨" + String.join(",", vn);
        }
        
        if (this.pronounceUk != null) {
            rs += "↨" + String.join(",", pronounceUk);
        }        
                
        return rs;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone(); //To change body of generated methods, choose Tools | Templates.
    }

}
