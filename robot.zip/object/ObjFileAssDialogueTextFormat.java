/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

/**
 *
 * @author bnson
 */
public class ObjFileAssDialogueTextFormat {

    private String fontname;
    private String fontsize;
    private String primaryColour;
    private String secondaryColour;
    private String outlineColour;
    private String backColour;
    private String bold;
    private String italic;
    private String underline;
    private String strikeOut;

    public ObjFileAssDialogueTextFormat() {
        fontname = "";
        fontsize = "";
        primaryColour = "";
        secondaryColour = "";
        outlineColour = "";
        backColour = "";
        bold = "";
        italic = "";
        underline = "";
        strikeOut = "";
    }

    public String getFontname() {
        return fontname;
    }

    public void setFontname(String fontname) {
        if (!fontname.equalsIgnoreCase("default")) {
            this.fontname = "\\fn" + fontname;
        }
    }

    public String getFontsize() {
        return fontsize;
    }

    public void setFontsize(String fontsize) {
        if (!fontsize.equalsIgnoreCase("0")) {
            this.fontsize = "\\fs" + fontsize;
        }

    }

    public String getPrimaryColour() {
        return primaryColour;
    }

    public void setPrimaryColour(String primaryColour) {
        if (!primaryColour.equalsIgnoreCase("default")) {
            this.primaryColour = "\\c&H" + primaryColour + "&";
        }
    }

    public String getSecondaryColour() {
        return secondaryColour;
    }

    public void setSecondaryColour(String secondaryColour) {
        if (!secondaryColour.equalsIgnoreCase("default")) {
            this.secondaryColour = "\\2c&H" + secondaryColour + "&";
        }
    }

    public String getOutlineColour() {
        return outlineColour;
    }

    public void setOutlineColour(String outlineColour) {
        if (!outlineColour.equalsIgnoreCase("default")) {
            this.outlineColour = outlineColour;
        }
    }

    public String getBackColour() {
        return backColour;
    }

    public void setBackColour(String backColour) {
        if (!backColour.equalsIgnoreCase("default")) {
            this.backColour = backColour;
        }
    }

    public String getBold() {
        return bold;
    }

    public void setBold(String bold) {
        if (!bold.equalsIgnoreCase("default")) {
            this.bold = bold;
        }

    }

    public String getItalic() {
        return italic;
    }

    public void setItalic(String italic) {
        if (!italic.equalsIgnoreCase("default")) {
            this.italic = italic;
        }
    }

    public String getUnderline() {
        return underline;
    }

    public void setUnderline(String underline) {
        if (!underline.equalsIgnoreCase("default")) {
            this.underline = underline;
        }
    }

    public String getStrikeOut() {
        return strikeOut;
    }

    public void setStrikeOut(String strikeOut) {
        if (!strikeOut.equalsIgnoreCase("default")) {
            this.strikeOut = strikeOut;
        }
    }

    @Override
    public String toString() {
        String rs = fontname + fontsize + primaryColour;
        if (!rs.isEmpty()) {
            rs = "{" + rs + "}";
        }
        return rs;
    }
    
    

}
