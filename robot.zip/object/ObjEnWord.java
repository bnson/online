/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author bnson
 */
public class ObjEnWord {
    
    private final String word;
    private final String country;
    private List<ObjEnWordClases> classess;

    public ObjEnWord(String word , String country) {
        this.word = word;
        this.country = country;
    }

    public String getWord() {
        return word;
    }

    public String getCountry() {
        return country;
    }

    public List<ObjEnWordClases> getClassess() {
        if (classess == null) {
            classess = new ArrayList<>();
        }
        return classess;
    }
    
    

}
