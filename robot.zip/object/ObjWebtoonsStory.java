/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author bnson
 */
public class ObjWebtoonsStory {

    String name;
    String link;
    List<String> linkPages;
    
    List<ObjWebtoonsEpisode> episodes;

    public List<String> getLinkPages() {
        if (linkPages == null) {
            linkPages = new ArrayList<>();
        }
        return linkPages;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public List<ObjWebtoonsEpisode> getEpisodes() {
        if (episodes == null) {
            episodes = new ArrayList<>();
        }
        return episodes;
    }

}
