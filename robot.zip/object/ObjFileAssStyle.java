/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

/**
 *
 * @author bnson
 */
public class ObjFileAssStyle {

    private String header;
    private String format;
    private String style;
    
    private String name;
    private String vFontname;
    private String vFontsize;
    private String vPrimaryColour;
    private String vSecondaryColour;
    private String vOutlineColour;
    private String vBackColour;
    private String vBold;
    private String vItalic;
    private String vUnderline;
    private String vStrikeOut;
    private String vScaleX;
    private String vScaleY;
    private String vSpacing;
    private String vAngle;
    private String vBorderStyle;
    private String vOutline;
    private String vShadow;
    private String vAlignment;
    private String vMarginL;
    private String vMarginR;
    private String vMarginV;
    private String vEncoding;

    public ObjFileAssStyle(String lineStyle) {
        this.header = "[V4+ Styles]";
        this.format = "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding";
        
        this.setDefault();

        String[] arrLineStyle = lineStyle.replaceFirst("Style: ", "").split(",");
        if (arrLineStyle.length == 23) {
            this.name = arrLineStyle[0];
            this.vFontname = arrLineStyle[1];
            this.vFontsize = arrLineStyle[2];
            this.vPrimaryColour = arrLineStyle[3];
            this.vSecondaryColour = arrLineStyle[4];
            this.vOutlineColour = arrLineStyle[5];
            this.vBackColour = arrLineStyle[6];
            this.vBold = arrLineStyle[7];
            this.vItalic = arrLineStyle[8];
            this.vUnderline = arrLineStyle[9];
            this.vStrikeOut = arrLineStyle[10];
            this.vScaleX = arrLineStyle[11];
            this.vScaleY = arrLineStyle[12];
            this.vSpacing = arrLineStyle[13];
            this.vAngle = arrLineStyle[14];
            this.vBorderStyle = arrLineStyle[15];
            this.vOutline = arrLineStyle[16];
            this.vShadow = arrLineStyle[17];
            this.vAlignment = arrLineStyle[18];
            this.vMarginL = arrLineStyle[19];
            this.vMarginR = arrLineStyle[20];
            this.vMarginV = arrLineStyle[21];
            this.vEncoding = arrLineStyle[22];
        }
        
    }
    
    private void setDefault() {
        name = "Default";
        vFontname = "Arial";
        vFontsize = "80";
        vPrimaryColour = "&H00FFFFFF";
        vSecondaryColour = "&H00FFFFFF";
        vOutlineColour = "&H000E0E0E";
        vBackColour = "&H00000000";
        vBold = "-1";
        vItalic = "0";
        vUnderline = "0";
        vStrikeOut = "0";
        vScaleX = "100";
        vScaleY = "100";
        vSpacing = "0";
        vAngle = "0";
        vBorderStyle = "1";
        vOutline = "1";
        vShadow = "0";
        vAlignment = "5";
        vMarginL = "100";
        vMarginR = "100";
        vMarginV = "25";
        vEncoding = "0";        
    }

    @Override
    public String toString() {
        style = "Style: " + name + "," + vFontname + "," + vFontsize + "," + vPrimaryColour + "," + vSecondaryColour + "," + vOutlineColour + "," + vBackColour + "," + vBold + "," + vItalic + "," + vUnderline + "," + vStrikeOut + "," + vScaleX + "," + vScaleY + "," + vSpacing + "," + vAngle + "," + vBorderStyle + "," + vOutline + "," + vShadow + "," + vAlignment + "," + vMarginL + "," + vMarginR + "," + vMarginV + "," + vEncoding;
        String rs = header + "\n" + format + "\n" + style;
        return rs;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getvFontname() {
        return vFontname;
    }

    public void setvFontname(String vFontname) {
        this.vFontname = vFontname;
    }

    public String getvFontsize() {
        return vFontsize;
    }

    public void setvFontsize(String vFontsize) {
        this.vFontsize = vFontsize;
    }

    public String getvPrimaryColour() {
        return vPrimaryColour;
    }

    public void setvPrimaryColour(String vPrimaryColour) {
        this.vPrimaryColour = vPrimaryColour;
    }

    public String getvSecondaryColour() {
        return vSecondaryColour;
    }

    public void setvSecondaryColour(String vSecondaryColour) {
        this.vSecondaryColour = vSecondaryColour;
    }

    public String getvOutlineColour() {
        return vOutlineColour;
    }

    public void setvOutlineColour(String vOutlineColour) {
        this.vOutlineColour = vOutlineColour;
    }

    public String getvBackColour() {
        return vBackColour;
    }

    public void setvBackColour(String vBackColour) {
        this.vBackColour = vBackColour;
    }

    public String getvBold() {
        return vBold;
    }

    public void setvBold(String vBold) {
        this.vBold = vBold;
    }

    public String getvItalic() {
        return vItalic;
    }

    public void setvItalic(String vItalic) {
        this.vItalic = vItalic;
    }

    public String getvUnderline() {
        return vUnderline;
    }

    public void setvUnderline(String vUnderline) {
        this.vUnderline = vUnderline;
    }

    public String getvStrikeOut() {
        return vStrikeOut;
    }

    public void setvStrikeOut(String vStrikeOut) {
        this.vStrikeOut = vStrikeOut;
    }

    public String getvScaleX() {
        return vScaleX;
    }

    public void setvScaleX(String vScaleX) {
        this.vScaleX = vScaleX;
    }

    public String getvScaleY() {
        return vScaleY;
    }

    public void setvScaleY(String vScaleY) {
        this.vScaleY = vScaleY;
    }

    public String getvSpacing() {
        return vSpacing;
    }

    public void setvSpacing(String vSpacing) {
        this.vSpacing = vSpacing;
    }

    public String getvAngle() {
        return vAngle;
    }

    public void setvAngle(String vAngle) {
        this.vAngle = vAngle;
    }

    public String getvBorderStyle() {
        return vBorderStyle;
    }

    public void setvBorderStyle(String vBorderStyle) {
        this.vBorderStyle = vBorderStyle;
    }

    public String getvOutline() {
        return vOutline;
    }

    public void setvOutline(String vOutline) {
        this.vOutline = vOutline;
    }

    public String getvShadow() {
        return vShadow;
    }

    public void setvShadow(String vShadow) {
        this.vShadow = vShadow;
    }

    public String getvAlignment() {
        return vAlignment;
    }

    public void setvAlignment(String vAlignment) {
        this.vAlignment = vAlignment;
    }

    public String getvMarginL() {
        return vMarginL;
    }

    public void setvMarginL(String vMarginL) {
        this.vMarginL = vMarginL;
    }

    public String getvMarginR() {
        return vMarginR;
    }

    public void setvMarginR(String vMarginR) {
        this.vMarginR = vMarginR;
    }

    public String getvMarginV() {
        return vMarginV;
    }

    public void setvMarginV(String vMarginV) {
        this.vMarginV = vMarginV;
    }

    public String getvEncoding() {
        return vEncoding;
    }

    public void setvEncoding(String vEncoding) {
        this.vEncoding = vEncoding;
    }

}
