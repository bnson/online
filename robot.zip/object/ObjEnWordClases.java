/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author bnson
 */
public class ObjEnWordClases {
    
    private final String classes;
    private List<String> pronounces;
    private List<ObjEnWordClasesScence> scences;

    public ObjEnWordClases(String classes) {
        this.classes = classes;
    }

    public String getClasses() {
        return classes;
    }

    public List<String> getPronounces() {
        if (pronounces == null) {
            pronounces = new ArrayList<>();
        }
        return pronounces;
    }

    public List<ObjEnWordClasesScence> getScences() {
        if (scences == null) {
            scences = new ArrayList<>();
        }        
        return scences;
    }
    
    
    
}
