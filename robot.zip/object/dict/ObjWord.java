/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object.dict;

/**
 *
 * @author bnson
 */
public class ObjWord {
    
    private String en;
    private String enClass;
    private String vn;
    private int frequency;

    public ObjWord() {
        
    }

    public int getFrequency() {
        return frequency;
    }

    public void setFrequency(int frequency) {
        this.frequency = frequency;
    }

    public String getEn() {
        return en;
    }

    public void setEn(String en) {
        this.en = en;
    }

    public String getEnClass() {
        return enClass;
    }

    public void setEnClass(String enClass) {
        this.enClass = enClass;
    }

    public String getVn() {
        return vn;
    }

    public void setVn(String vn) {
        this.vn = vn;
    }
    
    
    
}
