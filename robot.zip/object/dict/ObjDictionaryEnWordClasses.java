/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object.dict;

/**
 *
 * @author bnson
 */
public class ObjDictionaryEnWordClasses {
    private int dictionaryEnWordId;
    private String _classes;

    public ObjDictionaryEnWordClasses(int dictionaryEnWordId, String _classes) {
        this.dictionaryEnWordId = dictionaryEnWordId;
        this._classes = _classes;
    }

    public int getDictionaryEnWordId() {
        return dictionaryEnWordId;
    }

    public void setDictionaryEnWordId(int dictionaryEnWordId) {
        this.dictionaryEnWordId = dictionaryEnWordId;
    }

    public String getClasses() {
        return _classes;
    }

    public void setClasses(String _classes) {
        this._classes = _classes;
    }
    
    
    
}
