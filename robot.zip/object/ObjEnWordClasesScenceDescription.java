/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author bnson
 */
public class ObjEnWordClasesScenceDescription {

    private final String description;
    private List<String> examples;

    public ObjEnWordClasesScenceDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public List<String> getExamples() {
        if (examples == null) {
            examples = new ArrayList<>();
        }
        return examples;
    }

}
