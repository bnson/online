/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

import java.util.ArrayList;
import java.util.List;
import utility.UtilityFileFolder;
import com.xuggle.xuggler.IContainer;

/**
 *
 * @author bnson
 */
public class ObjPVideo {

    private String name;
    private final String type;

    private int showTitle;
    
    private String titleVn;
    private String titleVnPrefix;
    private String titleVnEndfix;

    private String titleEn;
    private String titleEnPrefix;
    private String titleEnEndfix;

    private String durationOfFileMp4Subtitle;

    private final String folderInput;
    private final String folderOutput;

    private final String fileTxtRoot;
    private final String fileTxtAudio;

    private final String pathFileMp3;
    private final String pathFileSrt;
    private final String pathFileAss;
    private final String pathFileMp4;
    private final String pathFileMp4Subtitle;

    private String fileCover;
    private boolean hiddenText;
    private List<String> content;
    private ObjFileAss objFileAss;
 

    public ObjPVideo(String type, String folderInput) {
        this.type = type;

        this.showTitle = 0;
        this.titleEn = "";
        this.titleEnPrefix = "";
        this.titleEnEndfix = "";

        this.titleVn = "";
        this.titleVnPrefix = "";
        this.titleVnEndfix = "";

        this.durationOfFileMp4Subtitle = "00:00:00";

        if (folderInput.endsWith("\\")) {
            this.folderInput = folderInput;
        } else {
            this.folderInput = folderInput + "\\";
        }
        this.folderOutput = this.folderInput + this.type + "\\";

        this.content = new ArrayList<>();
        this.content.addAll(content);

        this.fileTxtRoot = this.folderOutput + this.type + "_root.txt";
        this.fileTxtAudio = this.folderOutput + this.type + "_audio.txt";

        this.pathFileMp3 = this.folderOutput + this.type + ".mp3";
        this.pathFileSrt = this.folderOutput + this.type + ".srt";
        this.pathFileAss = this.folderOutput + this.type + ".ass";
        this.pathFileMp4 = this.folderOutput + this.type + ".mp4";
        this.pathFileMp4Subtitle = this.folderOutput + this.type + "_sub.mp4";

        this.fileCover = "";

        this.hiddenText = false;
       
    }

    public ObjFileAss getObjFileAss() {
        if (objFileAss == null) {
            objFileAss = new ObjFileAss(this.pathFileAss);
        }
        return objFileAss;
    }

    public boolean isHiddenText() {
        return hiddenText;
    }

    public void setHiddenText(boolean hiddenText) {
        this.hiddenText = hiddenText;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public String getTitleVn() {
        return titleVn;
    }

    public String getTitleEn() {
        return titleEn;
    }

    public String getFolderInput() {
        return folderInput;
    }

    public String getFolderOutput() {
        return folderOutput;
    }

    public List<String> getContent() {
        if (content == null) {
            content = new ArrayList<>();
        }
        return content;
    }

    public String getFileTxtRoot() {
        return fileTxtRoot;
    }

    public String getFileTxtAudio() {
        return fileTxtAudio;
    }

    public String getFileCover() {
        fileCover = folderInput + "cover.mp4";
        if (!UtilityFileFolder.isExistsFile(fileCover)) {
            fileCover = folderInput + "cover.png";
        }
        return fileCover;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setTitleVn(String titleVn) {
        this.titleVn = titleVnPrefix + titleVn + titleVnEndfix;
    }

    public void setTitleEn(String titleEn) {
        this.titleEn = titleEnPrefix + titleEn + titleEnEndfix;
    }

    public void setFileCover(String fileCover) {
        this.fileCover = fileCover;
    }

    public String getDurationOfFileMp4Subtitle() {
        if (durationOfFileMp4Subtitle.equalsIgnoreCase("00:00:00")) {
            if (UtilityFileFolder.isExistsFile(this.pathFileMp4Subtitle)) {
                IContainer container = IContainer.make();
                container.open(this.pathFileMp4Subtitle, IContainer.Type.READ, null);
                long duration = container.getDuration();

                long hours = (duration / 1000 / 1000) / 60 / 60;
                long minutes = (duration / 1000 / 1000) / 60;
                long seconds = (duration / 1000 / 1000) % 60;

                durationOfFileMp4Subtitle = String.format("%02d:%02d:%02d", hours, minutes, seconds);
                System.out.println("Duration (ms): " + duration);
                container.close();
            }
        }

        return durationOfFileMp4Subtitle;
    }

    public long getDurationMilliSecondsOfFileMp4Subtitle() {
        long duration = 0;
        if (durationOfFileMp4Subtitle.equalsIgnoreCase("00:00:00")) {
            if (UtilityFileFolder.isExistsFile(this.pathFileMp4Subtitle)) {
                IContainer container = IContainer.make();
                container.open(this.pathFileMp4Subtitle, IContainer.Type.READ, null);
                duration = container.getDuration();
                container.close();
            }
        }

        return duration;
    }

    public void setTitleVnPrefix(String titleVnPrefix) {
        this.titleVnPrefix = titleVnPrefix;
    }

    public void setTitleVnEndfix(String titleVnEndfix) {
        this.titleVnEndfix = titleVnEndfix;
    }

    public void setTitleEnPrefix(String titleEnPrefix) {
        this.titleEnPrefix = titleEnPrefix;
    }

    public void setTitleEnEndfix(String titleEnEndfix) {
        this.titleEnEndfix = titleEnEndfix;
    }

    public String getPathFileMp3() {
        return pathFileMp3;
    }

    public String getPathFileSrt() {
        return pathFileSrt;
    }

    public String getPathFileAss() {
        return pathFileAss;
    }

    public String getPathFileMp4() {
        return pathFileMp4;
    }

    public String getPathFileMp4Subtitle() {
        return pathFileMp4Subtitle;
    }

    public int getShowTitle() {
        return showTitle;
    }

    
    public void setShowTitle(int option) {
        switch (option) {
            case 0:
                //-- Show English title.
                this.showTitle = 0;
                break;
            case 1:
                //-- Show Vietnamese title.
                this.showTitle = 1;
                break;
            default:
                //-- Show both
                this.showTitle = 2;
        }
        
    }
    

}
