/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

import com.ibm.icu.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 *
 * @author bnson
 */
public class ObjVideoHanimeTv {

    private String name;
    private String brand;
    private Date releaseDate;
    private List<String> alternateNames;
    private List<String> tabs;
    private String description;
    private List<String> imageThumbs;
    private List<String> mp4Links;

    public ObjVideoHanimeTv() {
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public List<String> getAlternateNames() {
        if (alternateNames == null) {
            alternateNames = new ArrayList<>();
        }
        return alternateNames;
    }

    public void setAlternateNames(List<String> alternateNames) {
        this.alternateNames = alternateNames;
    }

    public List<String> getTabs() {
        if (tabs == null) {
            tabs = new ArrayList<>();
        }
        return tabs;
    }

    public void setTabs(List<String> tabs) {
        this.tabs = tabs;
    }
    
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<String> getImageThumbs() {
        if (imageThumbs == null) {
            imageThumbs = new ArrayList<>();
        }
        return imageThumbs;
    }

    public void setImageThumbs(List<String> imageThumbs) {
        this.imageThumbs = imageThumbs;
    }

    public List<String> getMp4Links() {
        if (mp4Links == null) {
            mp4Links = new ArrayList<>();
        }
        return mp4Links;
    }

    public void setMp4Links(List<String> mp4Links) {
        this.mp4Links = mp4Links;
    }
    
    

    @Override
    public String toString() {
        //String patternDate = "MMMM dd, yyyy";
        String patternDate = "yyyy-MM-dd";
        SimpleDateFormat simpleDateFormat =new SimpleDateFormat(patternDate, new Locale("en", "EN"));
        String strReleaseDate = "";
        if (releaseDate != null) {
            strReleaseDate = simpleDateFormat.format(releaseDate);
        }
        
        String strAlternateNames = "";
        if (alternateNames != null) {
            strAlternateNames = Arrays.toString(alternateNames.toArray());
        }
        
        String strTabs = "";
        if (tabs != null) {
            strTabs = Arrays.toString(tabs.toArray());
        }        
        
        if (description == null) {
            description = "";
        }
        
        return "ObjVideo{" 
                + "name=" + name 
                + ", brand=" + brand 
                + ", releaseDate=" + strReleaseDate 
                + ", alternateName=" + strAlternateNames 
                + ", tags=" + strTabs 
                + ", description=" + description + '}';
    }

}
