/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

/**
 *
 * @author bnson
 */
public class ObjWebtoonsComment {

    String ticket;
    String objectId;
    String categoryId;
    String templateId;
    String commentNo;
    String parentCommentNo;
    String replyLevel;
    int replyCount;
    String replyAllCount;
    String replyPreviewNo;
    String replyList;
    String imageCount;
    String imageList;
    String imagePathList;
    String imageWidthList;
    String imageHeightList;
    String commentType;
    String stickerId;
    String sticker;
    int sortValue;
    String contents;
    String userIdNo;
    String exposedUserIp;
    String lang;
    String country;
    String idType;
    String idProvider;
    String userName;
    String userProfileImage;
    String profileType;
    String modTime;
    String modTimeGmt;
    String regTime;
    String regTimeGmt;
    String sympathyCount;
    String antipathyCount;
    String userBlind;
    String hideReplyButton;
    String status;
    String mine;
    String best;
    String mentions;
    String toUser;
    String userStatus;
    String categoryImage;
    String open;
    String levelCode;
    String grades;
    String sympathy;
    String antipathy;
    String snsList;
    String metaInfo;
    String extension;
    String audioInfoList;
    String translation;
    String report;
    String middleBlindReport;
    String spamInfo;
    String userHomepageUrl;
    String defamation;
    String hiddenByCleanbot;
    String evalScore;
    String userBlocked;
    String visible;
    String idNo;
    String manager;
    String deleted;
    String blind;
    String containText;
    String secret;
    String serviceId;
    String blindReport;
    String expose;
    String exposeByCountry;
    String virtual;
    String profileUserId;
    String validateBanWords;
    String maskedUserId;
    String maskedUserName;
    String anonymous;
    String linkEpisodeReference;
    String episodeNumberReference;

    public String getEpisodeNumberReference() {
        return episodeNumberReference;
    }

    public void setEpisodeNumberReference(String episodeNumberReference) {
        this.episodeNumberReference = episodeNumberReference;
    }
    
    public String getLinkEpisodeReference() {
        return linkEpisodeReference;
    }

    public void setLinkEpisodeReference(String linkEpisodeReference) {
        this.linkEpisodeReference = linkEpisodeReference;
    }
    
    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public String getCommentNo() {
        return commentNo;
    }

    public void setCommentNo(String commentNo) {
        this.commentNo = commentNo;
    }

    public String getParentCommentNo() {
        return parentCommentNo;
    }

    public void setParentCommentNo(String parentCommentNo) {
        this.parentCommentNo = parentCommentNo;
    }

    public String getReplyLevel() {
        return replyLevel;
    }

    public void setReplyLevel(String replyLevel) {
        this.replyLevel = replyLevel;
    }

    public int getReplyCount() {
        return replyCount;
    }

    public void setReplyCount(int replyCount) {
        this.replyCount = replyCount;
    }

    public String getReplyAllCount() {
        return replyAllCount;
    }

    public void setReplyAllCount(String replyAllCount) {
        this.replyAllCount = replyAllCount;
    }

    public String getReplyPreviewNo() {
        return replyPreviewNo;
    }

    public void setReplyPreviewNo(String replyPreviewNo) {
        this.replyPreviewNo = replyPreviewNo;
    }

    public String getReplyList() {
        return replyList;
    }

    public void setReplyList(String replyList) {
        this.replyList = replyList;
    }

    public String getImageCount() {
        return imageCount;
    }

    public void setImageCount(String imageCount) {
        this.imageCount = imageCount;
    }

    public String getImageList() {
        return imageList;
    }

    public void setImageList(String imageList) {
        this.imageList = imageList;
    }

    public String getImagePathList() {
        return imagePathList;
    }

    public void setImagePathList(String imagePathList) {
        this.imagePathList = imagePathList;
    }

    public String getImageWidthList() {
        return imageWidthList;
    }

    public void setImageWidthList(String imageWidthList) {
        this.imageWidthList = imageWidthList;
    }

    public String getImageHeightList() {
        return imageHeightList;
    }

    public void setImageHeightList(String imageHeightList) {
        this.imageHeightList = imageHeightList;
    }

    public String getCommentType() {
        return commentType;
    }

    public void setCommentType(String commentType) {
        this.commentType = commentType;
    }

    public String getStickerId() {
        return stickerId;
    }

    public void setStickerId(String stickerId) {
        this.stickerId = stickerId;
    }

    public String getSticker() {
        return sticker;
    }

    public void setSticker(String sticker) {
        this.sticker = sticker;
    }

    public int getSortValue() {
        return sortValue;
    }

    public void setSortValue(int sortValue) {
        this.sortValue = sortValue;
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }

    public String getUserIdNo() {
        return userIdNo;
    }

    public void setUserIdNo(String userIdNo) {
        this.userIdNo = userIdNo;
    }

    public String getExposedUserIp() {
        return exposedUserIp;
    }

    public void setExposedUserIp(String exposedUserIp) {
        this.exposedUserIp = exposedUserIp;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdProvider() {
        return idProvider;
    }

    public void setIdProvider(String idProvider) {
        this.idProvider = idProvider;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserProfileImage() {
        return userProfileImage;
    }

    public void setUserProfileImage(String userProfileImage) {
        this.userProfileImage = userProfileImage;
    }

    public String getProfileType() {
        return profileType;
    }

    public void setProfileType(String profileType) {
        this.profileType = profileType;
    }

    public String getModTime() {
        return modTime;
    }

    public void setModTime(String modTime) {
        this.modTime = modTime;
    }

    public String getModTimeGmt() {
        return modTimeGmt;
    }

    public void setModTimeGmt(String modTimeGmt) {
        this.modTimeGmt = modTimeGmt;
    }

    public String getRegTime() {
        return regTime;
    }

    public void setRegTime(String regTime) {
        this.regTime = regTime;
    }

    public String getRegTimeGmt() {
        return regTimeGmt;
    }

    public void setRegTimeGmt(String regTimeGmt) {
        this.regTimeGmt = regTimeGmt;
    }

    public String getSympathyCount() {
        return sympathyCount;
    }

    public void setSympathyCount(String sympathyCount) {
        this.sympathyCount = sympathyCount;
    }

    public String getAntipathyCount() {
        return antipathyCount;
    }

    public void setAntipathyCount(String antipathyCount) {
        this.antipathyCount = antipathyCount;
    }

    public String getUserBlind() {
        return userBlind;
    }

    public void setUserBlind(String userBlind) {
        this.userBlind = userBlind;
    }

    public String getHideReplyButton() {
        return hideReplyButton;
    }

    public void setHideReplyButton(String hideReplyButton) {
        this.hideReplyButton = hideReplyButton;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMine() {
        return mine;
    }

    public void setMine(String mine) {
        this.mine = mine;
    }

    public String getBest() {
        return best;
    }

    public void setBest(String best) {
        this.best = best;
    }

    public String getMentions() {
        return mentions;
    }

    public void setMentions(String mentions) {
        this.mentions = mentions;
    }

    public String getToUser() {
        return toUser;
    }

    public void setToUser(String toUser) {
        this.toUser = toUser;
    }

    public String getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(String userStatus) {
        this.userStatus = userStatus;
    }

    public String getCategoryImage() {
        return categoryImage;
    }

    public void setCategoryImage(String categoryImage) {
        this.categoryImage = categoryImage;
    }

    public String getOpen() {
        return open;
    }

    public void setOpen(String open) {
        this.open = open;
    }

    public String getLevelCode() {
        return levelCode;
    }

    public void setLevelCode(String levelCode) {
        this.levelCode = levelCode;
    }

    public String getGrades() {
        return grades;
    }

    public void setGrades(String grades) {
        this.grades = grades;
    }

    public String getSympathy() {
        return sympathy;
    }

    public void setSympathy(String sympathy) {
        this.sympathy = sympathy;
    }

    public String getAntipathy() {
        return antipathy;
    }

    public void setAntipathy(String antipathy) {
        this.antipathy = antipathy;
    }

    public String getSnsList() {
        return snsList;
    }

    public void setSnsList(String snsList) {
        this.snsList = snsList;
    }

    public String getMetaInfo() {
        return metaInfo;
    }

    public void setMetaInfo(String metaInfo) {
        this.metaInfo = metaInfo;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public String getAudioInfoList() {
        return audioInfoList;
    }

    public void setAudioInfoList(String audioInfoList) {
        this.audioInfoList = audioInfoList;
    }

    public String getTranslation() {
        return translation;
    }

    public void setTranslation(String translation) {
        this.translation = translation;
    }

    public String getReport() {
        return report;
    }

    public void setReport(String report) {
        this.report = report;
    }

    public String getMiddleBlindReport() {
        return middleBlindReport;
    }

    public void setMiddleBlindReport(String middleBlindReport) {
        this.middleBlindReport = middleBlindReport;
    }

    public String getSpamInfo() {
        return spamInfo;
    }

    public void setSpamInfo(String spamInfo) {
        this.spamInfo = spamInfo;
    }

    public String getUserHomepageUrl() {
        return userHomepageUrl;
    }

    public void setUserHomepageUrl(String userHomepageUrl) {
        this.userHomepageUrl = userHomepageUrl;
    }

    public String getDefamation() {
        return defamation;
    }

    public void setDefamation(String defamation) {
        this.defamation = defamation;
    }

    public String getHiddenByCleanbot() {
        return hiddenByCleanbot;
    }

    public void setHiddenByCleanbot(String hiddenByCleanbot) {
        this.hiddenByCleanbot = hiddenByCleanbot;
    }

    public String getEvalScore() {
        return evalScore;
    }

    public void setEvalScore(String evalScore) {
        this.evalScore = evalScore;
    }

    public String getUserBlocked() {
        return userBlocked;
    }

    public void setUserBlocked(String userBlocked) {
        this.userBlocked = userBlocked;
    }

    public String getVisible() {
        return visible;
    }

    public void setVisible(String visible) {
        this.visible = visible;
    }

    public String getIdNo() {
        return idNo;
    }

    public void setIdNo(String idNo) {
        this.idNo = idNo;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getDeleted() {
        return deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public String getBlind() {
        return blind;
    }

    public void setBlind(String blind) {
        this.blind = blind;
    }

    public String getContainText() {
        return containText;
    }

    public void setContainText(String containText) {
        this.containText = containText;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getBlindReport() {
        return blindReport;
    }

    public void setBlindReport(String blindReport) {
        this.blindReport = blindReport;
    }

    public String getExpose() {
        return expose;
    }

    public void setExpose(String expose) {
        this.expose = expose;
    }

    public String getExposeByCountry() {
        return exposeByCountry;
    }

    public void setExposeByCountry(String exposeByCountry) {
        this.exposeByCountry = exposeByCountry;
    }

    public String getVirtual() {
        return virtual;
    }

    public void setVirtual(String virtual) {
        this.virtual = virtual;
    }

    public String getProfileUserId() {
        return profileUserId;
    }

    public void setProfileUserId(String profileUserId) {
        this.profileUserId = profileUserId;
    }

    public String getValidateBanWords() {
        return validateBanWords;
    }

    public void setValidateBanWords(String validateBanWords) {
        this.validateBanWords = validateBanWords;
    }

    public String getMaskedUserId() {
        return maskedUserId;
    }

    public void setMaskedUserId(String maskedUserId) {
        this.maskedUserId = maskedUserId;
    }

    public String getMaskedUserName() {
        return maskedUserName;
    }

    public void setMaskedUserName(String maskedUserName) {
        this.maskedUserName = maskedUserName;
    }

    public String getAnonymous() {
        return anonymous;
    }

    public void setAnonymous(String anonymous) {
        this.anonymous = anonymous;
    }

}
