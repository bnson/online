/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author bnson
 */
public class ObjStory {

    private String name;
    private String author;
    private String status;
    private List<String> tabs;
    private List<ObjChapter> chapters;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public List<String> getTabs() {
        if (tabs == null) {
            tabs = new ArrayList<>();
        }
        return tabs;
    }

    public void setTabs(List<String> tabs) {
        this.tabs = tabs;
    }

    public List<ObjChapter> getChapters() {
        if (chapters == null) {
            chapters = new ArrayList<>();
        }
        return chapters;
    }

    public void setChapters(List<ObjChapter> chapters) {
        this.chapters = chapters;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "ObjStory{" + "name=" + name + ", author=" + author + ", tabs=" + tabs + ", linksChapter=" + chapters + ", status=" + status + '}';
    }

}
