/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

/**
 *
 * @author bnson
 */
public class ObjFileAssDialogue {

    private String layer;
    private String start;
    private String end;
    private String style;
    private String name;
    private String marginL;
    private String marginR;
    private String marginV;
    private String effect;
    private String text;

    private ObjFileAssDialogueTextFormat textFormatTitle;
    private ObjFileAssDialogueTextFormat textFormatRow1;
    private ObjFileAssDialogueTextFormat textFormatRow2;
    private ObjFileAssDialogueTextFormat textFormatRow3;

    public ObjFileAssDialogue(String AssDialogueLine) {
        String[] arrDialogueLine = AssDialogueLine.replaceFirst("Dialogue: ", "").split(",", 10);

        this.layer = arrDialogueLine[0];
        this.start = arrDialogueLine[1];
        this.end = arrDialogueLine[2];
        this.style = arrDialogueLine[3];
        this.name = arrDialogueLine[4];
        this.marginL = arrDialogueLine[5];
        this.marginR = arrDialogueLine[6];
        this.marginV = arrDialogueLine[7];
        this.effect = arrDialogueLine[8];
        this.text = arrDialogueLine[9];

    }

    private void autoFormatText() {
        //text = text.replaceAll("([^(Mr)])\\. (\\w|\\d)", "$1.\\\\N$2");
        text = text.replaceAll("(\\s)\\b(?:(?!(Mr.|Mrs.|Ms.|MR.|MRS.|MS.))(\\w+))\\b(\\.)+\\B(\\s)", "$1$3$4\\\\N");
        text = text.replace("`", "\\N\\N");
        text = text.replace("★", "\\N\\N");
        text = text.replace("⚊", "\\N\\N");

        if (text.contains(":")) {
            String[] arrText = text.split(":", 2);
            if (arrText[0].split(" ").length < 3) {
                text = "{\\u1\\b1}" + arrText[0].trim() + ": " + "{\\u0\\b0}\\N\\N" + arrText[1].trim();
            }
        }
    }

    public void setTextFormatTitle() {
        if (textFormatTitle != null) {
            if (!textFormatTitle.toString().isEmpty()) {
                text = (textFormatTitle.toString() + text).trim();
            }
        }
        autoFormatText();
    }
    
    public void setTextFormatRow() {
        if (text.contains(" ` ")) {
            String[] arrText = text.split("`");
            String newText = "";

            if (arrText[0] != null && textFormatRow1 != null) {
                if (!textFormatRow1.toString().isEmpty()) {
                    arrText[0] = textFormatRow1.toString() + arrText[0];
                }
                newText = arrText[0].trim();
            }
            
            if (arrText.length > 1) {
                if (arrText[1] != null && textFormatRow2 != null) {
                    if (!textFormatRow2.toString().isEmpty()) {
                        arrText[1] = textFormatRow2.toString() + arrText[1];
                    }
                    newText += "\\N\\N" + arrText[1].trim();                    
                }
            }

            if (arrText.length > 2) {
                if (arrText[2] != null && textFormatRow3 != null) {
                    if (!textFormatRow3.toString().isEmpty()) {
                        arrText[2] = textFormatRow3.toString() + arrText[2];
                    }
                    newText += "\\N\\N" + arrText[2].trim();
                }
            }

            if (!newText.isEmpty()) {
                this.text = newText;
            }
        }

        autoFormatText();
    }

    public String getLayer() {
        return layer;
    }

    public void setLayer(String layer) {
        this.layer = layer;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMarginL() {
        return marginL;
    }

    public void setMarginL(String marginL) {
        if (!marginL.equalsIgnoreCase("default")) {
            this.marginL = marginL;
        }
    }

    public String getMarginR() {
        return marginR;
    }

    public void setMarginR(String marginR) {
        if (!marginR.equalsIgnoreCase("default")) {
            this.marginR = marginR;
        }
    }

    public String getMarginV() {
        return marginV;
    }

    public void setMarginV(String marginV) {
        if (!marginV.equalsIgnoreCase("default")) {
            this.marginV = marginV;
        }
    }

    public String getEffect() {
        return effect;
    }

    public void setEffect(String effect) {
        this.effect = effect;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public ObjFileAssDialogueTextFormat getTextFormatTitle() {
        if (textFormatTitle == null) {
            textFormatTitle = new ObjFileAssDialogueTextFormat();
        }        
        return textFormatTitle;
    }

    public ObjFileAssDialogueTextFormat getTextFormatRow1() {
        if (textFormatRow1 == null) {
            textFormatRow1 = new ObjFileAssDialogueTextFormat();
        }
        return textFormatRow1;
    }

    public ObjFileAssDialogueTextFormat getTextFormatRow2() {
        if (textFormatRow2 == null) {
            textFormatRow2 = new ObjFileAssDialogueTextFormat();
        }
        return textFormatRow2;
    }

    public ObjFileAssDialogueTextFormat getTextFormatRow3() {
        if (textFormatRow3 == null) {
            textFormatRow3 = new ObjFileAssDialogueTextFormat();
        }
        return textFormatRow3;
    }

    @Override
    public String toString() {
        String string = "Dialogue: " + layer + "," + start + "," + end + "," + style + "," + name + "," + marginL + "," + marginR + "," + marginV + "," + effect + "," + text;
        return string;
    }

}
