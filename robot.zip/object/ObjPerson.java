/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author bnson
 */
public class ObjPerson {
    
    private String name;
    private String voice;
    private int rate;
    private int pitch;
    private int volume;

    public ObjPerson(String name, String voice, int rate, int pitch, int volume) {
        this.name = name;
        this.voice = voice;
        this.rate = rate;
        this.pitch = pitch;
        this.volume = volume;
    }

    public String readEnglish(String text) {
        String read = "<voice required=\"Name=$1\"><rate absspeed=\"$2\"><pitch absmiddle=\"$3\"><volume level=\"$4\">$5</volume></pitch></rate></voice>";
        read = read.replace("$1", this.voice);
        read = read.replace("$2", Integer.toString(this.rate));
        read = read.replace("$3", Integer.toString(this.pitch));
        read = read.replace("$4", Integer.toString(this.volume));
      
        if (!this.name.isEmpty() && !this.name.equalsIgnoreCase("male") && !this.name.equalsIgnoreCase("female")) {
            String[] arrText = text.split(":", 2);
            if (arrText.length == 2 && arrText[0].split(" ").length < 3) {
                text = "<volume level=\"0\">" + arrText[0].trim() + ": " + "</volume>" + arrText[1].trim();
            }
        } else {
            //text = text.replace(":", "∶");
        }
        
        //text = processSpecialCharacter(text);
        read = read.replace("$5", text);
        
        return read;
    }
    
    public String readMute(String text) {
        String read = "<voice required=\"Name=$1\"><rate absspeed=\"$2\"><pitch absmiddle=\"$3\"><volume level=\"$4\">$5</volume></pitch></rate></voice>";
        read = read.replace("$1", this.voice);
        read = read.replace("$2", Integer.toString(10));
        read = read.replace("$3", Integer.toString(0));
        read = read.replace("$4", Integer.toString(0));
        read = read.replace("$5", text);
        
        return read;
    }
    
    public String readMute(String text, int speed) {
        String read = "<voice required=\"Name=$1\"><rate absspeed=\"$2\"><pitch absmiddle=\"$3\"><volume level=\"$4\">$5</volume></pitch></rate></voice>";
        read = read.replace("$1", this.voice);
        read = read.replace("$2", Integer.toString(speed));
        read = read.replace("$3", Integer.toString(0));
        read = read.replace("$4", Integer.toString(0));
        read = read.replace("$5", text);
        
        return read;
    }    
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVoice() {
        return voice;
    }

    public void setVoice(String voice) {
        this.voice = voice;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public int getPitch() {
        return pitch;
    }

    public void setPitch(int pitch) {
        this.pitch = pitch;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    private String processSpecialCharacter(String text) {
        String rs = StringUtils.trim(text);
        rs = rs.replace("’", "'");
        rs = rs.replace("…", "...");
        return rs;
    }    

}
