/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author bnson
 */
public class ObjSentence {
    String en;
    List<String> enWords;
    List<String> vn;

    public ObjSentence(String sentence) {
        this.en = "";
        this.enWords = new ArrayList<>();
        this.vn = new ArrayList<>();
        
        String[] arrSentence = sentence.split("↨");
        this.en = arrSentence[0];
        if (arrSentence.length > 1) {
            this.vn.add(arrSentence[1]);
        }
        
    }

    public List<String> getEnWords() {
        if (this.enWords == null) {
            this.enWords = new ArrayList<>();
        }
        this.enWords.addAll(Arrays.asList(StringUtils.stripAll(this.en.split("[\\s\\r\\n]"))));
        return this.enWords;
    }

    public String getEn() {
        return en;
    }

    public void setEn(String en) {
        this.en = en;
    }

    public List<String> getVn() {
        if (vn == null) {
            vn = new ArrayList<>();
        }
        return vn;
    }    
}
