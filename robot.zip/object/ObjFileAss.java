/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import utility.UtilityFileFolder;

/**
 *
 * @author bnson
 */
public class ObjFileAss {

    private int playResX;
    private int playResY;
    private String scriptInfo;
    private String scriptType;

    private final List<String> settings;
    private final List<ObjFileAssDialogue> dialogues;

    private ObjFileAssStyle style;

    private String path;

    public ObjFileAss(String pathFileAss) {
        this.path = pathFileAss;
        List<String> assLines = UtilityFileFolder.readRowTextFileToListString(this.path);

        playResX = 1920;
        playResY = 1080;

        settings = new ArrayList<>();
        dialogues = new ArrayList<>();

        for (String assLine : assLines) {
            if (assLine.startsWith("Dialogue: ")) {
                ObjFileAssDialogue objFileAssDialogue = new ObjFileAssDialogue(assLine);
                dialogues.add(objFileAssDialogue);
            } else if (assLine.startsWith("Style: ")) {
                style = new ObjFileAssStyle(assLine);
            } else if (assLine.startsWith("PlayResX: ")) {
                playResX = Integer.parseInt(assLine.replaceFirst("PlayResX: ", "").trim());
            } else if (assLine.startsWith("PlayResY: ")) {
                playResY = Integer.parseInt(assLine.replaceFirst("PlayResY: ", "").trim());
            } else if (assLine.startsWith("ScriptType: ")) {
                scriptType = assLine.replaceFirst("ScriptType: ", "").trim();
            } else if (assLine.startsWith("; Script ")) {
                scriptInfo = assLine;
            } else {
                settings.add(assLine);
            }
        }
        
        fixError();
    }

    private void fixError() {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("H:mm:ss.SS");
        
        LocalTime timeEnd;
        LocalTime timeStart;
        for (int i = 1; i < dialogues.size(); i++) {
            timeEnd = LocalTime.parse(dialogues.get(i-1).getEnd(), dateTimeFormatter);
            timeStart = LocalTime.parse(dialogues.get(i).getStart(), dateTimeFormatter);
            
            while (timeStart.isBefore(timeEnd)) {
                System.out.println("Fix time end: " + timeEnd);
                timeEnd = timeEnd.minusNanos(10000000);
                dialogues.get(i-1).setEnd(timeEnd.format(dateTimeFormatter));
            }

        }
    }    
    
    public List<String> getSettings() {
        return settings;
    }

    public List<ObjFileAssDialogue> getDialogues() {
        return dialogues;
    }

    public int getPlayResX() {
        return playResX;
    }

    public void setPlayResX(int playResX) {
        this.playResX = playResX;
    }

    public ObjFileAssStyle getStyle() {
        return style;
    }

    public int getPlayResY() {
        return playResY;
    }

    public void setPlayResY(int playResY) {
        this.playResY = playResY;
    }

    public void save() {
        String assFileLinesWriteData = StringUtils.join(this.toString(), "\n");
        UtilityFileFolder.writeTextFileWithBufferedWriter(this.path, "UTF-8", assFileLinesWriteData, false);
    }

    @Override
    public String toString() {
        String rs = "[Script Info]\n" + scriptInfo + "\n"
                + "ScriptType: " + scriptType + "\n"
                + "PlayResX: " + playResX + "\n"
                + "PlayResY: " + playResY + "\n"
                + "\n" + style.toString() + "\n"
                + "\n" + "[Events]" + "\n"
                + "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text" + "\n";

        for (ObjFileAssDialogue dialogue : dialogues) {
            rs += dialogue.toString() + "\n";
        }

        return rs;
    }

}
