/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author bnson
 */
public class ObjWebtoonsEpisode {
    
    String episodeNumber;
    String episodeLink;
    List<ObjWebtoonsComment> ObjWebtoonsComments;

    public String getEpisodeNumber() {
        return episodeNumber;
    }

    public void setEpisodeNumber(String episodeNumber) {
        this.episodeNumber = episodeNumber;
    }

    public String getEpisodeLink() {
        return episodeLink;
    }

    public void setEpisodeLink(String episodeLink) {
        this.episodeLink = episodeLink;
    }
    
    public List<ObjWebtoonsComment> getObjWebtoonsComments() {
        if (ObjWebtoonsComments == null) {
            ObjWebtoonsComments = new ArrayList<>();
        }
        return ObjWebtoonsComments;
    }    
}
