/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import utility.FFMPEG;
import utility.UtilityFileFolder;
import utility.UtilityString;
import utility.UtilityWindowsExplorerComparator;

/**
 *
 * @author bnson
 */
public class English extends javax.swing.JFrame {

    /**
     * Creates new form Main_New
     */
    private final String BALABOLKA = "C:\\Program Files (x86)\\Balabolka\\balabolka.exe";
    //private final String BALCON = "D:\\Application\\balcon\\balcon.exe";
    private final String FFMPEG_PATH = "D:\\Application\\ffmpeg\\ffmpeg-20171115-ff8f40a-win64-static\\bin\\ffmpeg";
    private final FFMPEG ffmpeg;
    String logo = "EngLives";
    String imgCover = "E:\\Projects\\EngLives\\Tiếng_Anh_Lớp_10\\cover_reading_bilingual.png";
    
    public English() {
        initComponents();
        ffmpeg = new FFMPEG(FFMPEG_PATH);
        
        String[] voices = {"","Zira","David","Ngọc"};
        cbbVoice1.setModel(new DefaultComboBoxModel<>(voices)); 
        cbbVoice2.setModel(new DefaultComboBoxModel<>(voices)); 
        cbbVoice3.setModel(new DefaultComboBoxModel<>(voices)); 
    }
    
    
    
    

    private void makeVideoBilingual() {
        String logo = "EngLives";
        String title = "TIẾNG ANH LỚP 10.";
        String pathFolder = tfFolder.getText();
        String pathFileRoot = getPathFileRoot(pathFolder);
        List<String> makeVideo = new ArrayList<>();

        String pathFileRun = pathFileRoot.replace("Root.txt", "Run.txt");
        String pathFileMp3 = pathFileRoot.replace("Root.txt", "Run.mp3");
        String pathFileMp4 = pathFileRoot.replace(" Root.txt", "Run.mp4");
        String pathFileMp4WithoutSubtitle = pathFileRoot.replace("Root.txt", "Run Without Subtitle.mp4");
        String pathFileStr = pathFileRoot.replace("Root.txt", "Run.srt");
        String pathFileAss = pathFileRoot.replace("Root.txt", "Run.ass");

        try {

            if (!pathFileRoot.isEmpty()) {
                List<String> lines = UtilityFileFolder.readRowTextFileToListString(pathFileRoot);
                List<String> linesEN = new ArrayList<>();
                List<String> linesVN = new ArrayList<>();
                boolean isVN = false;
                for (String tmp : lines) {
                    if (tmp.equals("↔↔↔")) {
                        isVN = true;
                    } else {
                        if (!isVN) {
                            linesEN.add(UtilityString.trimSpace(tmp));
                        } else {
                            linesVN.add(UtilityString.trimSpace(tmp));
                        }
                    }
                }

                if (linesEN.size() != linesVN.size()) {
                    System.out.println("Error & Application will exit!");
                    System.exit(0);
                }

                makeVideo.addAll(makeVideoLogo(logo, 2));
                
                
                makeVideo.addAll(makeVideoTitle(title, "VN"));
                
                String message1 = "Video Song Ngữ Anh Việt - Hỗ Trợ Học Tiếng Anh.";
                makeVideo.addAll(makeVideoMessage(message1, "VN"));
                
                //String message2 = "\"Don't stop or replay while listening.\"";
                //makeVideo.addAll(makeVideoMessage(message2, "EN"));
                
                makeVideo.addAll(makeVideoMessage(linesEN.get(0), "EN"));
                makeVideo.addAll(makeVideoMessage(linesVN.get(0), "VN"));

                makeVideo.addAll(makeVideoMessage("Round 1: Bilingual.", "EN"));
                for (int i = 0; i < linesEN.size(); i++) {
                    if (i == 0) {
                        
                    } else {
                        makeVideo.addAll(MakeVideoVoiceZira(linesEN.get(i)));
                        makeVideo.addAll(MakeVideoVoiceGoogleFemale(0, 10,linesVN.get(i)));                        
                    }
                }

                makeVideo.addAll(makeVideoMessage("Round 2: Only English.", "EN"));
                for (int i = 0; i < linesEN.size(); i++) {
                    if (i == 0) {
                        
                    } else {
                        makeVideo.addAll(MakeVideoVoiceZira(linesEN.get(i)));
                    }                    
                    
                }

                makeVideo.addAll(makeVideoMessage("Round 3: Only Vietnamese.", "EN"));
                for (int i = 0; i < linesEN.size(); i++) {
                    if (i == 0) {
                        
                    } else {
                        makeVideo.addAll(MakeVideoVoiceGoogleFemale(linesVN.get(i)));
                    }                    
                    
                }

                makeVideo.addAll(makeVideoMessage("\"Repeat this video until you're satisfied.\"", "EN"));
                makeVideo.addAll(makeVideoMessage("\"Hope this video will help to improve your English.\"", "EN"));
                makeVideo.addAll(makeVideoLogo(logo, 5));

                //String dict = "C:\\Users\\bnson\\Documents\\Balabolka\\sample.bxd";
                UtilityFileFolder.writeTextFileWithBufferedWriter(pathFileRun, "UTF-8", String.join("\n", makeVideo), false);
                ProcessBuilder process = new ProcessBuilder("cmd.exe", "/c", "start", "chcp", "65001", "&", BALABOLKA, "-msq", pathFileRun, pathFileMp3);
                //ProcessBuilder process1 = new ProcessBuilder("cmd.exe", "/c", "start", "chcp", "65001", "&", BALCON, "-f", pathFileRun, "-", pathFileMp3, "-d", dict);
                process.redirectErrorStream(true);
                System.out.println("process: " + process.command());
                Process p = process.start();
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line;

                while ((line = br.readLine()) != null) {
                    System.out.println("-- " + line);
                }
                //System.out.println("-- Wait over: " + p.waitFor()); 

                if (p.waitFor() == 0) {
                    ffmpeg.convertSubSrtToAss(pathFileStr);
                    List<String> assFileLines = UtilityFileFolder.readRowTextFileToListString(pathFileAss);
                    List<String> assFileLinesWrite = new ArrayList<>();
                    int tmpIndex = 0;

                    for (String assFileLine : assFileLines) {
                        System.out.println(tmpIndex + ": " + assFileLine);

                        if (assFileLine.contains("PlayResX: ")) {
                            assFileLine = "PlayResX: 1920";
                        }
                        if (assFileLine.contains("PlayResY: ")) {
                            assFileLine = "PlayResY: 1080";
                        }
                        if (assFileLine.contains("Style: Default")) {
                            //-- CENTER x MID
                            assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,33,33,25,0";
                            //-- CENTER x BOTTOM
                            //assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,33,33,25,0";
                        }

                        if (assFileLine.contains("EngLives")) {
                            assFileLine = assFileLine.replace("EngLives", "{\\b1\\fs200}Eng{\\c&H0000FF&}Lives");
                        }

                        //if (assFileLine.contains(logo)) {
                            //assFileLine = assFileLine.replace(logo, "{\\b1\\fs150}" + logo);
                        //}
                        if (assFileLine.contains(title)) {
                            assFileLine = assFileLine.replace(title, "{\\b1\\fs150}" + title);
                        }                        

                        if (assFileLine.contains(message1)) {
                            assFileLine = assFileLine.replace(message1, "{\\b1\\fs150}" + message1.replaceFirst(" - ", "\\\\N\\\\N"));
                        }

                        //if (assFileLine.contains(",LESSON ") && assFileLine.matches("[\\w\\W]+,LESSON [\\d]+: [\\w\\W]+")) {
                            //assFileLine = assFileLine.replaceFirst(",(LESSON [\\d+]): ", ",{\\\\b1\\\\u1}$1:{\\\\b1\\\\u0}\\\\N\\\\N");
                        //}
                        
                        if (assFileLine.contains(linesEN.get(0))) {
                            assFileLine = assFileLine.replace(linesEN.get(0), "{\\b1\\fs150}" + linesEN.get(0).replaceFirst(" - ", "\\\\N\\\\N"));
                        }
                        if (assFileLine.contains(linesVN.get(0))) {
                            assFileLine = assFileLine.replace(linesVN.get(0), "{\\b1\\fs150}" + linesVN.get(0).replaceFirst(" - ", "\\\\N\\\\N"));
                        }                        

                        if (assFileLine.contains(",Round ") && assFileLine.matches("[\\w\\W]+,Round [\\d]+: [\\w\\W]+")) {
                            assFileLine = assFileLine.replaceFirst(",(Round [\\d+]): ", ",{\\\\b1\\\\u1}$1:{\\\\u0}\\\\N\\\\N");
                            //assFileLine = assFileLine.replaceFirst(",(Round [\\d+]): ", ",{\\\\b1\\\\u1}$1:{\\\\u0}");
                        }

                        if (assFileLine.matches("[^\"]+(\"[^\"]+\"$)")) {
                            assFileLine = assFileLine.replaceFirst("(\"[^\"]+\"$)", "{\\\\b1\\\\i1}$1{\\\\b0\\\\i0}");
                        }

                        if (tmpIndex > 15) {
                            //assFileLine = assFileLine.replaceFirst(",([^0-9,:]+): ", ",{\\\\b1\\\\u1}$1:{\\\\b0\\\\u0}\\\\N\\\\N");
                        }

                        assFileLinesWrite.add(assFileLine);
                        tmpIndex++;
                    }

                    //String assFileLinesWriteData = String.join("\n", assFileLinesWrite);
                    String assFileLinesWriteData = String.join("\n", assFileLinesWrite);
                    UtilityFileFolder.writeTextFileWithBufferedWriter(pathFileAss, "UTF-8", assFileLinesWriteData, false);

                    
                    ffmpeg.mergeImageAndMp3ToMp4_New_3(imgCover, pathFileMp3);

                    ffmpeg.writeSubToVideo5(pathFileAss, pathFileMp4WithoutSubtitle);

                }

            } else {
                System.out.println("Root file don't exist!");
            }

        } catch (IOException ex) {

        } catch (InterruptedException ex) {
            Logger.getLogger(English.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private List<String> MakeVideoVoiceZira(String str) {
        String strVoice = str;
        List<String> listStrVoice = new ArrayList<>();

        listStrVoice.add(addVoiceMicrosoftZiraDesktop(0, 10, processText(strVoice)));
        listStrVoice.add(addVoiceMicrosoftZiraDesktop(100, 0, processText(strVoice)));
        listStrVoice.add(addVoiceMicrosoftZiraDesktop(0, 0, processText(strVoice)));

        return listStrVoice;
    }
    
    private List<String> MakeVideoVoiceGoogleFemale(String str) {
        String strVoice = str;
        List<String> listStrVoice = new ArrayList<>();

        listStrVoice.add(addVoiceMicrosoftZiraDesktop(0, 10, processText(strVoice)));
        listStrVoice.add(processText(strVoice));
        listStrVoice.add(addVoiceMicrosoftZiraDesktop(0, 0, processText(strVoice)));

        return listStrVoice;
    }    
    

    private List<String> MakeVideoVoiceGoogleFemale(int volume, int speed, String str) {
        String strVoice = str;
        List<String> listStrVoice = new ArrayList<>();

        listStrVoice.add(addVoiceMicrosoftZiraDesktop(volume, speed, processText(strVoice)));
        //--
        String strVoiceUpdate = strVoice;
        List<String> listReplace = new ArrayList<>();
        listReplace.add("Oxford Advanced Learner's Dictionary");
        for (String strReplace : listReplace) {
            if (strVoiceUpdate.contains(strReplace)) {
                strVoiceUpdate = strVoiceUpdate.replace(strReplace, addVoiceMicrosoftZiraDesktop(100, 0, strReplace));
            }               
        }     
        listStrVoice.add(processText(strVoiceUpdate));
        //--
        listStrVoice.add(addVoiceMicrosoftZiraDesktop(volume, speed, processText(strVoice)));

        return listStrVoice;
    }

    private List<String> makeVideoLogo(String str, int loop) {
        String strLogo = str;
        List<String> listStrLogo = new ArrayList<>();
        for (int i = 0; i < loop; i++) {
            listStrLogo.add(addVoiceMicrosoftZiraDesktop(0, 0, strLogo));
        }
        return listStrLogo;
    }

    private List<String> makeVideoTitle(String str, String language) {
        String strTitle = str;
        List<String> listStrTitle = new ArrayList<>();
        if (language.equalsIgnoreCase("EN")) {
            listStrTitle.add(addVoiceMicrosoftZiraDesktop(0, 0, strTitle));
            listStrTitle.add(addVoiceMicrosoftZiraDesktop(100, 0, strTitle));
            listStrTitle.add(addVoiceMicrosoftZiraDesktop(0, 0, strTitle));
        } else {
            listStrTitle.add(addVoiceMicrosoftZiraDesktop(0, 0, strTitle));
            listStrTitle.add(strTitle);
            listStrTitle.add(addVoiceMicrosoftZiraDesktop(0, 0, strTitle));
        }
        return listStrTitle;
    }

    private List<String> makeVideoMessage(String str, String language) {
        String strMessage = str;
        List<String> listStrTitle = new ArrayList<>();
        if (language.equalsIgnoreCase("EN")) {
            listStrTitle.add(addVoiceMicrosoftZiraDesktop(0, 5, strMessage));
            listStrTitle.add(addVoiceMicrosoftZiraDesktop(100, 0, strMessage));
            listStrTitle.add(addVoiceMicrosoftZiraDesktop(0, 5, strMessage));
        } else {
            listStrTitle.add(addVoiceMicrosoftZiraDesktop(0, 5, strMessage));
            listStrTitle.add(strMessage);
            listStrTitle.add(addVoiceMicrosoftZiraDesktop(0, 5, strMessage));
        }

        return listStrTitle;
    }

    private String getPathFileRoot(String pathFolder) {
        String pathFileRoot = "";
        List<String> listFiles = UtilityFileFolder.getListPathFileInFolder(pathFolder, "txt", false);
        if (listFiles.size() > 0) {
            for (String file : listFiles) {
                if (file.contains("Root.txt")) {
                    pathFileRoot = file;
                    break;
                }
            }
        }
        return pathFileRoot;
    }

    private String addVoiceMicrosoftZiraDesktop(int volume, int speed, String str) {
        String rs;
        //--
        String lineUpdateVoice = "<voice required=\"Name=Microsoft Zira Desktop\">"
                + "<volume level=\"?1\">"
                + "<rate absspeed=\"?2\">?3</rate>"
                + "</volume>"
                + "</voice>";

        String rate = "<rate absspeed=\"-10\">?1</rate>";
        String silence = "<silence msec=\"1000\"/>";
        String volume0 = "<volume level=\"0\">?1: </volume>";
        String newLine = "\n";
        //--
        rs = lineUpdateVoice.replace("?1", Integer.toString(volume)).replace("?2", Integer.toString(speed)).replace("?3", str);
        //--
        return rs;
    }

    public void makeVideoVocabulary() {
        try {
            String pathFolder = "E:\\Project\\VietnameseAudio\\English\\Topics\\001 - At The Airport";
            String pathRoot = "";
            String pathSaveScript;
            String pathSaveMp3;
            String dataScriptStr;
            List<String> listFiles = UtilityFileFolder.getListPathFileInFolder(pathFolder, "txt", false);
            List<String> dataScriptArr = new ArrayList<>();
            dataScriptArr.add("<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\">VietnameseAudio</volume></voice>");
            dataScriptArr.add("<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\">VietnameseAudio</volume></voice>");

            dataScriptArr.add("HỌC TỪ VỰNG TIẾNG ANH.");
            dataScriptArr.add("CHỦ ĐỀ: TIẾNG ANH TẠI SÂN BAY.");
            dataScriptArr.add("<voice required=\"Name=Microsoft David Desktop\">AT THE AIRPORT.</voice>");

            if (listFiles.size() > 0) {
                for (String file : listFiles) {
                    if (file.contains("Root.txt")) {
                        pathRoot = file;
                        List<String> lines = UtilityFileFolder.readRowTextFileToListString(pathRoot);

                        int index = 0;
                        for (String line : lines) {
                            if (!line.isEmpty() && !line.equalsIgnoreCase(".")) {
                                String tmp = processingVocabularyMicrosoftDavidDesktop(line, index);
                                dataScriptArr.add(tmp);
                                //System.out.println(tmp);
                                index++;
                            }
                        }

                        break;
                    }
                }
            }

            pathSaveScript = pathRoot.replace(" Root.txt", " Subtitle.txt");
            pathSaveMp3 = pathSaveScript.replace(".txt", ".mp3");

            dataScriptStr = String.join("\n", dataScriptArr);
            UtilityFileFolder.writeTextFileWithBufferedWriter(pathSaveScript, "UTF-8", dataScriptStr, false);

            ProcessBuilder process = new ProcessBuilder("cmd.exe", "/c", "start", "chcp", "65001", "&", BALABOLKA, "-msq", pathSaveScript, pathSaveMp3);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            //System.out.println("-- Wait over: " + p.waitFor()); 

            if (p.waitFor() == 0) {
                List<String> listSrtFiles = UtilityFileFolder.getListPathFileInFolder(pathFolder, "srt", false);
                ffmpeg.convertSubSrtToAss(listSrtFiles.get(0));
                //--
                List<String> assFile = UtilityFileFolder.getListPathFileInFolder(pathFolder, "ass", false);
                List<String> assFileLines = UtilityFileFolder.readRowTextFileToListString(assFile.get(0));
                List<String> assFileLinesWrite = new ArrayList<>();
                for (String assFileLine : assFileLines) {
                    if (assFileLine.contains("PlayResX: ")) {
                        assFileLine = "PlayResX: 1920";
                    }
                    if (assFileLine.contains("PlayResY: ")) {
                        assFileLine = "PlayResY: 1080";
                    }
                    if (assFileLine.contains("Style: Default")) {
                        //-- CENTER x MID
                        //assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,33,33,25,0";
                        //-- CENTER x BOTTOM
                        assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,33,33,25,0";
                    }
                    if (assFileLine.contains("VietnameseAudio")) {
                        assFileLine = assFileLine.replace("VietnameseAudio", "{\\b1\\fs123}Vietnamese{\\c&H0000FF&}Audio");
                    }
                    assFileLinesWrite.add(assFileLine);
                }
                String assFileLinesWriteData = String.join("\n", assFileLinesWrite);
                UtilityFileFolder.writeTextFileWithBufferedWriter(assFile.get(0), "UTF-8", assFileLinesWriteData, false);

                String imgCover = pathFolder + "\\" + "cover.png";
                ffmpeg.mergeImageAndMp3ToMp4_New_1(imgCover, pathSaveMp3);

                List<String> listFilesMp4 = UtilityFileFolder.getListPathFileInFolder(pathFolder, "mp4", false);
                List<String> listFilesSub = UtilityFileFolder.getListPathFileInFolder(pathFolder, "ass", false);
                ffmpeg.writeSubToVideo2(listFilesSub.get(0), listFilesMp4.get(0));

            }
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(English.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private List<String> makeVideoHeader() {
        List<String> data = new ArrayList<>();
        data.add(addVoice(2,0,0,0,logo));
        data.add(addVoice(2,0,0,0,logo));
        return data;
    }
    
    private List<String> makeVideoFooter() {
        List<String> data = new ArrayList<>();
        data.add(addVoice(2,100,0,0,"\"Repeat this video until you're satisfied.\""));
        data.add(addVoice(2,100,0,0,"\"Hope this video will help to improve your English.\""));
        
        for (int i = 0; i < 5; i++) {
            data.add(addVoice(2,0,0,0,logo));
        }
        
        return data;
    }    

    public void makeVideoVocabularyEn() {
        String pathFolder = tfFolder.getText().trim();
        String pathFileRoot;
        String pathFileEdit;
        String pathSaveMp3;
        String pathSaveMp4;

        pathFileRoot = UtilityFileFolder.getListPathFileInFolder(pathFolder, "Root.txt", false).get(0);

        try {
            if (!pathFileRoot.isEmpty()) {
                pathFileEdit = pathFileRoot.replace("Root.txt", "Run.txt");
                pathSaveMp3 = pathFileRoot.replace("Root.txt", "Run.mp3");
                pathSaveMp4 = pathFileRoot.replace("Root.txt", "Run.mp4");
                //--
                List<String> dataFileEdit = new ArrayList<>();
                dataFileEdit.addAll(makeVideoHeader());
                //--
                List<String> lines = UtilityFileFolder.readRowTextFileToListString(pathFileRoot);
                int index = 0;
                for (String line : lines) {
                    //System.out.println("-- " + line);
                    if (!line.isEmpty() && !line.equalsIgnoreCase(".")) {
                        if (index == 0) {
                            //SUBJECT
                            String titleEn = processText(line).toUpperCase().trim();
                            dataFileEdit.add(addVoice(2, 100, 0, 0, titleEn));
                            dataFileEdit.add(addVoice(2, 0, 0, 0, titleEn));
                        } else {
                            if (index % 2 == 0) {
                                line = processText(line).trim();
                                dataFileEdit.add(addVoice(2, 0, 8, 0, line));
                                dataFileEdit.add(addVoice(2, 100, 0, 0, line));
                                dataFileEdit.add(addVoice(2, 0, 4, 0, line));
                            } else {
                                line = processText(line).trim();
                                dataFileEdit.add(addVoice(1, 0, 8, 0, line));
                                dataFileEdit.add(addVoice(1, 100, 0, 0, line));
                                dataFileEdit.add(addVoice(1, 0, 4, 0, line));
                            }
                        }
                    }
                    index++;
                }
                //--
                dataFileEdit.addAll(makeVideoFooter());

                UtilityFileFolder.writeTextFileWithBufferedWriter(pathFileEdit, "UTF-8", String.join("\n", dataFileEdit), false);

                ProcessBuilder process = new ProcessBuilder("cmd.exe", "/c", "start", "chcp", "65001", "&", BALABOLKA, "-msq", pathFileEdit, pathSaveMp3);
                process.redirectErrorStream(true);
                System.out.println("process: " + process.command());
                Process p = process.start();
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line;

                while ((line = br.readLine()) != null) {
                    System.out.println("-- " + line);
                }

                if (p.waitFor() == 0) {
                    List<String> listSrtFiles = UtilityFileFolder.getListPathFileInFolder(pathFolder, "srt", false);
                    ffmpeg.convertSubSrtToAss(listSrtFiles.get(0));
                    //--
                    List<String> assFile = UtilityFileFolder.getListPathFileInFolder(pathFolder, "ass", false);
                    List<String> assFileLines = UtilityFileFolder.readRowTextFileToListString(assFile.get(0));
                    List<String> assFileLinesWrite = new ArrayList<>();
                    
                    boolean customLine = false;
                    for (String assFileLine : assFileLines) {
                        if (assFileLine.contains("PlayResX: ")) {
                            assFileLine = "PlayResX: 1920";
                        }
                        if (assFileLine.contains("PlayResY: ")) {
                            assFileLine = "PlayResY: 1080";
                        }
                        if (assFileLine.contains("Style: Default")) {
                            //-- CENTER x MID
                            assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,33,33,25,0";
                            //-- CENTER x BOTTOM
                            //assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,33,33,25,0";
                        }
                        if (assFileLine.contains("EngLives")) {
                            assFileLine = assFileLine.replace("EngLives", "{\\b1\\fs123}Eng{\\c&H0000FF&}Lives");
                        }
                        if (assFileLine.contains("\\N\\N/")) {
                            assFileLine = assFileLine.replace("\\N\\N/", "\\N\\N{\\i1\\c&HA1A1A1&\\fs90}/") + "{\\i0}";
                        }
                        
                        if (assFileLine.contains("IRREGULAR VERBS.")) {
                            customLine = true;
                        }
                        
                        if (assFileLine.contains("\"Repeat this video until you're satisfied.\"")) {
                            customLine = false;
                        }
                        
                        if (customLine) {
                            assFileLine = assFileLine.replace(". ", "\\N\\N");
                            System.out.println("assFileLine: " + assFileLine);
                        }
                        
                        assFileLinesWrite.add(assFileLine);
                    }
                    String assFileLinesWriteData = String.join("\n", assFileLinesWrite);
                    UtilityFileFolder.writeTextFileWithBufferedWriter(assFile.get(0), "UTF-8", assFileLinesWriteData, false);

                    String imgCover = pathFolder + "\\" + "cover.png";
                    ffmpeg.mergeImageAndMp3ToMp4_New_1(imgCover, pathSaveMp3);

                    List<String> listFilesMp4 = UtilityFileFolder.getListPathFileInFolder(pathFolder, "mp4", false);
                    List<String> listFilesSub = UtilityFileFolder.getListPathFileInFolder(pathFolder, "ass", false);
                    ffmpeg.writeSubToVideo2(listFilesSub.get(0), listFilesMp4.get(0));
                }
            }
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(English.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void makeVideoConversationEn() {
        String pathFolder = tfFolder.getText().trim();
        String pathFileRoot;
        String pathFileEdit;
        String pathSaveMp3;
        String pathSaveMp4;
        
        int voice = 1;
        int voiceSubject = 1;
        if (cbVoiceZira.isSelected()) {
            voice = 1;
            voiceSubject = 2;
        }                             
        if (cbVoiceDavid.isSelected()) {
            voice = 2;
            voiceSubject = 1;
        }
        if (cbVoiceZira.isSelected() && cbVoiceDavid.isSelected()) {
            voice = 3;
            voiceSubject = 1;
        }          
        
        pathFileRoot = UtilityFileFolder.getListPathFileInFolder(pathFolder, "Root.txt", false).get(0);

        try {
            if (!pathFileRoot.isEmpty()) {
                pathFileEdit = pathFileRoot.replace("Root.txt", "Run.txt");
                pathSaveMp3 = pathFileRoot.replace("Root.txt", "Run.mp3");
                pathSaveMp4 = pathFileRoot.replace("Root.txt", "Run.mp4");
                //--
                List<String> dataFileEdit = new ArrayList<>();
                dataFileEdit.addAll(makeVideoHeader());
                //--
                List<String> lines = UtilityFileFolder.readRowTextFileToListString(pathFileRoot);
                int index = 0;
                for (String line : lines) {
                    //System.out.println("-- " + line);
                    if (!line.isEmpty() && !line.equalsIgnoreCase(".")) {
                        if (index == 0) {
                            //SUBJECT                          
                            String titleEn = processText(line).toUpperCase().trim();
                            dataFileEdit.add(addVoice(voiceSubject, 100, 0, 0, titleEn));
                            dataFileEdit.add(addVoice(voiceSubject, 0, 0, 0, titleEn));
                        } else {
                            if (voice == 1 || voice == 2) {
                                line = processText(line).trim();

                                dataFileEdit.add(addVoice(voice, 0, 8, 0, line));
                                dataFileEdit.add(addVoice(voice, 100, 0, 0, line));
                                dataFileEdit.add(addVoice(voice, 0, 4, 0, line));                                
                            }
                            if (voice == 3) {
                                if (index % 2 == 0) {
                                    line = processText(line).trim();
                                    dataFileEdit.add(addVoice(2, 0, 8, 0, line));
                                    dataFileEdit.add(addVoice(2, 100, 0, 0, line));
                                    dataFileEdit.add(addVoice(2, 0, 4, 0, line));
                                } else {
                                    line = processText(line).trim();
                                    dataFileEdit.add(addVoice(1, 0, 8, 0, line));
                                    dataFileEdit.add(addVoice(1, 100, 0, 0, line));
                                    dataFileEdit.add(addVoice(1, 0, 4, 0, line));
                                }                                
                            }

                        }
                    }
                    index++;
                }
                //--
                dataFileEdit.addAll(makeVideoFooter());

                UtilityFileFolder.writeTextFileWithBufferedWriter(pathFileEdit, "UTF-8", String.join("\n", dataFileEdit), false);

                ProcessBuilder process = new ProcessBuilder("cmd.exe", "/c", "start", "chcp", "65001", "&", BALABOLKA, "-msq", pathFileEdit, pathSaveMp3);
                process.redirectErrorStream(true);
                System.out.println("process: " + process.command());
                Process p = process.start();
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line;

                while ((line = br.readLine()) != null) {
                    System.out.println("-- " + line);
                }

                if (p.waitFor() == 0) {
                    List<String> listSrtFiles = UtilityFileFolder.getListPathFileInFolder(pathFolder, "srt", false);
                    ffmpeg.convertSubSrtToAss(listSrtFiles.get(0));
                    //--
                    List<String> assFile = UtilityFileFolder.getListPathFileInFolder(pathFolder, "ass", false);
                    List<String> assFileLines = UtilityFileFolder.readRowTextFileToListString(assFile.get(0));
                    List<String> assFileLinesWrite = new ArrayList<>();

                    for (String assFileLine : assFileLines) {
                        if (assFileLine.contains("PlayResX: ")) {
                            assFileLine = "PlayResX: 1920";
                        }
                        if (assFileLine.contains("PlayResY: ")) {
                            assFileLine = "PlayResY: 1080";
                        }
                        if (assFileLine.contains("Style: Default")) {
                            //-- CENTER x MID
                            assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,33,33,25,0";
                            //-- CENTER x BOTTOM
                            //assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,33,33,25,0";
                        }
                        if (assFileLine.contains("EngLives")) {
                            assFileLine = assFileLine.replace("EngLives", "{\\b1\\fs123}Eng{\\c&H0000FF&}Lives");
                        }
                        if (assFileLine.contains("\\N\\N/")) {
                            assFileLine = assFileLine.replace("\\N\\N/", "\\N\\N{\\i1\\c&HA1A1A1&\\fs90}/") + "{\\i0}";
                        }
                        
                        assFileLinesWrite.add(assFileLine);
                    }
                    String assFileLinesWriteData = String.join("\n", assFileLinesWrite);
                    UtilityFileFolder.writeTextFileWithBufferedWriter(assFile.get(0), "UTF-8", assFileLinesWriteData, false);

                    String imgCover = pathFolder + "\\" + "cover.png";
                    ffmpeg.mergeImageAndMp3ToMp4_New_1(imgCover, pathSaveMp3);

                    List<String> listFilesMp4 = UtilityFileFolder.getListPathFileInFolder(pathFolder, "mp4", false);
                    List<String> listFilesSub = UtilityFileFolder.getListPathFileInFolder(pathFolder, "ass", false);
                    ffmpeg.writeSubToVideo2(listFilesSub.get(0), listFilesMp4.get(0));
                }
            }
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(English.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
 
    public void makeVideoVocabulary001() {
        try {
            String pathFolder = tfFolder.getText().trim();

            String pathFileRoot = "";
            String pathFileEdit;

            String pathSaveMp3;
            String pathSaveMp4;

            List<String> listFiles = UtilityFileFolder.getListPathFileInFolder(pathFolder, "txt", false);

            if (listFiles.size() > 0) {
                for (String file : listFiles) {
                    if (file.contains("Root.txt")) {
                        pathFileRoot = file;
                        break;
                    }
                }
            }

            if (!pathFileRoot.isEmpty()) {
                pathFileEdit = pathFileRoot.replace("Root.txt", "Run.txt");
                pathSaveMp3 = pathFileRoot.replace("Root.txt", "Run.mp3");
                pathSaveMp4 = pathFileRoot.replace("Root.txt", "Run.mp4");

                List<String> dataFileEdit = new ArrayList<>();
                dataFileEdit.add("<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\">EngLives</volume></voice>");
                dataFileEdit.add("<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\">EngLives</volume></voice>");
                dataFileEdit.add("HỌC TỪ VỰNG TIẾNG ANH.");

                List<String> lines = UtilityFileFolder.readRowTextFileToListString(pathFileRoot);
                int index = 0;
                for (String line : lines) {
                    //System.out.println("-- " + line);
                    if (!line.isEmpty() && !line.equalsIgnoreCase(".")) {
                        if (index == 0) {
                            String titleVN = processText(line.split("~")[0]).toUpperCase().trim();
                            String titleEN = processText(line.split("~")[1]).toUpperCase().trim();
                            titleEN = titleEN.replaceAll("[\\d\\s]+\\.\\s", "");

                            titleVN = "CÁCH ĐỂ NÓI \"" + titleVN.replaceAll("[?!.]$", "") + "\" TRONG TIẾNG ANH.";
                            titleEN = "THE WAYS TO SAY \"" + titleEN.replaceAll("[?!.]$", "") + "\" IN ENGLISH.";
                            dataFileEdit.add("CHỦ ĐỀ: " + titleVN);
                            dataFileEdit.add("SUBJECT: " + addVoiceMicrosoftZiraDesktop(titleEN));
                        } else {
                            if (index % 2 == 0) {
                                dataFileEdit.add(processText(line.split("~")[0]));
                                dataFileEdit.add(addVoiceMicrosoftDavidDesktop(processText(line.split("~")[1])));
                                dataFileEdit.add(addVoiceMicrosoftDavidDesktop(processText(line.split("~")[1]).replace(" ", ". ")));
                                dataFileEdit.add(addVoiceMicrosoftDavidDesktop(processText(line.split("~")[1])));
                                dataFileEdit.add(addVoiceMicrosoftDavidDesktop(processText(line.split("~")[1])));
                            } else {
                                dataFileEdit.add(processText(line.split("~")[0]));
                                dataFileEdit.add(addVoiceMicrosoftZiraDesktop(processText(line.split("~")[1])));
                                dataFileEdit.add(addVoiceMicrosoftZiraDesktop(processText(line.split("~")[1]).replace(" ", ". ")));
                                dataFileEdit.add(addVoiceMicrosoftZiraDesktop(processText(line.split("~")[1])));
                                dataFileEdit.add(addVoiceMicrosoftZiraDesktop(processText(line.split("~")[1])));
                            }
                        }
                    }
                    index++;
                }

                dataFileEdit.add("<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\">EngLives</volume></voice>");
                dataFileEdit.add("<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\">EngLives</volume></voice>");

                UtilityFileFolder.writeTextFileWithBufferedWriter(pathFileEdit, "UTF-8", String.join("\n", dataFileEdit), false);

                ProcessBuilder process = new ProcessBuilder("cmd.exe", "/c", "start", "chcp", "65001", "&", BALABOLKA, "-msq", pathFileEdit, pathSaveMp3);
                process.redirectErrorStream(true);
                System.out.println("process: " + process.command());
                Process p = process.start();
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line;

                while ((line = br.readLine()) != null) {
                    System.out.println("-- " + line);
                }
                //System.out.println("-- Wait over: " + p.waitFor()); 

                if (p.waitFor() == 0) {
                    List<String> listSrtFiles = UtilityFileFolder.getListPathFileInFolder(pathFolder, "srt", false);
                    ffmpeg.convertSubSrtToAss(listSrtFiles.get(0));
                    //--
                    List<String> assFile = UtilityFileFolder.getListPathFileInFolder(pathFolder, "ass", false);
                    List<String> assFileLines = UtilityFileFolder.readRowTextFileToListString(assFile.get(0));
                    List<String> assFileLinesWrite = new ArrayList<>();
                    for (String assFileLine : assFileLines) {
                        if (assFileLine.contains("PlayResX: ")) {
                            assFileLine = "PlayResX: 1920";
                        }
                        if (assFileLine.contains("PlayResY: ")) {
                            assFileLine = "PlayResY: 1080";
                        }
                        if (assFileLine.contains("Style: Default")) {
                            //-- CENTER x MID
                            assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,33,33,25,0";
                            //-- CENTER x BOTTOM
                            //assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,33,33,25,0";
                        }
                        if (assFileLine.contains("EngLives")) {
                            assFileLine = assFileLine.replace("EngLives", "{\\b1\\fs123}Eng{\\c&H0000FF&}Lives");
                        }
                        assFileLinesWrite.add(assFileLine);
                    }
                    String assFileLinesWriteData = String.join("\n", assFileLinesWrite);
                    UtilityFileFolder.writeTextFileWithBufferedWriter(assFile.get(0), "UTF-8", assFileLinesWriteData, false);

                    String imgCover = pathFolder + "\\" + "cover.png";
                    ffmpeg.mergeImageAndMp3ToMp4_New_1(imgCover, pathSaveMp3);

                    List<String> listFilesMp4 = UtilityFileFolder.getListPathFileInFolder(pathFolder, "mp4", false);
                    List<String> listFilesSub = UtilityFileFolder.getListPathFileInFolder(pathFolder, "ass", false);
                    ffmpeg.writeSubToVideo2(listFilesSub.get(0), listFilesMp4.get(0));
                }
            }

        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(English.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //Có phiên âm
    public void makeVideoVocabulary002() {
        try {
            String pathFolder = tfFolder.getText().trim();

            String pathFileRoot = "";
            String pathFileEdit;

            String pathSaveMp3;
            String pathSaveMp4;

            List<String> listFiles = UtilityFileFolder.getListPathFileInFolder(pathFolder, "txt", false);

            if (listFiles.size() > 0) {
                for (String file : listFiles) {
                    if (file.contains("Root.txt")) {
                        pathFileRoot = file;
                        break;
                    }
                }
            }

            if (!pathFileRoot.isEmpty()) {
                pathFileEdit = pathFileRoot.replace("Root.txt", "Run.txt");
                pathSaveMp3 = pathFileRoot.replace("Root.txt", "Run.mp3");
                pathSaveMp4 = pathFileRoot.replace("Root.txt", "Run.mp4");

                List<String> dataFileEdit = new ArrayList<>();
                dataFileEdit.add("<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\">EngLives</volume></voice>");
                dataFileEdit.add("<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\">EngLives</volume></voice>");
                dataFileEdit.add("HỌC TỪ VỰNG TIẾNG ANH.");

                List<String> lines = UtilityFileFolder.readRowTextFileToListString(pathFileRoot);
                int index = 0;
                for (String line : lines) {
                    //System.out.println("-- " + line);
                    if (!line.isEmpty() && !line.equalsIgnoreCase(".")) {
                        if (index == 0) {
                            String title01 = processText(line.split("~")[0]).toUpperCase().trim();
                            String title02 = processText(line.split("~")[1]).toUpperCase().trim();
                            dataFileEdit.add(title01);
                            dataFileEdit.add(addVoiceMicrosoftZiraDesktop(title02));
                        } else if (index > 1) {
                            if (index % 2 == 0) {
                                System.out.println("line: " + line);
                                dataFileEdit.add(processText(line.split("~")[3]));

                                String tmpSilent = "<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\"><rate absspeed=\"10\">"
                                        + addVoiceMicrosoftDavidDesktop(processText(line.split("~")[0]))
                                        + "\\N\\N"
                                        + processText(line.split("~")[2]).replaceAll("( / |/ | /)", "/")
                                        + " (" + processText(line.split("~")[1]) + ")</rate></volume></voice>";
                                dataFileEdit.add(tmpSilent);

                                String tmp = addVoiceMicrosoftDavidDesktop(processText(line.split("~")[0]))
                                        + "<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\"><rate absspeed=\"10\">\\N\\N"
                                        + processText(line.split("~")[2]).replaceAll("( / |/ | /)", "/")
                                        + " (" + processText(line.split("~")[1]) + ")</rate></volume></voice>";
                                dataFileEdit.add(tmp);
                                dataFileEdit.add(tmp);
                                dataFileEdit.add(tmp);
                                dataFileEdit.add(tmp);
                            } else {
                                dataFileEdit.add(processText(line.split("~")[3]));

                                String tmpSilent = "<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\"><rate absspeed=\"10\">"
                                        + addVoiceMicrosoftDavidDesktop(processText(line.split("~")[0]))
                                        + "\\N\\N"
                                        + processText(line.split("~")[2]).replaceAll("( / |/ | /)", "/")
                                        + " (" + processText(line.split("~")[1]) + ")</rate></volume></voice>";
                                dataFileEdit.add(tmpSilent);

                                String tmp = addVoiceMicrosoftZiraDesktop(processText(line.split("~")[0]))
                                        + "<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\"><rate absspeed=\"10\">\\N\\N"
                                        + processText(line.split("~")[2]).replaceAll("( / |/ | /)", "/")
                                        + " (" + processText(line.split("~")[1]) + ")</rate></volume></voice>";
                                dataFileEdit.add(tmp);
                                dataFileEdit.add(tmp);
                                dataFileEdit.add(tmp);
                                dataFileEdit.add(tmp);
                            }
                        }
                    }
                    index++;
                }

                dataFileEdit.add("<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\">EngLives</volume></voice>");
                dataFileEdit.add("<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\">EngLives</volume></voice>");

                UtilityFileFolder.writeTextFileWithBufferedWriter(pathFileEdit, "UTF-8", String.join("\n", dataFileEdit), false);

                ProcessBuilder process = new ProcessBuilder("cmd.exe", "/c", "start", "chcp", "65001", "&", BALABOLKA, "-msq", pathFileEdit, pathSaveMp3);
                process.redirectErrorStream(true);
                System.out.println("process: " + process.command());
                Process p = process.start();
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line;

                while ((line = br.readLine()) != null) {
                    System.out.println("-- " + line);
                }
                //System.out.println("-- Wait over: " + p.waitFor()); 

                if (p.waitFor() == 0) {
                    List<String> listSrtFiles = UtilityFileFolder.getListPathFileInFolder(pathFolder, "srt", false);
                    ffmpeg.convertSubSrtToAss(listSrtFiles.get(0));
                    //--
                    List<String> assFile = UtilityFileFolder.getListPathFileInFolder(pathFolder, "ass", false);
                    List<String> assFileLines = UtilityFileFolder.readRowTextFileToListString(assFile.get(0));
                    List<String> assFileLinesWrite = new ArrayList<>();
                    for (String assFileLine : assFileLines) {
                        if (assFileLine.contains("PlayResX: ")) {
                            assFileLine = "PlayResX: 1920";
                        }
                        if (assFileLine.contains("PlayResY: ")) {
                            assFileLine = "PlayResY: 1080";
                        }
                        if (assFileLine.contains("Style: Default")) {
                            //-- CENTER x MID
                            assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,33,33,25,0";
                            //-- CENTER x BOTTOM
                            //assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,33,33,25,0";
                        }
                        if (assFileLine.contains("EngLives")) {
                            assFileLine = assFileLine.replace("EngLives", "{\\b1\\fs123}Eng{\\c&H0000FF&}Lives");
                        }
                        if (assFileLine.contains("\\N\\N/")) {
                            assFileLine = assFileLine.replace("\\N\\N/", "\\N\\N{\\i1\\c&HA1A1A1&\\fs90}/") + "{\\i0}";
                        }
                        assFileLinesWrite.add(assFileLine);
                    }
                    String assFileLinesWriteData = String.join("\n", assFileLinesWrite);
                    UtilityFileFolder.writeTextFileWithBufferedWriter(assFile.get(0), "UTF-8", assFileLinesWriteData, false);

                    String imgCover = pathFolder + "\\" + "cover.png";
                    ffmpeg.mergeImageAndMp3ToMp4_New_1(imgCover, pathSaveMp3);

                    List<String> listFilesMp4 = UtilityFileFolder.getListPathFileInFolder(pathFolder, "mp4", false);
                    List<String> listFilesSub = UtilityFileFolder.getListPathFileInFolder(pathFolder, "ass", false);
                    ffmpeg.writeSubToVideo2(listFilesSub.get(0), listFilesMp4.get(0));
                }
            }

        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(English.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //Ko có phiên âm
    public void makeVideoVocabulary003() {
        try {
            String pathFolder = tfFolder.getText().trim();

            String pathFileRoot = "";
            String pathFileEdit;

            String pathSaveMp3;
            String pathSaveMp4;

            List<String> listFiles = UtilityFileFolder.getListPathFileInFolder(pathFolder, "txt", false);

            if (listFiles.size() > 0) {
                for (String file : listFiles) {
                    if (file.contains("Root.txt")) {
                        pathFileRoot = file;
                        break;
                    }
                }
            }

            if (!pathFileRoot.isEmpty()) {
                pathFileEdit = pathFileRoot.replace("Root.txt", "Run.txt");
                pathSaveMp3 = pathFileRoot.replace("Root.txt", "Run.mp3");
                pathSaveMp4 = pathFileRoot.replace("Root.txt", "Run.mp4");

                List<String> dataFileEdit = new ArrayList<>();
                dataFileEdit.add("<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\">EngLives</volume></voice>");
                dataFileEdit.add("<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\">EngLives</volume></voice>");
                dataFileEdit.add("HỌC TỪ VỰNG TIẾNG ANH.");

                List<String> lines = UtilityFileFolder.readRowTextFileToListString(pathFileRoot);

                String title01 = processText(lines.get(0).split("~")[0]).toUpperCase().trim();
                String title02 = processText(lines.get(0).split("~")[1]).toUpperCase().trim();
                dataFileEdit.add(title01);
                dataFileEdit.add(addVoiceMicrosoftZiraDesktop(title02));
                String tmpSilentTitle02 = "<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\"><rate absspeed=\"0\">"
                        + addVoiceMicrosoftDavidDesktop(processText(title02))
                        + "</rate></volume></voice>";
                dataFileEdit.add(tmpSilentTitle02);

                lines.remove(0);
                Collections.sort(lines, new UtilityWindowsExplorerComparator());
                int index = 0;
                for (String line : lines) {
                    //System.out.println("-- " + line);
                    if (!line.isEmpty() && !line.equalsIgnoreCase(".")) {
                        if (index == -1) {
//                            String title01 = processText(line.split("~")[0]).toUpperCase().trim();
//                            String title02 = processText(line.split("~")[1]).toUpperCase().trim();
//                            dataFileEdit.add(title01);
//                            dataFileEdit.add(addVoiceMicrosoftZiraDesktop(title02));
                        } else if (index >= 0) {
                            System.out.println("line: " + line);
                            if (index % 2 == 0) {
                                dataFileEdit.add(processText(line.split("~")[2]));

                                String tmpSilent = "<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\"><rate absspeed=\"10\">"
                                        + addVoiceMicrosoftDavidDesktop(processText(line.split("~")[0]))
                                        + "\\N\\N"
                                        + processText(line.split("~")[1]).replaceAll("( / |/ | /)", "/")
                                        + "</rate></volume></voice>";
                                dataFileEdit.add(tmpSilent);

                                String tmp = addVoiceMicrosoftDavidDesktop(processText(line.split("~")[0]))
                                        + "<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\"><rate absspeed=\"10\">\\N\\N"
                                        + processText(line.split("~")[1]).replaceAll("( / |/ | /)", "/")
                                        + "</rate></volume></voice>";
                                dataFileEdit.add(tmp);
                                dataFileEdit.add(tmp);
                                dataFileEdit.add(tmp);
                                dataFileEdit.add(tmp);
                            } else {
                                dataFileEdit.add(processText(line.split("~")[2]));

                                String tmpSilent = "<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\"><rate absspeed=\"10\">\\N\\N"
                                        + addVoiceMicrosoftDavidDesktop(processText(line.split("~")[0]))
                                        + "\\N\\N"
                                        + processText(line.split("~")[1]).replaceAll("( / |/ | /)", "/")
                                        + "</rate></volume></voice>";
                                dataFileEdit.add(tmpSilent);

                                String tmp = addVoiceMicrosoftZiraDesktop(processText(line.split("~")[0]))
                                        + "<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\"><rate absspeed=\"10\">\\N\\N"
                                        + processText(line.split("~")[1]).replaceAll("( / |/ | /)", "/")
                                        + "</rate></volume></voice>";
                                dataFileEdit.add(tmp);
                                dataFileEdit.add(tmp);
                                dataFileEdit.add(tmp);
                                dataFileEdit.add(tmp);
                            }
                        }
                    }
                    index++;
                }

                dataFileEdit.add("<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\">EngLives</volume></voice>");
                dataFileEdit.add("<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\">EngLives</volume></voice>");

                UtilityFileFolder.writeTextFileWithBufferedWriter(pathFileEdit, "UTF-8", String.join("\n", dataFileEdit), false);

                ProcessBuilder process = new ProcessBuilder("cmd.exe", "/c", "start", "chcp", "65001", "&", BALABOLKA, "-msq", pathFileEdit, pathSaveMp3);
                process.redirectErrorStream(true);
                System.out.println("process: " + process.command());
                Process p = process.start();
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line;

                while ((line = br.readLine()) != null) {
                    System.out.println("-- " + line);
                }
                //System.out.println("-- Wait over: " + p.waitFor()); 

                if (p.waitFor() == 0) {
                    List<String> listSrtFiles = UtilityFileFolder.getListPathFileInFolder(pathFolder, "srt", false);
                    ffmpeg.convertSubSrtToAss(listSrtFiles.get(0));
                    //--
                    List<String> assFile = UtilityFileFolder.getListPathFileInFolder(pathFolder, "ass", false);
                    List<String> assFileLines = UtilityFileFolder.readRowTextFileToListString(assFile.get(0));
                    List<String> assFileLinesWrite = new ArrayList<>();
                    for (String assFileLine : assFileLines) {
                        if (assFileLine.contains("PlayResX: ")) {
                            assFileLine = "PlayResX: 1920";
                        }
                        if (assFileLine.contains("PlayResY: ")) {
                            assFileLine = "PlayResY: 1080";
                        }
                        if (assFileLine.contains("Style: Default")) {
                            //-- CENTER x MID
                            assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,33,33,25,0";
                            //-- CENTER x BOTTOM
                            //assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,33,33,25,0";
                        }
                        if (assFileLine.contains("EngLives")) {
                            assFileLine = assFileLine.replace("EngLives", "{\\b1\\fs123}Eng{\\c&H0000FF&}Lives");
                        }
                        if (assFileLine.contains("\\N\\N/")) {
                            assFileLine = assFileLine.replace("\\N\\N/", "\\N\\N{\\i1\\c&HA1A1A1&\\fs90}/") + "{\\i0}";
                        }
                        assFileLinesWrite.add(assFileLine);
                    }
                    String assFileLinesWriteData = String.join("\n", assFileLinesWrite);
                    UtilityFileFolder.writeTextFileWithBufferedWriter(assFile.get(0), "UTF-8", assFileLinesWriteData, false);

                    String imgCover = pathFolder + "\\" + "cover.png";
                    ffmpeg.mergeImageAndMp3ToMp4_New_1(imgCover, pathSaveMp3);

                    List<String> listFilesMp4 = UtilityFileFolder.getListPathFileInFolder(pathFolder, "mp4", false);
                    List<String> listFilesSub = UtilityFileFolder.getListPathFileInFolder(pathFolder, "ass", false);
                    ffmpeg.writeSubToVideo2(listFilesSub.get(0), listFilesMp4.get(0));
                }
            }

        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(English.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private String processText(String str) {
        String rs = str.replaceAll("\\s+", " ");
        rs = rs.trim();

        if (rs.matches("[!?.]$")) {
            rs = rs + ".";
        }
        return rs;
    }

    private String addVoiceMicrosoftDavidDesktop(String str) {
        String rs;
        //--
        String lineUpdateVoice = "<voice required=\"Name=Microsoft David Desktop\">?1</voice>";
        String lineUpdate1Rate = "<voice required=\"Name=Microsoft David Desktop\"><rate absspeed=\"-10\">?1</rate></voice>";
        String rate = "<rate absspeed=\"-10\">?1</rate>";
        String silence = "<silence msec=\"1000\"/>";
        String volume0 = "<volume level=\"0\">?1: </volume>";
        String newLine = "\n";
        //--
        rs = lineUpdateVoice.replace("?1", str);
        //--
        return rs;
    }
    
    private String addVoice(int voice, int volume, int rate, int pitch, String text) {
        String voice1 = "Microsoft Zira Desktop";
        String voice2 = "Microsoft David Desktop";
        String addVoice = "<voice required=\"Name=?1\"><volume level=\"?2\"><rate absspeed=\"?3\"><pitch absmiddle=\"?4\">?5</pitch></rate></volume></voice>";
        
        switch (voice) {
            case 1:
                addVoice = addVoice.replace("?1", voice1);
                break;
            case 2:
                addVoice = addVoice.replace("?1", voice2);
                break;
            default:
                addVoice = addVoice.replace("?1", voice1);
        }
        
        addVoice = addVoice.replace("?2", Integer.toString(volume));
        addVoice = addVoice.replace("?3", Integer.toString(rate));
        addVoice = addVoice.replace("?4", Integer.toString(pitch));
        addVoice = addVoice.replace("?5", text);
        
        return addVoice;
    }
    
    

    private String addVoiceMicrosoftZiraDesktop(String str) {
        String rs;
        //--
        String lineUpdateVoice = "<voice required=\"Name=Microsoft Zira Desktop\">?1</voice>";
        String lineUpdate1Rate = "<voice required=\"Name=Microsoft Zira Desktop\"><rate absspeed=\"-10\">?1</rate></voice>";
        String rate = "<rate absspeed=\"-10\">?1</rate>";
        String silence = "<silence msec=\"1000\"/>";
        String volume0 = "<volume level=\"0\">?1: </volume>";
        String newLine = "\n";
        //--
        rs = lineUpdateVoice.replace("?1", str);
        //--
        return rs;
    }
    
    
    

    private String processingVocabularyMicrosoftDavidDesktop(String str, int index) {
        String rs;
        //--
        String line = UtilityString.trimSpace(str);
        line = line + ".";
        line = line.replaceAll("[\\.]+", ".");
        line = line.replace("’", "'");
        line = line.replace("?.", "?");
        line = line.replace("!.", "!");
        //--
        String lineUpdate1 = "<voice required=\"Name=Microsoft David Desktop\">?1</voice>";
        String lineUpdate1Rate = "<voice required=\"Name=Microsoft David Desktop\"><rate absspeed=\"-10\">?1</rate></voice>";
        String rate = "<rate absspeed=\"-10\">?1</rate>";
        String silence = "<silence msec=\"1000\"/>";
        String volume0 = "<volume level=\"0\">?1: </volume>";

        String newLine = "\n";
        //--
        if (index % 2 == 0) {
            rs = line + lineUpdate1.replace("?1", silence);

        } else {
            String tmp1 = lineUpdate1.replace("?1", line.replace(" ", ". ")) + newLine;
            String tmp2 = lineUpdate1.replace("?1", line) + newLine;
            String tmp3 = lineUpdate1.replace("?1", line) + newLine;
            String tmp4 = lineUpdate1.replace("?1", line + silence) + newLine;
            rs = tmp1 + tmp2 + tmp3 + tmp4;
        }
        //--
        return rs;
    }

    private void webMakeVolucation() {
        String newLine = "<button class=\"btn btn-default btn-sm btn-play postBtnplayVocabulary\" onclick=\"responsiveVoice.speak('?1')\" type=\"button\">?2</button>";

        taOutput.setText("");
        String lines[] = taInput.getText().split("\\r?\\n");
        List<String> listLines = new ArrayList<>();

        for (String line : lines) {
            line = UtilityString.trimSpace(line);
            line = line.replace("'", "’");
            line = line.replace("\"", "”");

            if (!line.isEmpty()) {
                String tmpLine = newLine;
                tmpLine = tmpLine.replace("?1", line);
                tmpLine = tmpLine.replace("?2", line);
                listLines.add(tmpLine);
            }
        }

        listLines.forEach((line) -> {
            taOutput.append(line + "\n");
        });
        taOutput.append("\n\n\n\n\n");
    }

    private void webMakeVolucationWithTranslate() {
        String newLine = "<div class=\"vocabulary\">"
                + "<button class=\"btn btn-default btnTranslate\" data-remodal-target=\"modal\" onclick=\"myTranslate(this)\" type=\"button\" value=\"Get Score\">"
                + "<spam aria-hidden=\"true\" class=\"fa fa-language\"></spam></button>"
                + "<button class=\"btn btn-default btnPlayLeft\" onclick=\"responsiveVoice.speak('?1')\" type=\"button\">?2</button></div>";

        taOutput.setText("");
        String lines[] = taInput.getText().split("\\r?\\n");
        List<String> listLines = new ArrayList<>();

        for (String line : lines) {
            line = UtilityString.trimSpace(line);
            line = line.replace("'", "’");
            line = line.replace("\"", "”");

            if (!line.isEmpty()) {
                String tmpLine = newLine;
                tmpLine = tmpLine.replace("?1", line);
                tmpLine = tmpLine.replace("?2", line);
                listLines.add(tmpLine);
            }
        }

        listLines.forEach((line) -> {
            taOutput.append(line + "\n");
        });
        taOutput.append("\n\n\n\n\n");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        btBilingual = new javax.swing.JButton();
        btConversation = new javax.swing.JButton();
        cbVoiceNgocAnh = new javax.swing.JCheckBox();
        cbVoiceDavid = new javax.swing.JCheckBox();
        cbVoiceZira = new javax.swing.JCheckBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        taInput = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        btMakeWebWord = new javax.swing.JButton();
        btEditToLines = new javax.swing.JButton();
        btMakeWebLine = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        taOutput = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        tfFolder = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        cbbVoice1 = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        cbbVoice2 = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        cbbVoice3 = new javax.swing.JComboBox<>();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        btMakevideo = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "Video"));

        jButton1.setText("Vocabulary");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btBilingual.setText("Bilingual");
        btBilingual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btBilingualActionPerformed(evt);
            }
        });

        btConversation.setText("Conversation");
        btConversation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btConversationActionPerformed(evt);
            }
        });

        cbVoiceNgocAnh.setText("Ngọc Anh");

        cbVoiceDavid.setSelected(true);
        cbVoiceDavid.setText("David");

        cbVoiceZira.setText("Zira");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btBilingual, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cbVoiceZira)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbVoiceNgocAnh)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbVoiceDavid))
                            .addComponent(btConversation, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 243, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbVoiceZira)
                    .addComponent(jButton1)
                    .addComponent(cbVoiceNgocAnh)
                    .addComponent(cbVoiceDavid))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btConversation)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btBilingual)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jScrollPane1.setBorder(javax.swing.BorderFactory.createTitledBorder("Input"));

        taInput.setColumns(20);
        taInput.setRows(5);
        jScrollPane1.setViewportView(taInput);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Website"));

        btMakeWebWord.setText("Make Word");
        btMakeWebWord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btMakeWebWordActionPerformed(evt);
            }
        });

        btEditToLines.setText("Edit to Lines");
        btEditToLines.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEditToLinesActionPerformed(evt);
            }
        });

        btMakeWebLine.setText("Make Line");
        btMakeWebLine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btMakeWebLineActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btMakeWebWord, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btMakeWebLine, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btEditToLines, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btMakeWebWord)
                    .addComponent(btEditToLines)
                    .addComponent(btMakeWebLine))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jScrollPane2.setBorder(javax.swing.BorderFactory.createTitledBorder("Output"));

        taOutput.setColumns(20);
        taOutput.setRows(5);
        jScrollPane2.setViewportView(taOutput);

        jLabel1.setText("Folder");

        tfFolder.setText("E:\\Projects\\EngLives\\Irregular Verbs\\EN");

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "Voice"));

        jLabel2.setText("1");

        jLabel3.setText("2");

        jLabel4.setText("3");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbbVoice3, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbbVoice1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbbVoice2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTextField1)
                    .addComponent(jTextField2)
                    .addComponent(jTextField3, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cbbVoice1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cbbVoice2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cbbVoice3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "Video"));

        btMakevideo.setText("Make Video");
        btMakevideo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btMakevideoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btMakevideo)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btMakevideo)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfFolder))
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(tfFolder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 289, Short.MAX_VALUE)
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        makeVideoVocabularyEn();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btMakeWebWordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btMakeWebWordActionPerformed
        webMakeVolucation();
    }//GEN-LAST:event_btMakeWebWordActionPerformed

    private void btBilingualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btBilingualActionPerformed
        makeVideoBilingual();
    }//GEN-LAST:event_btBilingualActionPerformed

    private void btEditToLinesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEditToLinesActionPerformed
        List<String> listLines = new ArrayList<>();
        String input = taInput.getText();
        taOutput.setText("");

        input = input.replace(".", ".↨");
        input = input.replace("?", "?↨");
        input = input.replaceAll("[\\n|\\r]", "↨");
        input = input.replace("'", "’");
        input = input.replace("\"", "”");          

        String lines[] = input.split("↨");
        for (String line : lines) {
            line = UtilityString.trimSpace(line);
            line = processText(line);
            if (!line.isEmpty()) {
                listLines.add(line);
            }
        }  

        listLines.forEach((line) -> {
            taOutput.append(line + "\n");
        });        
        
    }//GEN-LAST:event_btEditToLinesActionPerformed

    private void btConversationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btConversationActionPerformed
        makeVideoConversationEn();
    }//GEN-LAST:event_btConversationActionPerformed

    private void btMakevideoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btMakevideoActionPerformed
        try {
            String folderProcess = tfFolder.getText().trim();
            String videoType = "EN";
            String pathFileRoot = "";
            String pathFileEdit;
            String pathFileMp3;
            String pathFileMp4;
            List<String> dataFileRoot = new ArrayList<>();
            List<String> dataFileEdit = new ArrayList<>();
            List<String> linesEn = new ArrayList<>();
            List<String> linesVn = new ArrayList<>();
            
            if (!UtilityFileFolder.isExistsFolder(folderProcess)) {
                JOptionPane.showMessageDialog(this, "Folder don't exists!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            List<String> tmpListFiles = UtilityFileFolder.getListPathFileInFolder(folderProcess, "txt", false);
            if (tmpListFiles.size() > 0) {
                for (String file : tmpListFiles) {
                    if (file.contains("Root.txt")) {
                        pathFileRoot = file;
                        break;
                    }
                }
            }
            
            if (pathFileRoot.isEmpty() || !UtilityFileFolder.isExistsFile(pathFileRoot)) {
                JOptionPane.showMessageDialog(this, "Root file don't exists!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            pathFileEdit = pathFileRoot.replace("Root.txt", "Run.txt");
            pathFileMp3 = pathFileRoot.replace("Root.txt", "Run.mp3");
            pathFileMp4 = pathFileRoot.replace("Root.txt", "Run.mp4");
            dataFileRoot.addAll(UtilityFileFolder.readRowTextFileToListString(pathFileRoot));
            dataFileRoot.removeAll(Arrays.asList("", null));
            
            String tmpStrDataFileRoot = String.join("↨", dataFileRoot);
            if (tmpStrDataFileRoot.contains("↔")) {
                videoType = "EN;VN";
                String[] tmpArrStrDataFileRoot = tmpStrDataFileRoot.split("↔");
                linesEn.addAll(Arrays.asList(tmpArrStrDataFileRoot[0].split("↨")));
                linesVn.addAll(Arrays.asList(tmpArrStrDataFileRoot[1].replaceFirst("↨", "").split("↨")));
                if (linesEn.size() != linesVn.size()) {
                    JOptionPane.showMessageDialog(this, "Line numbers of de and vn are different!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                
                String lineEn;
                String lineVn;
                dataFileEdit.addAll(makeVideoHeader());
                for (int i = 0; i < linesEn.size(); i++) {
                    lineEn = UtilityString.trimSpace(linesEn.get(i));
                    lineVn = UtilityString.trimSpace(linesVn.get(i));
                                        
                    if (i % 2 == 0) {
                        dataFileEdit.add(addVoice(1, 0, 8, 0, lineEn));
                        dataFileEdit.add(addVoice(1, 100, 0, 0, lineEn));
                        dataFileEdit.add(addVoice(1, 0, 4, 0, lineEn));
                    } else {
                        dataFileEdit.add(addVoice(2, 0, 8, 0, lineEn));
                        dataFileEdit.add(addVoice(2, 100, 0, 0, lineEn));
                        dataFileEdit.add(addVoice(2, 0, 4, 0, lineEn));
                    }
                    
                    dataFileEdit.add(addVoice(1, 0, 8, 0, lineVn));
                    dataFileEdit.add(lineVn);
                    dataFileEdit.add(addVoice(1, 0, 8, 0, lineVn));
                }
            }
            dataFileEdit.addAll(makeVideoFooter());
            UtilityFileFolder.writeTextFileWithBufferedWriter(pathFileEdit, "UTF-8", String.join("\n", dataFileEdit), false);
            
            ProcessBuilder process = new ProcessBuilder("cmd.exe", "/c", "start", "chcp", "65001", "&", BALABOLKA, "-msq", pathFileEdit, pathFileMp3);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }

            if (p.waitFor() == 0) {
                List<String> listSrtFiles = UtilityFileFolder.getListPathFileInFolder(folderProcess, "srt", false);
                ffmpeg.convertSubSrtToAss(listSrtFiles.get(0));
                //--
                List<String> assFile = UtilityFileFolder.getListPathFileInFolder(folderProcess, "ass", false);
                List<String> assFileLines = UtilityFileFolder.readRowTextFileToListString(assFile.get(0));
                List<String> assFileLinesWrite = new ArrayList<>();

                for (String assFileLine : assFileLines) {
                    if (assFileLine.contains("PlayResX: ")) {
                        assFileLine = "PlayResX: 1920";
                    }
                    if (assFileLine.contains("PlayResY: ")) {
                        assFileLine = "PlayResY: 1080";
                    }
                    if (assFileLine.contains("Style: Default")) {
                        //-- CENTER x MID
                        assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,33,33,25,0";
                        //-- CENTER x BOTTOM
                        //assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,33,33,25,0";
                    }
                    if (assFileLine.contains("EngLives")) {
                        assFileLine = assFileLine.replace("EngLives", "{\\b1\\fs123}Eng{\\c&H0000FF&}Lives");
                    }
                    if (assFileLine.contains("\\N\\N/")) {
                        assFileLine = assFileLine.replace("\\N\\N/", "\\N\\N{\\i1\\c&HA1A1A1&\\fs90}/") + "{\\i0}";
                    }

                    assFileLinesWrite.add(assFileLine);
                }
                String assFileLinesWriteData = String.join("\n", assFileLinesWrite);
                UtilityFileFolder.writeTextFileWithBufferedWriter(assFile.get(0), "UTF-8", assFileLinesWriteData, false);

                String imgCover = folderProcess + "\\" + "cover.png";
                ffmpeg.mergeImageAndMp3ToMp4_New_1(imgCover, pathFileMp3);

                List<String> listFilesMp4 = UtilityFileFolder.getListPathFileInFolder(folderProcess, "mp4", false);
                List<String> listFilesSub = UtilityFileFolder.getListPathFileInFolder(folderProcess, "ass", false);
                ffmpeg.writeSubToVideo2(listFilesSub.get(0), listFilesMp4.get(0));
            }            
        } catch (IOException ex) {
            Logger.getLogger(English.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(English.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_btMakevideoActionPerformed

    private void btMakeWebLineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btMakeWebLineActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btMakeWebLineActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(English.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new English().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btBilingual;
    private javax.swing.JButton btConversation;
    private javax.swing.JButton btEditToLines;
    private javax.swing.JButton btMakeWebLine;
    private javax.swing.JButton btMakeWebWord;
    private javax.swing.JButton btMakevideo;
    private javax.swing.JCheckBox cbVoiceDavid;
    private javax.swing.JCheckBox cbVoiceNgocAnh;
    private javax.swing.JCheckBox cbVoiceZira;
    private javax.swing.JComboBox<String> cbbVoice1;
    private javax.swing.JComboBox<String> cbbVoice2;
    private javax.swing.JComboBox<String> cbbVoice3;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextArea taInput;
    private javax.swing.JTextArea taOutput;
    private javax.swing.JTextField tfFolder;
    // End of variables declaration//GEN-END:variables
}
