/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import object.ObjSentence;
import object.ObjWord;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import utility.UtilityFileFolder;
import utility.UtilityList;
import utility.UtilityString;
import utility.UtilityWindowsExplorerComparator;

/**
 *
 * @author bnson
 */
public class PText extends javax.swing.JFrame {

    private final String url = "jdbc:postgresql://localhost:5432/";
    private final String user = "postgres";
    private final String password = "gemdark1986!";    
    private Connection conn = null;
    
    private Gson gson;
    private List<String> output = new ArrayList<>();
    private String pathFolderProcess;
    private String pahtFileVocabularyJson;
    private String pahtFileVocabularyWebContentRaw;
    private String pahtFileVocabularyEnText;
    
    
    public PText() {
        try {
            initComponents();
            conn = connect();
            
            taInput.getDocument().addDocumentListener(new DocumentListener() {
                @Override
                public void insertUpdate(DocumentEvent e) {
                    System.out.println("insertUpdate");
                    run();
                }
                
                @Override
                public void removeUpdate(DocumentEvent e) {
                    System.out.println("removeUpdate");
                    run();
                }
                
                @Override
                public void changedUpdate(DocumentEvent e) {
                    System.out.println("changedUpdate");
                }
                
            });
        } catch (SQLException ex) {
            Logger.getLogger(PText.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void getSetting() {
        pathFolderProcess = tfPathFolderProcess.getText().trim();
        pahtFileVocabularyJson = pathFolderProcess + "\\vocabulary.json";
        pahtFileVocabularyEnText = pathFolderProcess + "\\vocabulary_en.txt";
        pahtFileVocabularyWebContentRaw = pathFolderProcess + "\\vocabulary_web_content_raw.txt";
                
        output.clear();
        output.addAll(Arrays.asList(StringUtils.stripAll(taInput.getText().split("[\\r\\n]"))));
        output.removeAll(Collections.singleton(null));
        output.removeAll(Collections.singleton(""));
        
    }
    
    private Connection connect() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }
    
    private ObjWord getVocabularyFromDictEnVn(String vocabulary) {
        ObjWord rs = new ObjWord();
        try {
            //conn = connect();

            PreparedStatement st = conn.prepareStatement("select * from ehosito.dictionary_en_vn where en = ? limit 1");
            st.setString(1, vocabulary);
            ResultSet resultSet = st.executeQuery();
            while (resultSet.next()) {
                rs.setEn(resultSet.getString(1));
                rs.setClasses(resultSet.getString(2));
                rs.setPronounceUk(resultSet.getString(3));
                rs.setPronounceUs(resultSet.getString(4));
                rs.setVn(resultSet.getString(7));
            }
            
            resultSet.close();
            st.close();
            //conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(PText.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return rs;
    }
    
    private boolean vocabularyIsExists(String vocabulary) {
        try {
            //conn = connect();

            PreparedStatement st = conn.prepareStatement("select 1 from ehosito.dictionary_en_vn where en = ? limit 1");
            st.setString(1, vocabulary);
            ResultSet resultSet = st.executeQuery();
            while (resultSet.isBeforeFirst()) {
                return true;
            }
            resultSet.close();
            st.close();
            //conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(PText.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }    

    private void insertDictionaryEnVn(List<ObjWord> objWordsList) {
        String SQL = "INSERT INTO ehosito.dictionary_en_vn(en, classes, pronounce_uk, pronounce_us, vn) "
                + "VALUES(?, ?, ?, ?, ?) on conflict (en) do nothing;";
        try {
            //Connection conn = connect();
            PreparedStatement statement = conn.prepareStatement(SQL);
            int count = 0;

            for (ObjWord objWords : objWordsList) {
                statement.setString(1, objWords.getEn());
                statement.setString(2, String.join("↨", objWords.getClasses()));
                statement.setString(3, String.join("↨", objWords.getPronounceUk()));
                statement.setString(4, String.join("↨", objWords.getPronounceUs()));
                statement.setString(5, String.join("↨", objWords.getVn()));

                statement.addBatch();
                count++;
                // execute every 100 rows or less
                if (count % 100 == 0 || count == objWordsList.size()) {
                    statement.executeBatch();
                }
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    private String getTranslateVn(String vocabulary) {
        String translateVn = "";
        try {
            String referrerLink = "https://translate.google.com/";
            String link = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=vi&dt=t&q=" + vocabulary;
            System.out.println("link: " + link);
            Document doc = Jsoup.connect(link)
                    .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36")
                    .referrer(referrerLink)
                    .ignoreContentType(true)
                    .timeout(10000)
                    .header("content-type", "application/json")
                    .get();

            translateVn = doc.text();
            
        } catch (IOException ex) {
            Logger.getLogger(EnglishV1.class.getName()).log(Level.SEVERE, null, ex);
        }
        return translateVn;
    }    
    
    
    
    private String getVocabularyFromCambride(String vocabulary) {
        String rs = "";
        String workClasses = "";
        String pronounceUk = "";
        String pronounceUs = "";

        try {
            Document doc = Jsoup.connect("https://dictionary.cambridge.org/dictionary/english/" + vocabulary).get();
            
            Element eWorkClasses = doc.select("div[class=posgram dpos-g hdib lmr-5] > span[class=pos dpos]").first();
            if (eWorkClasses != null) {
                workClasses = eWorkClasses.text();
            } else {
                //System.out.println("NULL");
            }

            Element ePronounceUk = doc.select("span[class=uk dpron-i ] > span[class=pron dpron]").first();
            if (ePronounceUk != null) {
                pronounceUk = ePronounceUk.text();
            } else {
                //System.out.println("NULL");
            }

            Element ePronounceUs = doc.select("span[class=us dpron-i ] > span[class=pron dpron]").first();
            if (ePronounceUs != null) {
                pronounceUs = ePronounceUs.text();
            } else {
                //System.out.println("NULL");
            }

            rs = workClasses + "↨" + pronounceUk + "↨" + pronounceUs;
            
            System.out.println("Vocabulary: " + vocabulary + "↨" + rs);

        } catch (IOException ex) {
            pronounceUs = "";
            Logger.getLogger(PText.class.getName()).log(Level.SEVERE, null, ex);
        }

        return rs;
    }    
    
    private List<String> convertToWords(String text) {
        List<String> rs = new ArrayList<>();
        List<String> lines = new ArrayList<>();
        
        lines.addAll(Arrays.asList(StringUtils.stripAll(text.split("[\\r\\n]"))));
        for (String line : lines) {
            ObjSentence objSentence = new ObjSentence(line);
            rs.addAll(objSentence.getEnWords());
        }
        
        rs = rs.stream().map(s -> s.replaceAll("[ |\\.|,|\"|:|;]", "")).collect(Collectors.toList());
        Collections.sort(rs, new UtilityWindowsExplorerComparator());

        //-- CLEAR DATA
        rs.removeAll(Collections.singleton(null));
        rs.removeAll(Collections.singleton(""));
        UtilityList.removeDuplication(rs);         

        return rs;
    }
    
    private void run() {
        if (!rbModeProcess.isSelected()) {
            getSetting();

            if (rbModeWord.isSelected()) {
                output.clear();
                output.addAll(Arrays.asList(StringUtils.stripAll(taInput.getText().toLowerCase().split("[\\s\\r\\n]"))));
                output = output.stream().map(s -> s.replaceAll("[ |\\.|,|\"|:|;]", "")).collect(Collectors.toList());
            }

            if (cbRemoveOrdinal.isSelected()) {
                output = output.stream().map(s -> s.replaceAll("^\\d+\\.", "")).collect(Collectors.toList());
            }

            if (cbRemoveTextInRoundBrackets.isSelected()) {
                output = output.stream().map(s -> s.replaceAll("\\(.*?\\)","")).collect(Collectors.toList());
            }

            if (!tfFind.getText().trim().isEmpty()) {
                String find = tfFind.getText().trim();
                String replace = tfReplace.getText().trim();
                output = output.stream().map(s -> s.replaceAll(find, replace)).collect(Collectors.toList());
            }

            if (cbSortByAlphabet.isSelected()) {
                //Collections.sort(output);
                //Collections.sort(output, Comparator.comparingInt(String::length));
                Collections.sort(output, new UtilityWindowsExplorerComparator());
                //Collections.reverse(output);            
            }        


            clearData(output);

            output = output.stream().map(s -> s.replaceAll("\\s+"," ").trim()).collect(Collectors.toList());
            taOutput.setText(StringUtils.join(output, "\n"));                  
        }
           
        
    }
    
    private void clearData(List<String> list) {
        //-- CLEAR DATA
        list.removeAll(Collections.singleton(null));
        list.removeAll(Collections.singleton(""));
        UtilityList.removeDuplication(list);
    }
    
    private void updateWordToDictionaryEnVn(List<ObjWord> objWordsList) {
        String SQL = "UPDATE ehosito.dictionary_en_vn SET classes = ?, pronounce_uk = ?, pronounce_us = ? WHERE en = ?;";
        try {
            //Connection conn = connect();
            PreparedStatement statement = conn.prepareStatement(SQL);
            int count = 0;

            for (ObjWord objWords : objWordsList) {
                statement.setString(1, String.join("↨", objWords.getClasses()));
                statement.setString(2, String.join("↨", objWords.getPronounceUk()));
                statement.setString(3, String.join("↨", objWords.getPronounceUs()));
                statement.setString(4, objWords.getEn());

                statement.addBatch();
                count++;
                // execute every 100 rows or less
                if (count % 100 == 0 || count == objWordsList.size()) {
                    statement.executeBatch();
                }
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }        
    }
        
    
    private void getWordNeedProcessOnDictionaryEnVn(List<ObjWord> listWordNeedProcess) {
        try {
            String query = "select * from ehosito.dictionary_en_vn "
                                + "where classes != 'proper nouns' and (classes = '' or pronounce_uk = '' or pronounce_us = '' or vn = '')";
            PreparedStatement st = conn.prepareStatement(query);
            ResultSet resultSet = st.executeQuery();
            
            while (resultSet.next()) {
                ObjWord objWord = new ObjWord();
                objWord.setEn(resultSet.getString(1));
                objWord.setClasses(resultSet.getString(2));
                objWord.setPronounceUk(resultSet.getString(3));
                objWord.setPronounceUs(resultSet.getString(4));
                objWord.setVn(resultSet.getString(7));
                
                listWordNeedProcess.add(objWord);
            }
            
            resultSet.close();
            st.close();
            //conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(PText.class.getName()).log(Level.SEVERE, null, ex);
        }
   
    }
    
    private List<String> processVocabulary() {
        List<String> rs = new ArrayList<>();
        List<ObjWord> listObjWord = new ArrayList<>();
        
        try {
            List<String> words = convertToWords(taInput.getText().trim());
            clearData(words);

            List<String> wordsProcess = new ArrayList<>(words);
            UtilityFileFolder.writeTextFileWithBufferedWriter(pahtFileVocabularyEnText, "UTF-8", StringUtils.join(words, "\n"), false);

            //== Find vocabulary on local database if exists then remove.
            for (String vocabulary : words) {
                if (vocabularyIsExists(vocabulary)) {
                    wordsProcess.remove(vocabulary);
                }                
            }
            clearData(wordsProcess);

            //== Find vocabulary on internet.
            if (!wordsProcess.isEmpty()) {
                String translate = StringUtils.join(wordsProcess, ". ") + ".";
                translate = getTranslateVn(translate);
                //System.out.println("translate: " + translate);
                JSONArray objArrs = new JSONArray(translate).getJSONArray(0);

                for (int i = 0; i < objArrs.length(); i++) {
                    ObjWord objWord = new ObjWord();
                    JSONArray objArr = objArrs.getJSONArray(i);
                    System.out.print("" + objArr.get(1).toString());
                    System.out.print("↨" + objArr.get(0).toString());

                    String enWord = UtilityString.trimSpace(objArr.get(1).toString());
                    enWord = enWord.replaceAll("[ |\\.|,|\"|:|;]", "").trim();

                    String vnWord = UtilityString.trimSpace(objArr.get(0).toString());
                    vnWord = vnWord.replaceAll("[ |\\.]", " ");
                    vnWord = vnWord.replaceAll("\\s+", " ").trim().toLowerCase();

                    objWord.setEn(enWord);
                    objWord.getVn().add(vnWord);

                    String[] arrTmp = getVocabularyFromCambride(enWord).split("↨", -1);
                    if (arrTmp.length == 3) {
                        objWord.getClasses().add(arrTmp[0]);
                        objWord.getPronounceUk().add(arrTmp[1]);
                        objWord.getPronounceUs().add(arrTmp[2]);
                    } else {
                        System.out.println(enWord + ": [Error] Wrong length...");
                    }

                    listObjWord.add(objWord);

                    if (i % 2 == 0) {
                        TimeUnit.SECONDS.sleep(3);
                        System.out.println("Slepping...");
                    } else {
                        TimeUnit.SECONDS.sleep(2);
                        System.out.println("Slepping...");
                    }
                }

                if (listObjWord.size() > 0) {
                    insertDictionaryEnVn(listObjWord);
                }
            }
            
            listObjWord.clear();
            
            for (String vocabulary : words) {
                ObjWord tmpObjWord = getVocabularyFromDictEnVn(vocabulary);
                listObjWord.add(tmpObjWord);
                rs.add(tmpObjWord.getDataForWebContentRaw());
            }
         
            //===
            //taOutput.setText(StringUtils.join(rs, "\n"));            
            
            //===
            gson = new GsonBuilder().setPrettyPrinting().create();
            String jsonData = gson.toJson(listObjWord);
            UtilityFileFolder.writeTextFileWithBufferedWriter(pahtFileVocabularyJson, "UTF-8", jsonData, false);
            UtilityFileFolder.writeTextFileWithBufferedWriter(pahtFileVocabularyWebContentRaw, "UTF-8", StringUtils.join(rs, "\n"), false);

        } catch (InterruptedException ex) {
            Logger.getLogger(PText.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return rs;
    }
    
    private void processWordOnDictionaryEnVn() {
        List<ObjWord> listWordNeedProcess = new ArrayList<>();
        getWordNeedProcessOnDictionaryEnVn(listWordNeedProcess);
        
        if(!listWordNeedProcess.isEmpty()) {
            
            for (int i = 0; i < listWordNeedProcess.size(); i++) {
                if (!listWordNeedProcess.get(i).getEn().trim().contains(" ")) {
                    System.out.println("== " + listWordNeedProcess.get(i).getEn());
                    if (listWordNeedProcess.get(i).getClasses().isEmpty() || listWordNeedProcess.get(i).getPronounceUk().isEmpty() || listWordNeedProcess.get(i).getPronounceUs().isEmpty()) {

                        String[] arrTmp = getVocabularyFromCambride(listWordNeedProcess.get(i).getEn()).split("↨", -1);
                        if (arrTmp.length == 3) {
                            if (listWordNeedProcess.get(i).getClasses().isEmpty()) {
                                listWordNeedProcess.get(i).getClasses().add(0, arrTmp[0]);
                            }

                            if (listWordNeedProcess.get(i).getPronounceUk().isEmpty()) {
                                listWordNeedProcess.get(i).getPronounceUk().add(0, arrTmp[1]);
                            }

                            if (listWordNeedProcess.get(i).getPronounceUs().isEmpty()) {
                                listWordNeedProcess.get(i).getPronounceUs().add(0, arrTmp[2]);
                            }

                        } else {
                            System.out.println(listWordNeedProcess.get(i).getEn() + ": [Error] Wrong length...");
                        }

                    }
                } else {
                    String[] tmpWords = listWordNeedProcess.get(i).getEn().trim().split(" ");
                    String tmpWordsClass = "";
                    String tmpWordsPronounceUk = "";
                    String tmpWordsPronounceUs = "";
                    for (String tmpWord : tmpWords) {
                        String[] arrTmp = getVocabularyFromCambride(tmpWord).split("↨", -1);
                        if (arrTmp.length == 3) {
                            tmpWordsClass = tmpWordsClass + " " + arrTmp[0];
                            tmpWordsPronounceUk = tmpWordsPronounceUk + " " + arrTmp[1];
                            tmpWordsPronounceUs = tmpWordsPronounceUs + " " + arrTmp[2];
                        } else {
                            System.out.println("[Error] Wrong length...");
                        }
                    }

                    tmpWordsClass = UtilityString.trimSpace(tmpWordsClass);
                    tmpWordsPronounceUk = UtilityString.trimSpace(tmpWordsPronounceUk);
                    tmpWordsPronounceUs = UtilityString.trimSpace(tmpWordsPronounceUs);
                    //--
                    listWordNeedProcess.get(i).getClasses().add(UtilityString.trimSpace(tmpWordsClass));
                    listWordNeedProcess.get(i).getPronounceUk().add(UtilityString.trimSpace(tmpWordsPronounceUk));
                    listWordNeedProcess.get(i).getPronounceUs().add(UtilityString.trimSpace(tmpWordsPronounceUs));
                }

                updateWordToDictionaryEnVn(listWordNeedProcess);
            }
            
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bgMode = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        taInput = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        taOutput = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        btProcessVocabulary = new javax.swing.JButton();
        btSearch = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        cbSortByAlphabet = new javax.swing.JCheckBox();
        jPanel1 = new javax.swing.JPanel();
        cbRemoveOrdinal = new javax.swing.JCheckBox();
        cbRemoveTextInRoundBrackets = new javax.swing.JCheckBox();
        jPanel8 = new javax.swing.JPanel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        rbModeWord = new javax.swing.JRadioButton();
        rbModeProcess = new javax.swing.JRadioButton();
        rbModeParagraph = new javax.swing.JRadioButton();
        rbProcessDatabase = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        tfFind = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        tfReplace = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        lbPathFolderProcess = new javax.swing.JLabel();
        tfPathFolderProcess = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        taInput.setColumns(20);
        taInput.setRows(5);
        jScrollPane1.setViewportView(taInput);

        taOutput.setColumns(20);
        taOutput.setRows(5);
        taOutput.setText("<h4><b><u>ĐOẠN VĂN</u></b>\n$1\n\n<br>\n<hr1>\n<h4><b><u>TỪ VỰNG</u></b>\n$2");
        jScrollPane2.setViewportView(taOutput);

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btProcessVocabulary.setText("Process");
        btProcessVocabulary.setToolTipText("");
        btProcessVocabulary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btProcessVocabularyActionPerformed(evt);
            }
        });

        btSearch.setText("Search");
        btSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btProcessVocabulary)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btSearch)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btProcessVocabulary)
                    .addComponent(btSearch))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Sort"));

        cbSortByAlphabet.setText("Sort by alphabet");
        cbSortByAlphabet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbSortByAlphabetActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cbSortByAlphabet)
                .addContainerGap(10, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cbSortByAlphabet)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Remove"));

        cbRemoveOrdinal.setText("Remove ordinal");
        cbRemoveOrdinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbRemoveOrdinalActionPerformed(evt);
            }
        });

        cbRemoveTextInRoundBrackets.setText("Remove text in round brackets");
        cbRemoveTextInRoundBrackets.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbRemoveTextInRoundBracketsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbRemoveOrdinal)
                    .addComponent(cbRemoveTextInRoundBrackets))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cbRemoveOrdinal)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cbRemoveTextInRoundBrackets)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder("Template"));

        jRadioButton1.setSelected(true);
        jRadioButton1.setText("Essay & Vocabulary");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jRadioButton1)
                .addContainerGap(87, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jRadioButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Mode"));

        bgMode.add(rbModeWord);
        rbModeWord.setText("Word");
        rbModeWord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbModeWordActionPerformed(evt);
            }
        });

        bgMode.add(rbModeProcess);
        rbModeProcess.setSelected(true);
        rbModeProcess.setText("Process");

        bgMode.add(rbModeParagraph);
        rbModeParagraph.setText("Paragraph");

        bgMode.add(rbProcessDatabase);
        rbProcessDatabase.setText("Database");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(rbModeProcess)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rbModeParagraph))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(rbProcessDatabase)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(rbModeWord)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbModeProcess)
                    .addComponent(rbModeParagraph))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbProcessDatabase)
                    .addComponent(rbModeWord))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Find & Replace"));

        jLabel1.setText("Find");

        jLabel2.setText("Replace");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tfFind)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(0, 193, Short.MAX_VALUE))
                    .addComponent(tfReplace))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfReplace, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lbPathFolderProcess.setText("Path Folder Process");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbPathFolderProcess)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfPathFolderProcess)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbPathFolderProcess)
                    .addComponent(tfPathFolderProcess, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2))
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 302, Short.MAX_VALUE)
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btProcessVocabularyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btProcessVocabularyActionPerformed
        getSetting();
        String inputText = taInput.getText().trim();
        String outputText = taOutput.getText().trim();

        List<String> listVocabulary = processVocabulary();
        
        outputText = outputText.replace("$1", inputText);
        outputText = outputText.replace("$2", StringUtils.join(listVocabulary, "\n"));
        taOutput.setText(outputText);
        
        

//        if (rbModeProcess.isSelected()) {
//            processWordOnInput();
//        }
//        
//        if (rbProcessDatabase.isSelected()) {
//            processWordOnDictionaryEnVn();
//        }
        
    }//GEN-LAST:event_btProcessVocabularyActionPerformed

    private void cbRemoveOrdinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbRemoveOrdinalActionPerformed
        run();
    }//GEN-LAST:event_cbRemoveOrdinalActionPerformed

    private void cbRemoveTextInRoundBracketsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbRemoveTextInRoundBracketsActionPerformed
        run();
    }//GEN-LAST:event_cbRemoveTextInRoundBracketsActionPerformed

    private void cbSortByAlphabetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbSortByAlphabetActionPerformed
        run();
    }//GEN-LAST:event_cbSortByAlphabetActionPerformed

    private void rbModeWordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbModeWordActionPerformed
        run();
    }//GEN-LAST:event_rbModeWordActionPerformed

    private void btSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSearchActionPerformed
        
        getSetting();
        try {
            List<String> inputData = new ArrayList<>();
            List<String> outData = new ArrayList<>();
            inputData.addAll(Arrays.asList(StringUtils.stripAll(taInput.getText().split("[\\r\\n]"))));

            for (String tmpData : inputData) {

                System.out.println("tmpData: " + tmpData);
                ObjWord objWord = (ObjWord) getVocabularyFromDictEnVn(tmpData).clone();
                taOutput.append(objWord.getEn() + "↨" + objWord.getClasses().get(0) + "↨" + objWord.getVn().get(0) + "↨" + objWord.getPronounceUk().get(0) + "\n");

            }
        } catch (CloneNotSupportedException ex) {
            Logger.getLogger(PText.class.getName()).log(Level.SEVERE, null, ex);
        }       
        
    }//GEN-LAST:event_btSearchActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PText.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PText.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PText.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PText.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new PText().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup bgMode;
    private javax.swing.JButton btProcessVocabulary;
    private javax.swing.JButton btSearch;
    private javax.swing.JCheckBox cbRemoveOrdinal;
    private javax.swing.JCheckBox cbRemoveTextInRoundBrackets;
    private javax.swing.JCheckBox cbSortByAlphabet;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbPathFolderProcess;
    private javax.swing.JRadioButton rbModeParagraph;
    private javax.swing.JRadioButton rbModeProcess;
    private javax.swing.JRadioButton rbModeWord;
    private javax.swing.JRadioButton rbProcessDatabase;
    private javax.swing.JTextArea taInput;
    private javax.swing.JTextArea taOutput;
    private javax.swing.JTextField tfFind;
    private javax.swing.JTextField tfPathFolderProcess;
    private javax.swing.JTextField tfReplace;
    // End of variables declaration//GEN-END:variables
}
