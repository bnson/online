/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author bnson
 */
public class AutoRobot {

    private Robot robot;
    private int delayStart;
    private int delayCharacter;
    
    public AutoRobot() {
        try {
            robot = new Robot();  
            delayStart = 4000;
            delayCharacter = 100;
        } catch (AWTException ex) {
            Logger.getLogger(AutoRobot.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }

    public int getDelayStart() {
        return delayStart;
    }

    public void setDelayStart(int delayStart) {
        this.delayStart = delayStart;
    }

    public int getDelayCharacter() {
        return delayCharacter;
    }

    public void setDelayCharacter(int delayCharacter) {
        this.delayCharacter = delayCharacter;
    }

    public void typeText(String str) {
        char[] arrCharacter = str.toCharArray();
        robot.delay(delayStart);
        for (char character : arrCharacter) {
            robot.delay(delayCharacter);
            typeCharacter(character);
        }
    }
    
    private void typeCharacter(char character) {
        switch (character) {
            case 'a': doTypeCharacter(KeyEvent.VK_A); break;
            case 'b': doTypeCharacter(KeyEvent.VK_B); break;
            case 'c': doTypeCharacter(KeyEvent.VK_C); break;
            case 'd': doTypeCharacter(KeyEvent.VK_D); break;
            case 'e': doTypeCharacter(KeyEvent.VK_E); break;
            case 'f': doTypeCharacter(KeyEvent.VK_F); break;
            case 'g': doTypeCharacter(KeyEvent.VK_G); break;
            case 'h': doTypeCharacter(KeyEvent.VK_H); break;
            case 'i': doTypeCharacter(KeyEvent.VK_I); break;
            case 'j': doTypeCharacter(KeyEvent.VK_J); break;
            case 'k': doTypeCharacter(KeyEvent.VK_K); break;
            case 'l': doTypeCharacter(KeyEvent.VK_L); break;
            case 'm': doTypeCharacter(KeyEvent.VK_M); break;
            case 'n': doTypeCharacter(KeyEvent.VK_N); break;
            case 'o': doTypeCharacter(KeyEvent.VK_O); break;
            case 'p': doTypeCharacter(KeyEvent.VK_P); break;
            case 'q': doTypeCharacter(KeyEvent.VK_Q); break;
            case 'r': doTypeCharacter(KeyEvent.VK_R); break;
            case 's': doTypeCharacter(KeyEvent.VK_S); break;
            case 't': doTypeCharacter(KeyEvent.VK_T); break;
            case 'u': doTypeCharacter(KeyEvent.VK_U); break;
            case 'v': doTypeCharacter(KeyEvent.VK_V); break;
            case 'w': doTypeCharacter(KeyEvent.VK_W); break;
            case 'x': doTypeCharacter(KeyEvent.VK_X); break;
            case 'y': doTypeCharacter(KeyEvent.VK_Y); break;
            case 'z': doTypeCharacter(KeyEvent.VK_Z); break;
            case 'A': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_A); break;
            case 'B': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_B); break;
            case 'C': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_C); break;
            case 'D': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_D); break;
            case 'E': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_E); break;
            case 'F': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_F); break;
            case 'G': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_G); break;
            case 'H': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_H); break;
            case 'I': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_I); break;
            case 'J': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_J); break;
            case 'K': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_K); break;
            case 'L': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_L); break;
            case 'M': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_M); break;
            case 'N': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_N); break;
            case 'O': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_O); break;
            case 'P': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_P); break;
            case 'Q': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_Q); break;
            case 'R': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_R); break;
            case 'S': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_S); break;
            case 'T': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_T); break;
            case 'U': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_U); break;
            case 'V': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_V); break;
            case 'W': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_W); break;
            case 'X': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_X); break;
            case 'Y': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_Y); break;
            case 'Z': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_Z); break;
            case '`': doTypeCharacter(KeyEvent.VK_BACK_QUOTE); break;
            case '0': doTypeCharacter(KeyEvent.VK_0); break;
            case '1': doTypeCharacter(KeyEvent.VK_1); break;
            case '2': doTypeCharacter(KeyEvent.VK_2); break;
            case '3': doTypeCharacter(KeyEvent.VK_3); break;
            case '4': doTypeCharacter(KeyEvent.VK_4); break;
            case '5': doTypeCharacter(KeyEvent.VK_5); break;
            case '6': doTypeCharacter(KeyEvent.VK_6); break;
            case '7': doTypeCharacter(KeyEvent.VK_7); break;
            case '8': doTypeCharacter(KeyEvent.VK_8); break;
            case '9': doTypeCharacter(KeyEvent.VK_9); break;
            case '-': doTypeCharacter(KeyEvent.VK_MINUS); break;
            case '=': doTypeCharacter(KeyEvent.VK_EQUALS); break;
            case '~': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_BACK_QUOTE); break;
            case '!': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_1); break;
            case '@': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_2); break;
            case '#': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_3); break;
            case '$': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_4); break;
            case '%': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_5); break;
            case '^': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_6); break;
            case '&': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_7); break;
            case '*': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_8); break;
            case '(': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_9); break;
            case ')': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_0); break;
            case '_': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_MINUS); break;
            case '+': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_EQUALS); break;
            case '\t': doTypeCharacter(KeyEvent.VK_TAB); break;
            case '\n': doTypeCharacter(KeyEvent.VK_ENTER); break;
            case '[': doTypeCharacter(KeyEvent.VK_OPEN_BRACKET); break;
            case ']': doTypeCharacter(KeyEvent.VK_CLOSE_BRACKET); break;
            case '\\': doTypeCharacter(KeyEvent.VK_BACK_SLASH); break;
            case '{': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent. VK_OPEN_BRACKET); break;
            case '}': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent. VK_CLOSE_BRACKET); break;
            //case '}': doTypeCharacter(KeyEvent.VK_DOWN); break;
            case '|': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent. VK_BACK_SLASH); break;
            case ':': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_SEMICOLON); break;
            case '"': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_QUOTE); break;
            case '<': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_COMMA); break;
            case '>': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_PERIOD); break;
            case '?': doTypeCharacter(KeyEvent.VK_SHIFT, KeyEvent.VK_SLASH); break;
            case ';': doTypeCharacter(KeyEvent.VK_SEMICOLON); break;
            case '\'': doTypeCharacter(KeyEvent.VK_QUOTE); break;
            case ',': doTypeCharacter(KeyEvent.VK_COMMA); break;
            case '.': doTypeCharacter(KeyEvent.VK_PERIOD); break;
            case '/': doTypeCharacter(KeyEvent.VK_SLASH); break;
            case ' ': doTypeCharacter(KeyEvent.VK_SPACE); break;
            default: throw new IllegalArgumentException("Cannot type character " + character);
        }
    }    

    private void doTypeCharacter(int... keyCodes) {
        for (int i = 0; i < keyCodes.length; i++) {
            robot.keyPress(keyCodes[i]);
        }
        for (int i = 0; i < keyCodes.length; i++) {
            robot.keyRelease(keyCodes[i]);
        }        
    }    

    public String getKeyText(int keyCode) {
        if (keyCode >= KeyEvent.VK_0 && keyCode <= KeyEvent.VK_9
                || keyCode >= KeyEvent.VK_A && keyCode <= KeyEvent.VK_Z) {
            return String.valueOf((char) keyCode);
        }

        switch (keyCode) {
            case KeyEvent.VK_COMMA:
                return "COMMA";
            case KeyEvent.VK_PERIOD:
                return "PERIOD";
            case KeyEvent.VK_SLASH:
                return "SLASH";
            case KeyEvent.VK_SEMICOLON:
                return "SEMICOLON";
            case KeyEvent.VK_EQUALS:
                return "EQUALS";
            case KeyEvent.VK_OPEN_BRACKET:
                return "OPEN_BRACKET";
            case KeyEvent.VK_BACK_SLASH:
                return "BACK_SLASH";
            case KeyEvent.VK_CLOSE_BRACKET:
                return "CLOSE_BRACKET";

            case KeyEvent.VK_ENTER:
                return "ENTER";
            case KeyEvent.VK_BACK_SPACE:
                return "BACK_SPACE";
            case KeyEvent.VK_TAB:
                return "TAB";
            case KeyEvent.VK_CANCEL:
                return "CANCEL";
            case KeyEvent.VK_CLEAR:
                return "CLEAR";
            case KeyEvent.VK_SHIFT:
                return "SHIFT";
            case KeyEvent.VK_CONTROL:
                return "CONTROL";
            case KeyEvent.VK_ALT:
                return "ALT";
            case KeyEvent.VK_PAUSE:
                return "PAUSE";
            case KeyEvent.VK_CAPS_LOCK:
                return "CAPS_LOCK";
            case KeyEvent.VK_ESCAPE:
                return "ESCAPE";
            case KeyEvent.VK_SPACE:
                return "SPACE";
            case KeyEvent.VK_PAGE_UP:
                return "PAGE_UP";
            case KeyEvent.VK_PAGE_DOWN:
                return "PAGE_DOWN";
            case KeyEvent.VK_END:
                return "END";
            case KeyEvent.VK_HOME:
                return "HOME";
            case KeyEvent.VK_LEFT:
                return "LEFT";
            case KeyEvent.VK_UP:
                return "UP";
            case KeyEvent.VK_RIGHT:
                return "RIGHT";
            case KeyEvent.VK_DOWN:
                return "DOWN";

            // numpad numeric keys handled below
            case KeyEvent.VK_MULTIPLY:
                return "MULTIPLY";
            case KeyEvent.VK_ADD:
                return "ADD";
            case KeyEvent.VK_SEPARATOR:
                return "SEPARATOR";
            case KeyEvent.VK_SUBTRACT:
                return "SUBTRACT";
            case KeyEvent.VK_DECIMAL:
                return "DECIMAL";
            case KeyEvent.VK_DIVIDE:
                return "DIVIDE";
            case KeyEvent.VK_DELETE:
                return "DELETE";
            case KeyEvent.VK_NUM_LOCK:
                return "NUM_LOCK";
            case KeyEvent.VK_SCROLL_LOCK:
                return "SCROLL_LOCK";

            case KeyEvent.VK_F1:
                return "F1";
            case KeyEvent.VK_F2:
                return "F2";
            case KeyEvent.VK_F3:
                return "F3";
            case KeyEvent.VK_F4:
                return "F4";
            case KeyEvent.VK_F5:
                return "F5";
            case KeyEvent.VK_F6:
                return "F6";
            case KeyEvent.VK_F7:
                return "F7";
            case KeyEvent.VK_F8:
                return "F8";
            case KeyEvent.VK_F9:
                return "F9";
            case KeyEvent.VK_F10:
                return "F10";
            case KeyEvent.VK_F11:
                return "F11";
            case KeyEvent.VK_F12:
                return "F12";
            case KeyEvent.VK_F13:
                return "F13";
            case KeyEvent.VK_F14:
                return "F14";
            case KeyEvent.VK_F15:
                return "F15";
            case KeyEvent.VK_F16:
                return "F16";
            case KeyEvent.VK_F17:
                return "F17";
            case KeyEvent.VK_F18:
                return "F18";
            case KeyEvent.VK_F19:
                return "F19";
            case KeyEvent.VK_F20:
                return "F20";
            case KeyEvent.VK_F21:
                return "F21";
            case KeyEvent.VK_F22:
                return "F22";
            case KeyEvent.VK_F23:
                return "F23";
            case KeyEvent.VK_F24:
                return "F24";

            case KeyEvent.VK_PRINTSCREEN:
                return "PRINTSCREEN";
            case KeyEvent.VK_INSERT:
                return "INSERT";
            case KeyEvent.VK_HELP:
                return "HELP";
            case KeyEvent.VK_META:
                return "META";
            case KeyEvent.VK_BACK_QUOTE:
                return "BACK_QUOTE";
            case KeyEvent.VK_QUOTE:
                return "QUOTE";

            case KeyEvent.VK_KP_UP:
                return "KP_UP";
            case KeyEvent.VK_KP_DOWN:
                return "KP_DOWN";
            case KeyEvent.VK_KP_LEFT:
                return "KP_LEFT";
            case KeyEvent.VK_KP_RIGHT:
                return "KP_RIGHT";

            case KeyEvent.VK_DEAD_GRAVE:
                return "DEAD_GRAVE";
            case KeyEvent.VK_DEAD_ACUTE:
                return "DEAD_ACUTE";
            case KeyEvent.VK_DEAD_CIRCUMFLEX:
                return "DEAD_CIRCUMFLEX";
            case KeyEvent.VK_DEAD_TILDE:
                return "DEAD_TILDE";
            case KeyEvent.VK_DEAD_MACRON:
                return "DEAD_MACRON";
            case KeyEvent.VK_DEAD_BREVE:
                return "DEAD_BREVE";
            case KeyEvent.VK_DEAD_ABOVEDOT:
                return "DEAD_ABOVEDOT";
            case KeyEvent.VK_DEAD_DIAERESIS:
                return "DEAD_DIAERESIS";
            case KeyEvent.VK_DEAD_ABOVERING:
                return "DEAD_ABOVERING";
            case KeyEvent.VK_DEAD_DOUBLEACUTE:
                return "DEAD_DOUBLEACUTE";
            case KeyEvent.VK_DEAD_CARON:
                return "DEAD_CARON";
            case KeyEvent.VK_DEAD_CEDILLA:
                return "DEAD_CEDILLA";
            case KeyEvent.VK_DEAD_OGONEK:
                return "DEAD_OGONEK";
            case KeyEvent.VK_DEAD_IOTA:
                return "DEAD_IOTA";
            case KeyEvent.VK_DEAD_VOICED_SOUND:
                return "DEAD_VOICED_SOUND";
            case KeyEvent.VK_DEAD_SEMIVOICED_SOUND:
                return "DEAD_SEMIVOICED_SOUND";

            case KeyEvent.VK_AMPERSAND:
                return "AMPERSAND";
            case KeyEvent.VK_ASTERISK:
                return "ASTERISK";
            case KeyEvent.VK_QUOTEDBL:
                return "QUOTEDBL";
            case KeyEvent.VK_LESS:
                return "LESS";
            case KeyEvent.VK_GREATER:
                return "GREATER";
            case KeyEvent.VK_BRACELEFT:
                return "BRACELEFT";
            case KeyEvent.VK_BRACERIGHT:
                return "BRACERIGHT";
            case KeyEvent.VK_AT:
                return "AT";
            case KeyEvent.VK_COLON:
                return "COLON";
            case KeyEvent.VK_CIRCUMFLEX:
                return "CIRCUMFLEX";
            case KeyEvent.VK_DOLLAR:
                return "DOLLAR";
            case KeyEvent.VK_EURO_SIGN:
                return "EURO_SIGN";
            case KeyEvent.VK_EXCLAMATION_MARK:
                return "EXCLAMATION_MARK";
            case KeyEvent.VK_INVERTED_EXCLAMATION_MARK:
                return "INVERTED_EXCLAMATION_MARK";
            case KeyEvent.VK_LEFT_PARENTHESIS:
                return "LEFT_PARENTHESIS";
            case KeyEvent.VK_NUMBER_SIGN:
                return "NUMBER_SIGN";
            case KeyEvent.VK_MINUS:
                return "MINUS";
            case KeyEvent.VK_PLUS:
                return "PLUS";
            case KeyEvent.VK_RIGHT_PARENTHESIS:
                return "RIGHT_PARENTHESIS";
            case KeyEvent.VK_UNDERSCORE:
                return "UNDERSCORE";

            case KeyEvent.VK_FINAL:
                return "FINAL";
            case KeyEvent.VK_CONVERT:
                return "CONVERT";
            case KeyEvent.VK_NONCONVERT:
                return "NONCONVERT";
            case KeyEvent.VK_ACCEPT:
                return "ACCEPT";
            case KeyEvent.VK_MODECHANGE:
                return "MODECHANGE";
            case KeyEvent.VK_KANA:
                return "KANA";
            case KeyEvent.VK_KANJI:
                return "KANJI";
            case KeyEvent.VK_ALPHANUMERIC:
                return "ALPHANUMERIC";
            case KeyEvent.VK_KATAKANA:
                return "KATAKANA";
            case KeyEvent.VK_HIRAGANA:
                return "HIRAGANA";
            case KeyEvent.VK_FULL_WIDTH:
                return "FULL_WIDTH";
            case KeyEvent.VK_HALF_WIDTH:
                return "HALF_WIDTH";
            case KeyEvent.VK_ROMAN_CHARACTERS:
                return "ROMAN_CHARACTERS";
            case KeyEvent.VK_ALL_CANDIDATES:
                return "ALL_CANDIDATES";
            case KeyEvent.VK_PREVIOUS_CANDIDATE:
                return "PREVIOUS_CANDIDATE";
            case KeyEvent.VK_CODE_INPUT:
                return "CODE_INPUT";
            case KeyEvent.VK_JAPANESE_KATAKANA:
                return "JAPANESE_KATAKANA";
            case KeyEvent.VK_JAPANESE_HIRAGANA:
                return "JAPANESE_HIRAGANA";
            case KeyEvent.VK_JAPANESE_ROMAN:
                return "JAPANESE_ROMAN";
            case KeyEvent.VK_KANA_LOCK:
                return "KANA_LOCK";
            case KeyEvent.VK_INPUT_METHOD_ON_OFF:
                return "INPUT_METHOD_ON_OFF";

            case KeyEvent.VK_AGAIN:
                return "AGAIN";
            case KeyEvent.VK_UNDO:
                return "UNDO";
            case KeyEvent.VK_COPY:
                return "COPY";
            case KeyEvent.VK_PASTE:
                return "PASTE";
            case KeyEvent.VK_CUT:
                return "CUT";
            case KeyEvent.VK_FIND:
                return "FIND";
            case KeyEvent.VK_PROPS:
                return "PROPS";
            case KeyEvent.VK_STOP:
                return "STOP";

            case KeyEvent.VK_COMPOSE:
                return "COMPOSE";
            case KeyEvent.VK_ALT_GRAPH:
                return "ALT_GRAPH";
        }

        if (keyCode >= KeyEvent.VK_NUMPAD0 && keyCode <= KeyEvent.VK_NUMPAD9) {
            char c = (char) (keyCode - KeyEvent.VK_NUMPAD0 + '0');
            return "NUMPAD" + c;
        }

        return "unknown(0x" + Integer.toString(keyCode, 16) + ")";
    }

}
