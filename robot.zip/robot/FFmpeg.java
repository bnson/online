/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.List;
import utility.UtilityFileFolder;

/**
 *
 * @author ASUS
 */
public class FFmpeg {
    
    private final String ffmegPath;
    
    public FFmpeg(String ffmegPath) {
        this.ffmegPath = ffmegPath;
    }
    
    
    private boolean process(ProcessBuilder processBuilder, boolean showProcess) {
        try {
            if (processBuilder != null) {
                processBuilder.redirectErrorStream(true);
                System.out.println("process: " + processBuilder.command());
                Process p = processBuilder.start();
                
                if (showProcess) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                    String line;
                    while ((line = br.readLine()) != null) {
                        System.out.println("-- " + line);
                    }
                }

                if (p.waitFor() == 0) {
                    System.out.println("-- Process done...");
                }                
                
            } else {
                return false;
            }
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFmpeg.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;          
    }
    
    
    public boolean writeSubToVideo7(String subPath, String mp4Path, String mp4SubPath, String mp4SubName) {
        System.out.println("== WRITE SUB TO VIDEO ==");
        mp4SubName = mp4SubName.replace(".", "");
        mp4SubName = mp4SubName.replace(":", " -");

        if (!mp4SubPath.endsWith("\\")) {
            mp4SubPath += "\\";
        }
        
        String pathVideoSub = mp4SubPath + mp4SubName + ".mp4";
        String subTitles = "\"subtitles=" + subPath.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
        
        ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-i", mp4Path, "-vf", subTitles, "-max_muxing_queue_size", "1920", pathVideoSub);
        return process(processBuilder, true);
    }
    
    public boolean writeSubToVideo8(String iFileAss, String iFileMp4, String iFileMp4Subtitle) {
        System.out.println("== WRITE SUB TO VIDEO ==");
        String iFileAssCmd = "\"subtitles=" + iFileAss.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
        //ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-i", iFileMp4, "-vf", iFileAssCmd, "-max_muxing_queue_size", "1920", iFileMp4Subtitle);
        ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-i", iFileMp4, "-vf", iFileAssCmd, "-c:v", "libx264", "-crf", "0", "-preset", "veryfast", "-tune", "stillimage", "-c:a", "copy", "-shortest", iFileMp4Subtitle);
        return process(processBuilder, true);
    }    
    

    
    public boolean mergeMp3AndMp4ToMp4RepeatMp4(String iPathMp3, String iPathMp4, String oPathMp4) {
        //-- CMD 001: ffmpeg -stream_loop -1 -i input.mp4 -i input.mp3 -shortest -map 0:v:0 -map 1:a:0 -y out.mp4
        //ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-stream_loop", "-1", "-i", iPathMp4, "-i", iPathMp3, "-shortest", "-map", "0:v:0", "-map", "1:a:0", "-y", oPathMp4);
        
        //-- CMD 002: ffmpeg -stream_loop -1 -i input.mp4 -i input.mp3 -shortest -map 0:v:0 -map 1:a:0 -y out.mp4
        //-- ffmpeg -y -stream_loop -1 -i video -i audio.mp3 -fflags +shortest -max_interleave_delta 50000 -c copy output.mp4
        //-- ffmpeg -stream_loop -1 -i 1.mp4 -c copy -v 0 -f nut - | ffmpeg -thread_queue_size 10K -i - -i 1.mp3 -c copy -map 0:v -map 1:a -shortest -y out.mp4
        ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-stream_loop", "-1", "-i", iPathMp4, "-i", iPathMp3, "-c", "copy", "-shortest", oPathMp4);
        
        return process(processBuilder, true);
    }   
    
    public boolean mergeMp3AndMp4ToMp4RepeatMp3(String iPathMp3, String iPathMp4, String oPathMp4) {
        //-- CMD 001: ffmpeg -i input.mp4 -stream_loop -1 -i input.mp3 -shortest -map 0:v:0 -map 1:a:0 -y out.mp4
        ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-i", iPathMp4, "-stream_loop", "-1", "-i", iPathMp3, "-shortest", "-map", "0:v:0", "-map", "1:a:0", "-y", oPathMp4);
        return process(processBuilder, false);
    }       
    
    public boolean videoSmooth(String iPathMp4, String oPathMp4) {
        //-- CMD 001: ffmpeg -i input.mkv -filter:v "minterpolate='mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120'" output.mkv
        ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-i", iPathMp4, "-filter:v", "\"minterpolate='mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120'\"", oPathMp4);
        return process(processBuilder, false);
    }
    
    public boolean videoSpeedUp(String iPathMp4, String oPathMp4) {
        //-- CMD 001: ffmpeg -i TheGoodTheBadAndTheUgly.mp4 -vf  "setpts=0.25*PTS" UpTheGoodTheBadAndTheUgly.mp4
        ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-i", iPathMp4, "-vf", "\"setpts=0.25*PTS\"", oPathMp4);
        return process(processBuilder, false);
    }   
    
    public boolean videoSlowDown(String iPathMp4, String oPathMp4) {
        //-- CMD 001: ffmpeg -i TheGoodTheBadAndTheUgly.mp4 -vf  "setpts=4*PTS" DownTheGoodTheBadAndTheUgly.mp4
        ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-i", iPathMp4, "-vf", "\"setpts=4*PTS\"", oPathMp4);
        return process(processBuilder, false);
    } 
    
    public boolean removeAudioFromVideo(String iPathMp4, String oPathMp4) {
        //-- CMD 001: ffmpeg -i $input_file -c copy -an $output_file
        //-- CMD 002: ffmpeg -i $input_file -vcodec copy -an $output_file
        ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-y", "-r", "25", "-i", iPathMp4,"-c", "copy", "-an", oPathMp4);
        return process(processBuilder, true);
    } 
    
    public boolean changeFrameRate(String iPathMp4, String oPathMp4, int frameRate) {
        //-- CMD 001: ffmpeg -i $input_file -c copy -an $output_file
        //-- CMD 002: ffmpeg -i $input_file -vcodec copy -an $output_file
        ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-y", "-i", iPathMp4, "-r", String.valueOf(frameRate), oPathMp4);
        return process(processBuilder, true);
    }    
    
    public boolean resizeVideo(String iPathMp4, String oPathMp4, String scale) {
        //-- CMD 001: ffmpeg -i input.mp4 -vf scale=1280:720 -preset slow -crf 18 output.mp4
        ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-i", iPathMp4, "-vf", "scale=" + scale, oPathMp4);
        return process(processBuilder, true);
    }
    
    public boolean combineMultipleMp3(String directory, List<String> listMp3Name, String pathMp3Output) {
        //ffmpeg -i "concat:file1.mp3|file2.mp3" -acodec copy -metadata "title=Some Song" test.mp3 -map_metadata 0:-1
        String concatMp3 = "concat:" + String.join("|", listMp3Name);
        ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-i", concatMp3, "-acodec", "copy", pathMp3Output);
        processBuilder.directory(new File(directory));
        return process(processBuilder, true);
    }
    
    public boolean combineMultipleMp4(String directory, String pathFileListMp4, String pathOutputMp4) {
        //ffmpeg -i "concat:input1|input2" -codec copy output.mkv -- not use for MP4
        //ffmpeg -safe 0 -f concat -i list.txt -c copy output.mp4
        //directory = "'" + directory + "'"; 
        pathFileListMp4 = "\"" + pathFileListMp4 + "\""; 
        pathOutputMp4 = "\"" + pathOutputMp4 + "\""; 
        
        try {
            //ffmpeg -safe 0 -f concat -segment_time_metadata 1 -i file.txt -vf select=concatdec_select -af aselect=concatdec_select,aresample=async=1 out.mp4
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-safe", "0", "-f", "concat", "-i", pathFileListMp4, "-acodec", "mp3", "-c", "copy", pathOutputMp4);
            //ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-safe", "0", "-f", "concat", "-segment_time_metadata", "1", "-i", pathFileListMp4, "-vf", "select=concatdec_select", "-af", "aselect=concatdec_select,aresample=async=1", pathOutputMp4);
            //ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-safe", "0", "-f", "concat", "-i", pathFileListMp4, "-c:v", "libx264", "-crf", "0", "-preset", "veryfast", "-tune", "stillimage", "-c", "copy", "-shortest", pathOutputMp4);
            //ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-safe", "0", "-f", "concat", "-i", pathFileListMp4, "-c", "copy", "-fflags", "+genpts", pathOutputMp4);
            
            process.directory(new File(directory));
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFmpeg.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;            
    }    
    
    
    public boolean splitVideo(String pathVideo, String pathVideoOutput, String splitTime) {
        //ffmpeg -i input.mp4 -c copy -map 0 -segment_time 00:30:00 -f segment Mp4_Combine_Output_%03d.mp4
        ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-c", "copy", "-map", "0", "-segment_time", splitTime, "-f", "segment", pathVideoOutput);
        return process(processBuilder, false);
    }     
    
    //========
    public boolean convertSubSrtToAss(String pathSrt) {
        System.out.println("== Convert sub srt to ass...");
        try {
            //-- ffmpeg -i subtitles.srt subtitles.ass
            String pathAcc = pathSrt.replace(".srt", ".ass");
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathSrt, pathAcc);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFmpeg.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    } 
    
    //========
    public boolean processAssFile(String pathAssFile, String title, List<String> persons) {
        List<String> assFileLines = UtilityFileFolder.readRowTextFileToListString(pathAssFile);
        List<String> assFileLinesWrite = new ArrayList<>();
        boolean isPerson;

        int index = 0;
        for (String assFileLine : assFileLines) {
            isPerson = false;
            for (String person : persons) {
                String[] tmpPerson = person.split("↨");
                String tmpPersonName = tmpPerson[0];
                if (assFileLine.contains(tmpPersonName + ": ")) {
                    assFileLine = assFileLine.replace(tmpPersonName + ": ", "{\\b1\\u1}" + tmpPersonName + ":\\N{\\b0\\u0}");
                } 
            }
            
            
            if (assFileLine.contains("PlayResX: ")) {
                assFileLine = "PlayResX: 1920";
            }
            if (assFileLine.contains("PlayResY: ")) {
                assFileLine = "PlayResY: 1080";
            }
            if (assFileLine.contains("Style: Default")) {
                //-- CENTER x MID
                //assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,33,33,25,0";
                //assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,77,77,25,0";
                //assFileLine = "Style: Default,Arial,120,&H00FFFFFF,&H00FFFFFF,&H001F1F1F,&H000A0A0A,0,0,0,0,100,100,0,0,1,2,1,5,77,77,25,0";
                //assFileLine = "Style: Default,Arial,120,&H00000000,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,2,5,77,77,25,0";
                //-- CENTER x BOTTOM
                //assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,33,33,25,0";
                //-- LEFT x TOP
                assFileLine = "Style: Default,Arial,100,&H00000000,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,300,25,150,0";
            }
            if (assFileLine.contains(title)) {
                assFileLine = assFileLine.replace(title, "{\\b1\\fs120}" + title);
                assFileLine = assFileLine.replace(" - ", "\\N");
            }
            if (assFileLine.contains("EngLives")) {
                assFileLine = assFileLine.replace("EngLives", "{\\b1\\fs172}Eng{\\c&H0000FF&}Lives");
            }
            
//            if (assFileLine.contains(". ")) {
//                assFileLine = assFileLine.replace(". ",".\\N");
//            }
            
            //if (assFileLine.contains("\\N\\N/")) {
            //    assFileLine = assFileLine.replace("\\N\\N/", "\\N\\N{\\i1\\c&HA1A1A1&\\fs90}/") + "{\\i0}";
            //}
            
            assFileLinesWrite.add(assFileLine);
            index++;
        }
        
        String assFileLinesWriteData = String.join("\n", assFileLinesWrite);
        UtilityFileFolder.writeTextFileWithBufferedWriter(pathAssFile, "UTF-8", assFileLinesWriteData, false);
        return true;
    }
    
    //========
    public boolean convertSubSrtToAss001(String pathSrt, String pathAss) {
        try {
            //-- ffmpeg -i subtitles.srt subtitles.ass
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathSrt, pathAss);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFmpeg.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }        

    //========
    public boolean writeSubToVideo(String pathSub, String pathVideo) {
        try {
            String extension = pathVideo.substring(pathVideo.lastIndexOf("."));
            String pathVideoSub = pathVideo.replace(extension, " Sub" + extension);
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-filter:v", subTitles, pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFmpeg.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }  

    public boolean writeSubToVideo6(String pathSub, String pathVideo) {
        try {
            String pathVideoSub = pathVideo.replace(".mp4", " Final.mp4" );
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-max_muxing_queue_size", "1920", pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFmpeg.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }     
    
 
    
    public boolean writeSubToVideo5(String pathSub, String pathVideo) {
        try {
            String pathVideoSub = pathVideo.replace(" Run Without Subtitle.mp4", ".mp4" );
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-max_muxing_queue_size", "1920", pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFmpeg.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }       
    
    public boolean writeSubToVideo2(String subPath, String videoPath, String videoName) {
        System.out.println("== WRITE SUB TO VIDEO ==");
        
        videoName = videoName.replace(".", "");
        videoName = videoName.replace(":", " -");
        
        try {
            String pathVideoSub = videoPath.replace("audio.mp4", videoName + ".mp4" );
            String subTitles = "\"subtitles=" + subPath.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", videoPath, "-vf", subTitles, "-max_muxing_queue_size", "1920", pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFmpeg.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }   

    public boolean writeSubToVideo3(String pathSub, String pathVideo) {
        try {
            String pathVideoSub = pathVideo.replace(" without_sub.mp4", ".mp4" );
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-max_muxing_queue_size", "1920", pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFmpeg.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }    

    public boolean writeSubToVideo4(String pathSub, String pathVideo) {
        try {
            String pathVideoSub = pathVideo.replace(".mp4", " Subtitle.mp4" );
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            //ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-max_muxing_queue_size", "1920", pathVideoSub);
            //ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-b:v", "20M", "-c:a", "copy",pathVideoSub);
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-c:v", "libx264", "-crf", "0", "-preset", "veryfast", "-tune", "stillimage", "-c:a", "copy", "-shortest", pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFmpeg.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }      
    
    public boolean writeSubToVideo1(String pathSub, String pathVideo) {
        try {
            String extension = pathVideo.substring(pathVideo.lastIndexOf("."));
            String pathVideoSub = pathVideo.replace(" Subtitle" + extension, extension);
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-max_muxing_queue_size", "1920", pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFmpeg.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }      
    
    public boolean writeSubToVideo_New_1(String pathSub, String pathVideo) {
        try {
            String extension = pathVideo.substring(pathVideo.lastIndexOf("."));
            String pathVideoSub = pathVideo.replace(extension, " Sub" + extension);
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFmpeg.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }     
    
    public boolean writeSubToVideo_Test(String pathSub, String pathVideo) {
        try {
            String extension = pathVideo.substring(pathVideo.lastIndexOf("."));
            String pathVideoSub = pathVideo.replace(extension, " Sub" + extension);
            String subTitles = "\"subtitles=" + pathSub.replace("\\", "\\\\\\\\").replace(":", "\\\\:") + "\"";
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-i", pathVideo, "-vf", subTitles, "-max_muxing_queue_size", "1024", pathVideoSub);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFmpeg.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;        
    }     
    
    public boolean mergeMp3AndMp4ToMp4(String iPathMp3, String iPathMp4, String oPathMp4) {
        ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-i", iPathMp3, "-i", iPathMp4, "-codec", "copy", "-shortest", oPathMp4);
        return process(processBuilder, false);
    }    
    
    public boolean mergeImageAndMp3ToMp4(String pathImage, String pathMp3) {
        String pathMp4 = pathMp3.replace(".mp3", ".mp4");

        //ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-loop", "1", "-i", pathImage, "-i" ,pathMp3, "-codec", "copy", "-shortest", pathMp4);
        ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-loop", "1", "-i", pathImage, "-i" ,pathMp3, "-c:v", "libx264", "-crf", "0", "-preset", "veryfast", "-tune", "stillimage", "-c:a", "copy", "-shortest", pathMp4);
        //ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-r", "1", "-loop", "1", "-i", pathImage, "-i"  ,pathMp3, "-acodec", "copy", "-shortest", pathMp4);
        //ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-loop", "1", "-i", pathImage, "-i" ,pathMp3, "-shortest", "-c:v", "libx264", "-c:a", "copy", pathMp4);
        //ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-r", "1", "-loop", "1", "-i", pathImage, "-i"  ,pathMp3, "-acodec", "copy", "-r", "1", "-shortest", pathMp4);
        //ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-loop", "1", "-i", pathImage, "-i" ,pathMp3, "-vf", "fps=10", "-shortest", "-c:v", "libx264", "-c:a", "copy", pathMp4);
        //ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-r", "1", "-loop", "1", "-i", pathImage, "-i"  ,pathMp3, "-acodec", "copy", "-r", "1", "-shortest", "-vf", "scale=1920:1080", pathMp4);
        //ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-r", "1", "-loop", "1", "-i", pathImage, "-i"  ,pathMp3, "-c:v", "libx264", "-crf", "0", "-preset", "veryfast", "-tune", "stillimage", "-c:a", "copy", "-shortest", pathMp4);
        //ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-loop", "1", "-framerate", "1", "-i", pathImage, "-i"  ,pathMp3, "-c:v", "libx264", "-crf", "0", "-preset", "veryfast", "-tune", "stillimage", "-c:a", "copy", "-shortest", pathMp4);            
        //ProcessBuilder processBuilder = new ProcessBuilder(this.ffmegPath, "-y", "-loop", "1", "-i", pathImage, "-i" ,pathMp3, "-r", "25","-codec", "copy", "-shortest", pathMp4);
        return process(processBuilder, true);
    }

    public boolean loopVideo(String loopNumber, String pathVideo) {
        try {
            //-- CMD 001: ffmpeg -stream_loop 4 -i 001.mp4 -c copy -fflags +genpts output.mp4
            String pathVideoLoop = pathVideo.replace(".mp4", "_loop.mp4");
            ProcessBuilder process = new ProcessBuilder(this.ffmegPath, "-stream_loop", loopNumber, "-i", pathVideo, "-c", "copy", "-fflags", "+genpts", pathVideoLoop);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            System.out.println("-- Wait over: " + p.waitFor());            
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(FFmpeg.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }
    
}
