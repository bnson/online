/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ibm.icu.text.SimpleDateFormat;
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.event.HyperlinkEvent;
import javax.swing.text.html.HTMLEditorKit;
import object.ObjChapter;
import object.ObjStory;
import object.ObjVideoHanimeTv;
import object.ObjWebtoonsComment;
import object.ObjWebtoonsEpisode;
import object.ObjWebtoonsStory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import utility.IDM;
import utility.UtilityFileFolder;
import utility.UtilityString;

/**
 *
 * @author bnson
 */
public class Download extends javax.swing.JFrame {

    private final IDM idm;
    private final String defaultFolderDownload;
    /**
     * Creates new form Download
     */
    public Download() {
        initComponents();
        
        idm = new IDM();
        defaultFolderDownload = "F:\\Video\\Anime Hentai\\";
        
        epShowHtml.addHyperlinkListener((HyperlinkEvent e) -> {
            if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
                if (Desktop.isDesktopSupported()) {
                    try {
                        Desktop.getDesktop().browse(e.getURL().toURI());
                    } catch (URISyntaxException | IOException ex) {
                        Logger.getLogger(Download.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        });
    }
    
    private String processString(String str) {
        String strProcess = UtilityString.trimSpace(str);
        
        strProcess = strProcess.replace("::", ":");
        strProcess = strProcess.replace("\"", "“");
        
        strProcess = UtilityString.trimSpace(strProcess);
        return strProcess;
    }
    
    private void getStoryInformationTruyenConvert(String linkWeb, String saveTo) {
        ObjStory story = new ObjStory();
        Document doc;
        Element body;
        String html;
        try {
//            doc = Jsoup.connect(linkWeb)
//                    .data("query", "Java")
//                    .userAgent("Mozilla")
//                    .cookie("auth", "token")
//                    .timeout(10000)
//                    .post();
//
//            body = doc.body();
//            html = body.html();
//            html = html.replaceAll("(?i)<br[^>]*>", "↔");
//            doc = Jsoup.parseBodyFragment(html);    
            
            File htmlFile = new File("F:\\Audio\\Hac_Am_Vuong_Gia\\TruyenConvert\\Website\\Hắc Ám Vương Giả Convert.html");
            doc = Jsoup.parse(htmlFile, "UTF-8");

            Elements names = doc.select("h1[class=title] > a");
            story.setName(names.get(0).text());
            
            Elements author = doc.select("div[class=item-value] > a[class=author]");
            story.setAuthor(author.get(0).text()); 
            
            Elements tags = doc.select("ul[class=list-unstyled categories] > li > a");
            for (Element tag : tags) {
                story.getTabs().add(UtilityString.trimSpace(tag.text()));
            }

            Elements status = doc.select("div[class=item]");
            for (Element tmpStatus : status) {
                if (tmpStatus.text().toLowerCase().contains("tình trạng:")) {
                    story.setStatus(UtilityString.trimSpace(tmpStatus.text().replace("Tình trạng:", "")));
                }
            }     
            
            Elements chapters = doc.select("div.col-md-4 > div.item > a");
            Collections.reverse(chapters);
            
            for (Element chapter : chapters) {
                ObjChapter objChapter = new ObjChapter();
                String tmp[] = chapter.attr("href").split("-");
                objChapter.setIndex(Integer.parseInt(tmp[tmp.length-1].replace("/", "")));
                
                if (!chapter.select("span").isEmpty()) {
                    objChapter.setName(processString(chapter.text().replace(chapter.select("span").text(), "")));
                } else {
                    objChapter.setName(processString(chapter.text()));
                }

                objChapter.setLink(chapter.attr("href"));
                System.out.println("objChapter: " + objChapter.toString());
                
                story.getChapters().add(objChapter);
            }            
            
            //System.out.println("Story: " + story.toString());
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            String jsonData = gson.toJson(story);
            if (jsonData != null && jsonData.length() > 0) {
                UtilityFileFolder.writeTextFileWithBufferedWriter(saveTo + "\\" + "data.json", "UTF-8", jsonData, false);
            } else {
                System.exit(0);
            }
            
            //DOWNLOAD STORY CONTENT
            for (int i = 0; i < story.getChapters().size(); i++) {
                System.out.println("-- INDEX: " + (i+1));
                String tmpLink = story.getChapters().get(i).getLink();
                if (!tmpLink.isEmpty() && i >= 300) {
                    doc = Jsoup.connect(tmpLink)
                            .data("query", "Java")
                            .userAgent("Mozilla")
                            .cookie("auth", "token")
                            .timeout(10000)
                            .post();
                    
                    body = doc.body();
                    
                    html = body.html();
                    html = html.replaceAll("(?i)<br[^>]*>", "↔");
                    Document docHtml = Jsoup.parseBodyFragment(html);                

                    Elements titles = docHtml.select("h2[class=title]");
                    story.getChapters().get(i).setName(titles.get(0).text());                    
                    
                    Elements content = docHtml.select("div[id=js-truyencv-content]");
                    story.getChapters().get(i).setContent(content.get(0).text());
                    
                    String tmpText = story.getChapters().get(i).getName() + "\r\n\r\n" + content.get(0).text().replaceAll("↔", "\r\n");
                    UtilityFileFolder.writeTextFileWithBufferedWriter(saveTo + "\\Text\\" + story.getChapters().get(i).getIndex() + ".txt", "UTF-8", tmpText, false);
                 
                    if (i % 10 == 0) {
                        TimeUnit.SECONDS.sleep(30);
                    } else {
                        TimeUnit.SECONDS.sleep(10);
                    }
                    
                    if (i > 400) {
                        break;
                    }

                }

            }

        } catch (IOException | InterruptedException | NumberFormatException ex) {
            Logger.getLogger(Download.class.getName()).log(Level.SEVERE, null, ex);
        }     
    
    }
    
    private void getVideoInformationWebToons(String linkWeb) {
        try {
            ObjWebtoonsStory objWebtoonsStory = new ObjWebtoonsStory();
            Document doc;
            Pattern p;
            Matcher m;            
            //==================================
            linkWeb = "https://www.webtoons.com/en/romance/truebeauty/list?title_no=1436";
            doc = Jsoup.connect(linkWeb)
                    .data("query", "Java")
                    .userAgent("Mozilla/5.0")
                    .cookie("auth", "token")
                    .timeout(10000)
                    .get();
            
            Element storyName = doc.select("h1[class=subj]").first();
            objWebtoonsStory.setName(storyName.text());
            objWebtoonsStory.setLink(linkWeb);
            
            Elements episodes = doc.select("ul[id=_listUl] > li > a");
            for (Element episode : episodes) {
                ObjWebtoonsEpisode objWebtoonsEpisode = new ObjWebtoonsEpisode();
                
                linkWeb = episode.attr("href");
                System.out.println("Episode link: " + linkWeb);
                doc = Jsoup.connect(linkWeb)
                        .data("query", "Java")
                        .userAgent("Mozilla/5.0")
                        .cookie("auth", "token")
                        .timeout(10000)
                        .get();
                
                String docHtml = doc.html();
                
                String apiDomain= "";
                String apiDomainPattern = "(sApiDomain : ')([^']+)";
                p = Pattern.compile(apiDomainPattern);
                m = p.matcher(docHtml);
                if (m.find()) {
                    apiDomain = m.group(2);
                    //System.out.println("apiDomain: " + apiDomain);
                }  
                
                String ticket= "";
                String ticketPattern = "(sTicket : ')([^']+)";
                p = Pattern.compile(ticketPattern);
                m = p.matcher(docHtml);
                if (m.find()) {
                    ticket = m.group(2);
                    //System.out.println("ticket: " + ticket);
                } 

                String templateId= "";
                String templateIdPattern = "(sTemplateId : ')([^']+)";
                p = Pattern.compile(templateIdPattern);
                m = p.matcher(docHtml);
                if (m.find()) {
                    templateId = m.group(2);
                    //System.out.println("ticket: " + templateId);
                } 
                
                String language= "";
                String languagePattern = "(sLanguage : ')([^']+)";
                p = Pattern.compile(languagePattern);
                m = p.matcher(docHtml);
                if (m.find()) {
                    language = m.group(2);
                    //System.out.println("ticket: " + language);
                }                   
                
                String objectId = "";
                String objectIdPattern = "(sObjectId : ')([^']+)";
                p = Pattern.compile(objectIdPattern);
                m = p.matcher(docHtml);
                if (m.find()) {
                    objectId = m.group(2);
                    //System.out.println("objectId: " + objectId);
                }                
                
                String consumerKey = "";
                String consumerKeyPattern = "(sConsumerKey : ')([^']+)";
                p = Pattern.compile(consumerKeyPattern);
                m = p.matcher(docHtml);
                if (m.find()) {
                    consumerKey = m.group(2);
                    //System.out.println("consumerKey: " + consumerKey);
                }   
                
                String pageSize = "";
                String pageSizePattern = "(nPageSize : )([^,]+)";
                p = Pattern.compile(pageSizePattern);
                m = p.matcher(docHtml);
                if (m.find()) {
                    pageSize = m.group(2);
                    //System.out.println("pageSize: " + pageSize);
                }                  
                
                String replyIndexSize = "";
                String replyIndexSizePattern = "(nPageSize : )([^,]+)";
                p = Pattern.compile(replyIndexSizePattern);
                m = p.matcher(docHtml);
                if (m.find()) {
                    replyIndexSize = m.group(2);
                    //System.out.println("consumerKey: " + replyIndexSize);
                }                
                
                int page = 1;
                
                String referrerLink = "";
                Elements eReferrerLinks = doc.select("link[rel=canonical]");
                for (Element eReferrerLink : eReferrerLinks) {
                    if (eReferrerLink.attr("href").startsWith("https://www.webtoons.com/")) {
                        referrerLink = eReferrerLink.attr("href");
                        //System.out.println("referrerLink: " + referrerLink);
                        break;
                    }
                }
                
                String linkApiComments = apiDomain 
                        + "/web_neo_list_jsonp.json?"
                        + "ticket=" + ticket
                        + "&templateId=" + templateId
                        + "&pool=ncc-cbox"
                        + "&lang=" + language
                        + "&country="
                        + "&objectId=" + objectId
                        + "&categoryId="
                        + "&pageSize=" + pageSize
                        + "&indexSize=" + replyIndexSize
                        + "&groupId="
                        + "&listType=OBJECT"
                        + "&pageType=default"
                        + "&token=null"
                        + "&consumerKey=" + consumerKey
                        + "&snsCode=null"
                        + "&page=" + page
                        + "&refresh=false"
                        + "&sort=NEW";
                System.out.println("linkApiComments: " + linkApiComments);
                objWebtoonsEpisode.setEpisodeNumber(episode.child(1).child(0).text());
                objWebtoonsEpisode.setEpisodeLink(linkWeb);
                
                //=========
                linkWeb = linkApiComments;
                doc = Jsoup.connect(linkWeb)
                        .data("query", "Java")
                        .userAgent("Mozilla/5.0")
                        .cookie("auth", "token")
                        .referrer(referrerLink)
                        .ignoreContentType(true)
                        .timeout(10000)
                        .get();

                String jsonString = doc.text();
                jsonString = jsonString.substring(10, jsonString.length()-2);
                //System.out.println("jsonString: " + jsonString);
                //epShow.setText(jsonString);
                
                JSONObject obj = new JSONObject(jsonString);                
                JSONArray commentList = obj.getJSONObject("result").getJSONArray("commentList");
                for (int i = 0; i < commentList.length(); i++) {
                    String contents = commentList.getJSONObject(i).getString("contents");
                    int sortValue = commentList.getJSONObject(i).getInt("sortValue");
                    //System.out.println("contents: " + contents);
                    
                    ObjWebtoonsComment objWebtoonsComment = new ObjWebtoonsComment();
                    objWebtoonsComment.setContents(contents);
                    objWebtoonsComment.setSortValue(sortValue);
                    
                    objWebtoonsEpisode.getObjWebtoonsComments().add(objWebtoonsComment);
                }

                objWebtoonsStory.getEpisodes().add(objWebtoonsEpisode);                

            }
            
            //=================
            //Gson gson = new GsonBuilder().setPrettyPrinting().create();
            //String jsonData = gson.toJson(objWebtoonsStory);     
            //System.out.println("jsonData: " + jsonData);
            
            String html = "";
            String htmlTable = "<tr><td>$1</td></tr>";
            String htmlTableHyperLink = "<tr><td><a href='$1'><h1>$2</h1></a></td></tr>";
            
            for (ObjWebtoonsEpisode episode : objWebtoonsStory.getEpisodes()) {
                String episodeHtml = htmlTableHyperLink.replace("$1", episode.getEpisodeLink()).replace("$2", episode.getEpisodeNumber());
                html += episodeHtml + "\r\n";
                
                Collections.sort(episode.getObjWebtoonsComments(), Comparator.comparing((objWebtoonsComment) -> objWebtoonsComment.getSortValue()));
                Collections.reverse(episode.getObjWebtoonsComments());
                for (ObjWebtoonsComment comment : episode.getObjWebtoonsComments()) {
                    String commentHtml = htmlTable.replace("$", comment.getContents());
                    html += commentHtml + "\r\n";
                }
            }
            
            html = "<html><head></head><body><table style=\"width:100%\" cellpadding=\"5\"  cellspacing=\"5\" border=\"1\">" + html + "</table></body></html>";
            epShow.setText(html);
            epShowHtml.setText(html);
            
            
        } catch (IOException ex) {
            Logger.getLogger(Download.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }    
    
    private void getVideoInformationHAnimeTv(String linkWeb) {
        try {
            ObjVideoHanimeTv video = new ObjVideoHanimeTv();
            
            Document doc = Jsoup.connect(linkWeb)
                    .data("query", "Java")
                    .userAgent("Mozilla")
                    .cookie("auth", "token")
                    .timeout(10000)
                    .post();

            Elements names = doc.select("h1[class=tv-title]");
            video.setName(names.get(0).text());
            
            Elements brands = doc.select("a[class=hvpimbc-text]");
            video.setBrand(brands.get(0).text());
            
            Elements releaseDates = doc.select("div[class=hvpimbc-text grey--text]");
            Date releaseDate = new SimpleDateFormat("MMMM dd, yyyy").parse(releaseDates.get(1).text());  
            video.setReleaseDate(releaseDate);
            
            Elements alternateNames = doc.select("div[class=hvpimbc-item full] > h2 > span");
            List<String> listAlternateNames = new ArrayList<>();
            if (alternateNames != null && alternateNames.size() > 0) {
                for (Element element : alternateNames) {
                    listAlternateNames.add(element.text());
                }
            } else {
                alternateNames = doc.select("div[class=hvpimbc-item full] > div > em");
                listAlternateNames.add(alternateNames.get(0).text());
            }
            video.getAlternateNames().clear();
            video.getAlternateNames().addAll(listAlternateNames);
            
            Elements tabs = doc.select("div[class=hvpis-text grey--text text--lighten-1] > a > div[class=btn__content]");
            List<String> listTabs = new ArrayList<>();
            if (tabs != null && tabs.size() > 0) {
                tabs.forEach((element) -> {
                    listTabs.add(element.text());
                });
            } else {
                System.exit(0);
            }
            video.getTabs().clear();
            video.getTabs().addAll(listTabs);
            
            Elements descriptions = doc.select("div[class=mt-3 mb-0 hvpist-description]");
            video.setDescription(descriptions.get(0).text());            
            
            System.out.println(video.toString());
            
            //===
            String folderDownload = defaultFolderDownload + video.getName();
            if (UtilityFileFolder.createDirectory(folderDownload)) {
                Gson gson = new GsonBuilder().setPrettyPrinting().create();
                String jsonData = gson.toJson(video);
                if (jsonData != null && jsonData.length() > 0) {
                    UtilityFileFolder.writeTextFileWithBufferedWriter(folderDownload + "\\" + "data.json", "UTF-8", jsonData, true);
                } else {
                    System.exit(0);
                }
                
                //===
                String imageCoverLink = "";
                Elements imageCover = doc.select("div[class=hvpi-cover-container] > img[class=hvpi-cover]");
                imageCoverLink = imageCover.get(0).attr("src");
                System.out.println("imageCoverLink: " + imageCoverLink);
                idm.download(folderDownload, imageCoverLink, "cover.jpg");                
                
            } else {
                System.exit(0);
            }

            
        } catch (IOException | ParseException ex) {
            Logger.getLogger(Download.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
        
    
    private void getInformationGoogleTranslate(String linkWeb, String saveTo) {
        try {
            Document doc = Jsoup.connect(linkWeb)
                    .data("query", "Java")
                    .userAgent("Mozilla")
                    .cookie("auth", "token")
                    .timeout(10000)
                    .get();

            Elements names = doc.select("span[class=tlid-translation translation] > span");
            for (Element name : names) {
                System.out.println("--: " + name.text());
            }

        } catch (Exception ex) {
            Logger.getLogger(Download.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    private void showVideoThumbs(ObjVideoHanimeTv video) {
        if (video != null) {
            String html = "";
            String image = " <img src=\"$1\" > ";
            
            int index = 0;
            for (String thumb : video.getImageThumbs()) {
                html = html + thumb + "<br>" + image.replace("$1", thumb) + "<br>";
                index++;
            }
            
            html = "<html>" + html + "</html>" ;
            
            HTMLEditorKit kit = new HTMLEditorKit();
            epShowHtml.setEditorKit(kit);            
            javax.swing.text.Document doc = kit.createDefaultDocument();
            epShowHtml.setDocument(doc);
            epShowHtml.setText(html);            
        } else {
            System.out.println("Object video is null!");
        }
    }
    
    private void getInformation(String linkWeb) {
        try {
            Document doc = Jsoup.connect(linkWeb)
                    .data("query", "Java")
                    .userAgent("Mozilla")
                    .cookie("auth", "token")
                    .timeout(10000)
                    .get();

            Elements names = doc.select("div[class=caption]");
            System.out.println(names.get(0).text());
            
            
        } catch (IOException ex) {
            Logger.getLogger(Download.class.getName()).log(Level.SEVERE, null, ex);
        }              
    }
    
    private void getVideoInformationArchiveOrg(String linkWeb) {
        try {
            ObjVideoHanimeTv video = new ObjVideoHanimeTv();
            
            Document doc = Jsoup.connect(linkWeb)
                    .data("query", "Java")
                    .userAgent("Mozilla")
                    .cookie("auth", "token")
                    .timeout(10000)
                    .post();

            Elements names = doc.select("h1[class=item-title]");
            video.setName(names.get(0).text());
            
            video.setBrand("unknown");
            
            Date releaseDate = new SimpleDateFormat("MM dd, yyyy").parse("01 01, 0001");  
            video.setReleaseDate(releaseDate);
            
            List<String> listAlternateNames = new ArrayList<>();
            listAlternateNames.add("unknown");
            video.getAlternateNames().clear();
            video.getAlternateNames().addAll(listAlternateNames);
            
            List<String> listTabs = new ArrayList<>();
            listTabs.add("unknown");
            video.getTabs().clear();
            video.getTabs().addAll(listTabs);
            
            video.setDescription("unknown");            

            //===
            String linkShowAll;
            Elements eShowAll = doc.select("div[class=show-all] > a[class=boxy-ttl]");
            linkShowAll = eShowAll.get(0).attr("abs:href");
            System.out.println("eShowAll: " + linkShowAll);
            Document doc1 = Jsoup.connect(linkShowAll)
                    .data("query", "Java")
                    .userAgent("Mozilla")
                    .cookie("auth", "token")
                    .timeout(10000)
                    .post();   
            
            String linkThumbs = "";
            Elements eDirTableLinks = doc1.select("table[class=directory-listing-table] > tbody > tr > td > a");
            for (Element eDirTableLink : eDirTableLinks) {
                if (eDirTableLink.text().toLowerCase().endsWith(".mp4")) {
                    video.getMp4Links().add(eDirTableLink.attr("abs:href"));
                }
                
                if (eDirTableLink.text().toLowerCase().endsWith(".thumbs/")) {
                    linkThumbs = eDirTableLink.attr("abs:href");
                }
            }
            //===
            if (linkThumbs.isEmpty()) {
                System.out.println("Application did not found link.");
            } else {
                Document doc3 = Jsoup.connect(linkThumbs)
                        .data("query", "Java")
                        .userAgent("Mozilla")
                        .cookie("auth", "token")
                        .timeout(10000)
                        .post();
                
                Elements eDirTableImageLinks = doc3.select("table[class=directory-listing-table] > tbody > tr > td > a");
                for (Element eDirTableImageLink : eDirTableImageLinks) {
                    if (eDirTableImageLink.text().toLowerCase().endsWith(".jpg")) {
                        video.getImageThumbs().add(eDirTableImageLink.attr("abs:href"));
                    }                    
                }
            }

            //===
            Gson gson = new Gson();
            String jsonData = gson.toJson(video);            
            epShow.setText(jsonData);
            //System.out.println(jsonData);
            //===
            showVideoThumbs(video);
        } catch (IOException | ParseException ex) {
            Logger.getLogger(Download.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        tfLinkWeb = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        epShow = new javax.swing.JEditorPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        epShowHtml = new javax.swing.JEditorPane();
        jLabel2 = new javax.swing.JLabel();
        tfSaveTo = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        btGetInformation = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Link Web");

        tfLinkWeb.setText("https://nhentai.net/?page=1");

        jScrollPane1.setViewportView(epShow);

        epShowHtml.setEditable(false);
        epShowHtml.setContentType("text/html"); // NOI18N
        jScrollPane2.setViewportView(epShowHtml);

        jLabel2.setText("Save to");

        tfSaveTo.setText("F:\\Audio\\Hac_Am_Vuong_Gia\\TruyenConvert");

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btGetInformation.setText("Get Information");
        btGetInformation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btGetInformationActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btGetInformation)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btGetInformation)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tfLinkWeb, javax.swing.GroupLayout.DEFAULT_SIZE, 908, Short.MAX_VALUE)
                    .addComponent(tfSaveTo))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addGap(10, 10, 10))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(tfLinkWeb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfSaveTo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 366, Short.MAX_VALUE)
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btGetInformationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btGetInformationActionPerformed
        String linkWeb = tfLinkWeb.getText().trim();
        String saveTo = tfSaveTo.getText().trim();
        
        if (linkWeb.contains("hanime.tv")) {
            getVideoInformationHAnimeTv(linkWeb);
        }
        
        if (linkWeb.contains("webtoons.com")) {
            //https://www.webtoons.com/en/romance/truebeauty/episode-115/viewer?title_no=1436&episode_no=116
            getVideoInformationWebToons(linkWeb);
        }        

        if (linkWeb.contains("archive.org")) {
            getVideoInformationArchiveOrg(linkWeb);
        }
        
        if (linkWeb.contains("truyencv.com")) {
            getStoryInformationTruyenConvert(linkWeb, saveTo);
        }        
        
        if (linkWeb.contains("translate.google.com")) {
            getInformationGoogleTranslate(linkWeb, saveTo);
        }
        
        if (linkWeb.contains("nhentai.net")) {
            getInformation(linkWeb);
        }        
        
    }//GEN-LAST:event_btGetInformationActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Download.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Download.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Download.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Download.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Download().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btGetInformation;
    private javax.swing.JEditorPane epShow;
    private javax.swing.JEditorPane epShowHtml;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField tfLinkWeb;
    private javax.swing.JTextField tfSaveTo;
    // End of variables declaration//GEN-END:variables

}
