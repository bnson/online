/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import object.dict.ObjWord;
import object.dict.ObjDictionaryEnWord;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Connection;
import org.jsoup.Connection.Method;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.json.JSONArray;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import utility.UtilityFileFolder;
import utility.UtilityList;
import utility.UtilityString;

/**
 *
 * @author bnson
 */
public class DownloadWebFromUrl extends javax.swing.JFrame {

    private final String url = "jdbc:postgresql://localhost:5432/";
    private final String user = "postgres";
    private final String password = "gemdark1986!";
    private int brittanicaIndex = 700;

    public DownloadWebFromUrl() {
        initComponents();
    }

    private void autoDownloadBrittanica(String link) {
        try {
            Document document = Jsoup.connect(link)
                    .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36")
                    .header("content-type", "text/html; charset=UTF-8")
                    .method(Method.GET)
                    .timeout(30000)
                    .get();

            Element postId = document.select("article").first();
            Element title = document.select("h1[class=entry-title]").first();
            Element content = document.select("div[class=entry-content]").first();
            Element previousPost = document.select("a[class=previous-post]").first();
            Element nextPost = document.select("a[class=next-post]").first();

            if (title != null && content != null) {
                String sPostId = "";
                if (postId != null && postId.attr("id") != null && !postId.attr("id").isEmpty()) {
                    sPostId = postId.attr("id");
                }
                List<String> fileData = new ArrayList<>();

                if (sPostId == null || sPostId.isEmpty()) {
                    System.out.println("Stop Link: " + link);
                    System.exit(0);
                }

                String filePath = "D:\\Data\\Brittanica\\" + sPostId + ".txt";

                if (UtilityFileFolder.isExistsFile(filePath)) {
                    System.out.println("==========================================");
                    System.out.println("File: " + filePath + " - is exists!");
                    System.out.println("==========================================");
                } else {
                    //====
                    System.out.println("==========================================");
                    System.out.println("Post ID: " + sPostId);
                    System.out.println("Title: " + title.text());
                    //System.out.println("Content: " + content.text());
                    System.out.println("Link: " + link);
                    System.out.println("brittanicaIndex: " + brittanicaIndex);

                    //====
                    fileData.add("↨Title: " + title.text() + "\n");

                    Elements contentChildren = content.children();
                    for (Element element : contentChildren) {
                        fileData.add(element.text() + "\n");
                    }

                    fileData.add("\n↨Link: " + link + "\n");

                    //====
                    writeUnicodeJava8(filePath, fileData);
                    brittanicaIndex--;

                    //====
                    if (brittanicaIndex > 0) {
//                    if ((previousPost != null && previousPost.attr("href") != null && !previousPost.attr("href").isEmpty())) {
//                        String linkPrevious = previousPost.attr("href");
//                        System.out.println("Link: " + previousPost.attr("href"));
//
//                        if (brittanicaIndex % 2 == 0) {
//                            TimeUnit.SECONDS.sleep(3);
//                        } else {
//                            TimeUnit.SECONDS.sleep(6);
//                        }
//
//                        autoDownloadBrittanica(linkPrevious);
//                    } 

                        if ((nextPost != null && nextPost.attr("href") != null && !nextPost.attr("href").isEmpty())) {
                            String linkNext = nextPost.attr("href");
                            System.out.println("Link: " + nextPost.attr("href"));

                            if (brittanicaIndex % 2 == 0) {
                                TimeUnit.SECONDS.sleep(2);
                            } else {
                                TimeUnit.SECONDS.sleep(3);
                            }

                            autoDownloadBrittanica(linkNext);
                        } else {
                            System.out.println("==========================================");
                            System.out.println("== END BY POST ID =================================");
                            System.out.println("==========================================");
                        }

                    } else {
                        System.out.println("==========================================");
                        System.out.println("== END BY INDEX =================================");
                        System.out.println("==========================================");
                    }
                }

            } else {
                System.out.println("==========================================");
                System.out.println("== ERROR =================================");
                System.out.println("==========================================");
            }

        } catch (IOException e) {
            System.out.println("downloadUsingJSOUP error: " + e.getMessage());
        } catch (InterruptedException ex) {
            Logger.getLogger(DownloadWebFromUrl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public java.sql.Connection connect() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    public List<ObjDictionaryEnWord> getListIdOfWord(List<String> wordList) {
        try {
            String words = StringUtils.join(wordList, "','");

            List<ObjDictionaryEnWord> ObjDictionaryEnWordList = new ArrayList<>();
            String sql = "select id, word, status from ehosito.dictionary_en_word where word in ('" + words + "')";
            java.sql.Connection conn = connect();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                ObjDictionaryEnWord objDictionaryEnWord = new ObjDictionaryEnWord(rs.getInt(1), rs.getString(2), rs.getString(3));
                ObjDictionaryEnWordList.add(objDictionaryEnWord);
            }

            return ObjDictionaryEnWordList;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }

        return null;
    }

    public void insertDictionaryEnWordTranslateToVn(List<ObjWord> objWordList) {
        String SQL = "INSERT INTO ehosito.dictionary_en_word_translate_to_vn (dictionary_en_word_classes_id, vn, frequency)\n"
                + "SELECT (SELECT id FROM ehosito.dictionary_en_word_classes WHERE dictionary_en_word_id IN (SELECT id FROM ehosito.dictionary_en_word WHERE word = ?) AND class ilike ?) as id, ? as vn, ? as frequency";
        try (
                java.sql.Connection conn = connect();
                PreparedStatement statement = conn.prepareStatement(SQL);) {
            int count = 0;

            for (ObjWord objWord : objWordList) {
                statement.setString(1, objWord.getEn());
                statement.setString(2, objWord.getEnClass());
                statement.setString(3, objWord.getVn());
                statement.setInt(4, objWord.getFrequency());
                statement.addBatch();
                count++;
                // execute every 100 rows or less
                if (count % 100 == 0 || count == objWordList.size()) {
                    statement.executeBatch();
                }
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void insertDictionaryEnWordClasses(List<ObjWord> objWordList) {
        String SQL = "INSERT INTO ehosito.dictionary_en_word_classes (dictionary_en_word_id, class)\n"
                + "SELECT (SELECT id FROM ehosito.dictionary_en_word WHERE word = ?) as id, ? as class\n"
                + "WHERE exists (SELECT 1 FROM ehosito.dictionary_en_word WHERE word = ?);";
        try (
                java.sql.Connection conn = connect();
                PreparedStatement statement = conn.prepareStatement(SQL);) {
            int count = 0;

            for (ObjWord objWord : objWordList) {
                statement.setString(1, objWord.getEn());
                statement.setString(2, objWord.getEnClass());
                statement.setString(3, objWord.getEn());
                statement.addBatch();
                count++;
                // execute every 100 rows or less
                if (count % 100 == 0 || count == objWordList.size()) {
                    statement.executeBatch();
                }
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    public void insertDictionaryEnSentences(List<String> sentences) {
        String SQL = "INSERT INTO ehosito.dictionary_en_sentences_tmp(sentence_raw) VALUES (?);";
        try (
                java.sql.Connection conn = connect();
                PreparedStatement statement = conn.prepareStatement(SQL);) {
            int count = 0;

            for (String sentence : sentences) {
                statement.setString(1, sentence);
                statement.addBatch();
                count++;
                // execute every 100 rows or less
                if (count % 100 == 0 || count == sentences.size()) {
                    statement.executeBatch();
                }
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }    

    private void downloadUsingStream(String urlStr, String file) {
        try {
            URL url = new URL(urlStr);
            BufferedInputStream bis = new BufferedInputStream(url.openStream());
            FileOutputStream fis = new FileOutputStream(file);
            byte[] buffer = new byte[1024];
            int count = 0;
            while ((count = bis.read(buffer, 0, 1024)) != -1) {
                fis.write(buffer, 0, count);
            }
            fis.close();
            bis.close();
        } catch (MalformedURLException ex) {
            Logger.getLogger(DownloadWebFromUrl.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(DownloadWebFromUrl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void downloadUsingNIO(String urlStr, String file) {
        try {
            URL url = new URL(urlStr);
            ReadableByteChannel rbc = Channels.newChannel(url.openStream());
            FileOutputStream fos = new FileOutputStream(file);
            fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
            fos.close();
            rbc.close();
        } catch (MalformedURLException ex) {
            Logger.getLogger(DownloadWebFromUrl.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(DownloadWebFromUrl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void downloadUsingHTTP(String urlStr, String file) {
        try {
            // Translate address of the webpage to the URL form
            URL address = new URL(urlStr);

            // Instantiate connection object
            HttpURLConnection connection = (HttpURLConnection) address.openConnection();

            // Set the properties of the connection (optional step)
            connection.setRequestMethod("GET"); // GET or POST HTTP method, GET is default
            connection.setRequestProperty("accept-language", "en"); // add headers to the request

            // Send HTTP request to the server - the connect is triggered by methods like:
            //						getInputStream
            //						getOutputStream
            //						getResponseCode
            //						getResponseMessage
            //                      connect			
            // Proceed with downloading only if server sends code OK 200
            int http_status = connection.getResponseCode();
            if (http_status != HttpURLConnection.HTTP_OK) {
                throw new IOException("Server response with error, code: " + http_status);
            }

            // Set up input stream to read data from the server
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));

            // Set up output stream to the file on disk
            BufferedWriter out = new BufferedWriter(new FileWriter(file));

            // Save data to the html file
            String line;
            while ((line = in.readLine()) != null) {
                out.write(line + "\n");
            }

            // Close input output streams after work is done
            in.close();
            out.close();

        } catch (MalformedURLException e) {
            System.out.println("Wrong URL address");
        } catch (IOException e) {
            System.out.println("Download error " + e.getMessage());
        }
    }

    private void downloadUsingJSOUP(String vocabulary, String file) {
        try {
            if (UtilityFileFolder.isExistsFile(file)) {
                System.out.println("Vocabulary " + vocabulary + " is exists.");
            } else {

                //String urlStr = "https://translate.google.com/_/TranslateWebserverUi/data/batchexecute?rpcids=MkEWBc&source-path=%2F&f.sid=586915041940004221&bl=boq_translate-webserver_20220906.10_p0&hl=vi&soc-app=1&soc-platform=1&soc-device=1&_reqid=773192&rt=c";
                String urlStr = "https://translate.google.com/_/TranslateWebserverUi/data/batchexecute?rpcids=MkEWBc&source-path=%2F&f.sid=1158988053965389093&bl=boq_translate-webserver_20220906.10_p0&hl=en&soc-app=1&soc-platform=1&soc-device=1&_reqid=574789&rt=c";
                String referrerLink = "https://translate.google.com/";
                String fReq = "[[[\"$1\",\"[[\\\"$2\\\",\\\"en\\\",\\\"vi\\\",true],[null]]\",null,\"generic\"]]]";

                String fReqId = tfFReqId.getText().trim();
                //AVdN8
                //MkEWBc

                //String userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36";
                String userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36";

                fReq = fReq.replace("$1", fReqId);
                fReq = fReq.replace("$2", vocabulary);

                // Send GET request to the server and fetch the response
                Connection.Response response = Jsoup.connect(urlStr)
                        .userAgent(userAgent)
                        .header("host", "translate.google.com")
                        .header("origin", "translate.google.com")
                        .header("Accept-Language", "en-US,en;q=0.5")
                        .referrer(referrerLink)
                        .header("content-type", "application/x-www-form-urlencoded;charset=utf-8")
                        .data("f.req", fReq)
                        .ignoreContentType(true)
                        .ignoreHttpErrors(true)
                        .method(Method.POST)
                        .timeout(10000)
                        .execute();

                // Parse response to get string with html code
                //String html = response.body();
                //Document doc = response.parse();
                String text = response.body();
                System.out.println("-- " + text);

                List<String> lines = new ArrayList<>();
                lines.add(text);

                writeUnicodeJava8(file, lines);
            }
        } catch (IOException e) {
            System.out.println("downloadUsingJSOUP error: " + e.getMessage());
            System.exit(0);
        }

    }

    private String autoCorrectSpelling(String text) {
        String rs = text;

        String[] charWrongA = {"á", "à", "ầ", "ả", "ậ", "ắ", "ấ", "ạ", "ặ", "ằ", "ẩ", "ẳ", "ã", "ẫ", "ẵ"};
        String[] charWrongAFix = {"á", "à", "ầ", "ả", "ậ", "ắ", "ấ", "ạ", "ặ", "ằ", "ẩ", "ẳ", "ã", "ẫ", "ẵ"};

        String[] charWrongE = {"ế", "ề", "é", "ể", "ệ", "è", "ẻ", "ẽ", "ẹ"};
        String[] charWrongEFix = {"ế", "ề", "é", "ể", "ệ", "è", "ẻ", "ẽ", "ẹ"};

        String[] charWrongI = {"ỉ", "í", "ĩ", "ị", "ì"};
        String[] charWrongIFix = {"ỉ", "í", "ĩ", "ị", "ì"};

        String[] charWrongO = {"ớ", "ờ", "ò", "ồ", "ố", "ó", "ọ", "ợ", "ỡ", "ỗ", "ộ", "ỏ", "ở", "õ", "ổ"};
        String[] charWrongOFix = {"ớ", "ờ", "ò", "ồ", "ố", "ó", "ọ", "ợ", "ỡ", "ỗ", "ộ", "ỏ", "ở", "õ", "ỗ"};

        String[] charWrongU = {"ự", "ú", "ử", "ụ", "ữ", "ù", "ừ", "ủ", "ứ", "ũ"};
        String[] charWrongUFix = {"ự", "ú", "ử", "ụ", "ữ", "ù", "ừ", "ủ", "ứ", "ũ"};

        String[] charWrongY = {"ý", "ỷ", "ỳ", "ỹ"};
        String[] charWrongYFix = {"ý", "ỷ", "ỳ", "ỹ"};

        String[] charWrong = concatenate(charWrongA, charWrongE, charWrongI, charWrongO, charWrongU, charWrongY);
        String[] charWrongFix = concatenate(charWrongAFix, charWrongEFix, charWrongIFix, charWrongOFix, charWrongUFix, charWrongYFix);

        for (int i = 0; i < charWrong.length; i++) {
            rs = rs.replace(charWrong[i], charWrongFix[i]);
        }

        //==============================
        //String encodeVietnameseCombiningAccent1 = "/\\u0300|\\u0301|\\u0303|\\u0309|\\u0323/g";
        //String encodeVietnameseCombiningAccent2 = "/\\u02C6|\\u0306|\\u031B/g,";
        //String textCodes = StringUnicodeEncoderDecoder.encodeStringToUnicodeSequence(text);
        //Pattern pattern = Pattern.compile("/\u0300|\u0301|\u0303|\u0309|\u0323/", Pattern.CASE_INSENSITIVE);
        //Pattern pattern = Pattern.compile("/\u0300|\u0301|\u0303|\u0309|\u0323/", Pattern.CASE_INSENSITIVE);
        Pattern pattern = Pattern.compile("/\u0300|\u0301|\u0303|\u0309|\u0323|\u02C6|\u0306|\u031B/|\u0340|\u0341", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(rs);

//        boolean matchFound = matcher.find();
//        if(matchFound) {
//          //System.out.println("Match found");
//          rs += ";wrong character";
//        } else {
//          //System.out.println("Match not found");
//        }     
        // Check all occurrences
        while (matcher.find()) {
            //System.out.println("Found wrong: " + matcher.group() + " - " +  matcher.start() + " - " + matcher.end());
            String wordWrong = rs.substring((matcher.start() - 1), (matcher.end() - 1)) + matcher.group();
            rs += ";\"" + wordWrong + "\"";
        }

        //===============================
        //String tmpCheck = rs.replaceAll("[\\w]+", "");
        //https://stackoverflow.com/questions/6198986/how-can-i-replace-non-printable-unicode-characters-in-java
//        String tmpCheck = rs.replaceAll("[^\\x00-\\x7F]", "");
//        tmpCheck = tmpCheck.replaceAll("[\\w]+", "");
//        
//        if (!tmpCheck.isEmpty()) {
//            rs += ";Wrong: " + tmpCheck;
//        }
//
        return rs;
    }

    // Method to concatenate multiple arrays in Java 8 and above
    public String[] concatenate(String[]... arrays) {
        return Stream.of(arrays)
                .flatMap(Stream::of) // or, use `Arrays::stream`
                .toArray(String[]::new);
    }

    private void writeUnicodeJava8(String fileName, List<String> lines) {

        Path path = Paths.get(fileName);

        try (BufferedWriter writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {

            for (String line : lines) {
                writer.append(line);
                writer.newLine();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void downloadTest(String url, String file) {
        try {
            URL obj = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
            conn.setReadTimeout(5000);
            conn.addRequestProperty("Accept-Language", "en-US,en;q=0.8");
            conn.addRequestProperty("User-Agent", "Mozilla");
            conn.addRequestProperty("Referer", "google.com");

            conn.setDoOutput(true);

            OutputStreamWriter w = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");

            w.write("SOME_JSON_STRING_HERE");
            w.close();

            System.out.println("Request URL ... " + url);

            int status = conn.getResponseCode();

            System.out.println("Response Code ... " + status);

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuffer html = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                html.append(inputLine);
            }

            in.close();
            conn.disconnect();

            System.out.println("URL Content... \n" + html.toString());
            System.out.println("Done");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getTranslateVn(String vocabulary) {
        String translateVn = "";
        try {
            String referrerLink = "https://translate.google.com/";
            String link = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=vi&dt=t&q=" + vocabulary;
            System.out.println("link: " + link);
            Document doc = Jsoup.connect(link)
                    .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36")
                    .referrer(referrerLink)
                    .ignoreContentType(true)
                    .timeout(10000)
                    .header("content-type", "application/json")
                    .get();

            translateVn = doc.text();
            System.out.println("translateVn: " + translateVn);
        } catch (IOException ex) {
            Logger.getLogger(DownloadWebFromUrl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return translateVn;
    }

    private String getFolderProcess(String vocabulary) {
        String subFolder = "";
        String fristChar = vocabulary.substring(0, 1);
        if (UtilityString.isNumberic(fristChar)) {
            subFolder = "0_number\\";
        } else if (UtilityString.isAlphabet(fristChar)) {
            subFolder = "" + fristChar + "\\";
        } else {
            subFolder = "0_other\\";
        }

        return subFolder;
    }

    private void processEnglishGoogleData(String filePath, String vocabulary) {
        System.out.println("filePath: " + filePath);
        List<String> lines = new ArrayList<>();
        //read file into stream, try-with-resources
        try (Stream<String> stream = Files.lines(Paths.get(filePath))) {
            lines = stream.collect(Collectors.toList());

        } catch (IOException e) {
            e.printStackTrace();
        }

        String jsonRoot = "";
        for (String line : lines) {
            if (line.contains("[[\"wrb.fr\",")) {
                jsonRoot = line;
                break;
            }
        }

        if (!jsonRoot.isEmpty()) {
            JSONArray jsonRootArray = new JSONArray(jsonRoot);
            JSONArray jsonRootArray0 = jsonRootArray.getJSONArray(0);
            //System.out.println(jsonRootArray0);
            List<ObjWord> objWordList = new ArrayList<>();
            List<String> frequencyList = new ArrayList<>();

            for (int i = 0; i < jsonRootArray0.length(); i++) {
                if (jsonRootArray0.get(i) instanceof String) {
                    if (jsonRootArray0.getString(i).contains(vocabulary)) {
                        String dataTranslate = jsonRootArray0.getString(i);
                        //System.out.println(dataTranslate);

                        JSONArray jsonDataTranslateArray = new JSONArray(dataTranslate);
                        for (int j = 0; j < jsonDataTranslateArray.length(); j++) {
                            if (jsonDataTranslateArray.get(j) instanceof JSONArray) {

                                JSONArray dataTranslate3Array = jsonDataTranslateArray.getJSONArray(j);

                                if (j == 1) {
                                    frequencyList.clear();
                                    String vnFrist = dataTranslate3Array.getJSONArray(0).getJSONArray(0).getJSONArray(5).getJSONArray(0).getString(0);
                                    JSONArray dataTranslate3ArraySub1 = dataTranslate3Array.getJSONArray(0).getJSONArray(0).getJSONArray(5).getJSONArray(0).getJSONArray(4);
                                    System.out.println(vnFrist);
                                    System.out.println(dataTranslate3ArraySub1);
                                    frequencyList.add(vnFrist);

                                    for (int j1 = 0; j1 < dataTranslate3ArraySub1.length(); j1++) {
                                        JSONArray dataTranslate3ArraySub1A = dataTranslate3ArraySub1.getJSONArray(j1);
                                        String tmpWord = dataTranslate3ArraySub1A.getString(0);
                                        frequencyList.add(tmpWord);
                                        System.out.println("tmpWord: " + tmpWord);

                                    }
                                }

                                if (j == 3) {
                                    for (int k = 0; k < dataTranslate3Array.length(); k++) {
                                        if (dataTranslate3Array.get(k).toString().contains("\"vi\",\"en\"")) {
                                            JSONArray dataTranslate4Array = dataTranslate3Array.getJSONArray(k);
                                            JSONArray dataTranslate5Array = dataTranslate4Array.getJSONArray(0);
                                            //System.out.println(dataTranslate4Array);

                                            for (int l = 0; l < dataTranslate5Array.length(); l++) {
                                                JSONArray dataTranslate6Array = dataTranslate5Array.getJSONArray(l);
                                                String classes = dataTranslate6Array.getString(0);
                                                JSONArray dataTranslate7Array = dataTranslate6Array.getJSONArray(1);

                                                //System.out.println(classes);
                                                //System.out.println(dataTranslate7Array);
                                                for (int m = 0; m < dataTranslate7Array.length(); m++) {
                                                    //System.out.println(dataTranslate7Array.getJSONArray(m));
                                                    ObjWord objWord = new ObjWord();
                                                    String vnWord = autoCorrectSpelling(dataTranslate7Array.getJSONArray(m).getString(0));

                                                    objWord.setEn(vocabulary);
                                                    objWord.setEnClass(classes);
                                                    objWord.setVn(vnWord);
                                                    objWord.setFrequency(0);

                                                    for (String tmpFrequency : frequencyList) {
                                                        if (tmpFrequency.equals(objWord.getVn())) {
                                                            objWord.setFrequency(objWord.getFrequency() + 1);
                                                        }
                                                    }

                                                    String result = objWord.getEn() + "↨" + objWord.getEnClass() + "↨" + objWord.getVn() + "↨" + objWord.getFrequency() + "\n";
                                                    System.out.println(result);
                                                    taReadContent.append(result);
                                                    objWordList.add(objWord);
                                                }

                                            }
                                        }

                                    }
                                } else {

                                }

                            }
                        }
                    }
                }

                //JSONObject object = jsonRootArray.getJSONObject(i);
                //System.out.println(object);
                //System.out.println(object.getString("No"));
                //System.out.println(object.getString("Name"));
            }
        }

    }
    
    private void autoDownloadSentenceDict(String link) {
        try {
            Document document = Jsoup.connect(link)
                    .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36")
                    .header("content-type", "text/html; charset=UTF-8")
                    .method(Method.GET)
                    .timeout(10000)
                    .get();

            Elements listLinkSentence = document.select("li[class=dotline] > a");

            if (!listLinkSentence.isEmpty()) {
                for (Element itemLinkSentence : listLinkSentence) {
                    System.out.println(itemLinkSentence.attr("abs:href"));
                    autoDownloadSentenceDictSub001(itemLinkSentence.attr("abs:href"));
                    Thread.sleep(2000);
                }
            } else {
                System.out.println("==========================================");
                System.out.println("== END BY INDEX =================================");
                System.out.println("==========================================");
            }

        } catch (IOException e) {
            System.out.println("downloadUsingJSOUP error: " + e.getMessage());
        } catch (InterruptedException ex) {
            Logger.getLogger(DownloadWebFromUrl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }   
    
    private void autoDownloadSentenceDictSub001(String link) {
        try {
            Thread.sleep(2000);
            
            Document document = Jsoup.connect(link)
                    .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36")
                    .header("content-type", "text/html; charset=UTF-8")
                    .method(Method.GET)
                    .timeout(10000)
                    .get();
            
            List<String> data = new ArrayList<>();
            
            Elements listSentence = document.select("div[id=all] > div");
            Elements listLink = document.select("div > a");
            Element elementInfo = document.select("div[class=viewbox] > div[class=info]").first();
            Element elementTitle = document.select("div[class=viewbox] > div[class=title] > h2").first();
            Element elementPageNumber = document.select("input[id=goPageNo]").first();
            
            String title = link.substring(link.lastIndexOf("/") + 1);
            if (elementTitle != null) {
                if (elementPageNumber != null && !elementPageNumber.attr("value").isEmpty() && !elementTitle.text().isEmpty()) {
                    title = elementTitle.text().trim() + "_" + elementPageNumber.attr("value");
                } else if (elementPageNumber == null && !elementTitle.text().isEmpty()) {
                    title = elementTitle.text().trim() + "_1";
                }
            }
            String subFolder = getFolderProcess(title);
            
            String nextLink = "";
            String pathWorkingFolder = tfFolderWorking.getText().trim();
            String pathFileSave = pathWorkingFolder + subFolder + "\\" + title + ".txt";

            String info = "";
            if (elementInfo != null) {
                info = elementInfo.text();
                info = info.replace("Posted:", " | Posted: ");
                info = info.replace("Updated:", " | Updated: ");                
            }
            
            data.add("►" + link);
            data.add("►" + info);
            
            if (!listSentence.isEmpty()) {
                for (Element itemSentence : listSentence) {
                    System.out.println(itemSentence.text());
                    data.add(itemSentence.text().trim());
                }
                
                if (UtilityFileFolder.isExistsFile(pathFileSave)) {
                    System.out.println("==========================================");
                    System.out.println("File: " + pathFileSave + " - is exists!");
                    System.out.println("==========================================");
                }                
                writeUnicodeJava8(pathFileSave, data);
                //==
                for (Element itemLink : listLink) {
                    if (itemLink.text().contains("next›")) {
                        System.out.println("Next: " + itemLink.attr("abs:href"));
                        nextLink = itemLink.attr("abs:href");
                        break;
                    }
                }

                if (!nextLink.isEmpty()) {
                    autoDownloadSentenceDictSub001(nextLink);
                } else {
                    System.out.println("==========================================");
                    System.out.println("== END SENTENCE ==========================");
                    System.out.println("==========================================");                    
                }

            } else {
                System.out.println("==========================================");
                System.out.println("== END WEB ==========================");
                System.out.println("==========================================");
            }

        } catch (IOException e) {
            System.out.println("downloadUsingJSOUP error: " + e.getMessage());
        } catch (InterruptedException ex) {
            Logger.getLogger(DownloadWebFromUrl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }       

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tfFReqId = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        taVocabularyList = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        tfFolderWorking = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        taReadContent = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        btBrittanica = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tfFReqId.setText("MkEWBc");

        jLabel1.setText("F_Req_Id");

        taVocabularyList.setColumns(20);
        taVocabularyList.setRows(5);
        jScrollPane1.setViewportView(taVocabularyList);

        jLabel2.setText("Vocabulary List");

        jLabel3.setText("Folder");

        tfFolderWorking.setEditable(false);
        tfFolderWorking.setText("D:\\Data\\SentenceDict\\");

            taReadContent.setColumns(20);
            taReadContent.setRows(5);
            jScrollPane2.setViewportView(taReadContent);

            jLabel4.setText("Read Content");

            jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

            jButton1.setText("Download Google Translate");
            jButton1.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jButton1ActionPerformed(evt);
                }
            });

            jButton2.setText("Read Google Translate");
            jButton2.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jButton2ActionPerformed(evt);
                }
            });

            jButton3.setText("Insert to Database");
            jButton3.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jButton3ActionPerformed(evt);
                }
            });

            btBrittanica.setText("Download Brittanica");
            btBrittanica.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    btBrittanicaActionPerformed(evt);
                }
            });

            jButton4.setText("Download Sentence Dict");
            jButton4.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jButton4ActionPerformed(evt);
                }
            });

            jButton5.setText("Read Sentence Dict");
            jButton5.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jButton5ActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
            jPanel1.setLayout(jPanel1Layout);
            jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(btBrittanica, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton3)
                    .addContainerGap())
            );
            jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton2)
                        .addComponent(btBrittanica)
                        .addComponent(jButton4)
                        .addComponent(jButton3))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton1)
                        .addComponent(jButton5))
                    .addContainerGap(26, Short.MAX_VALUE))
            );

            javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
            getContentPane().setLayout(layout);
            layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel3)
                                    .addGap(0, 0, Short.MAX_VALUE))
                                .addComponent(tfFolderWorking))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel1)
                                .addComponent(tfFReqId, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel2)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel4)
                                    .addGap(0, 0, Short.MAX_VALUE))
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 630, Short.MAX_VALUE))))
                    .addContainerGap())
            );
            layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(jLabel3))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tfFReqId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tfFolderWorking, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 282, Short.MAX_VALUE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jScrollPane1)))
                    .addContainerGap())
            );

            pack();
        }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        //String urlLink = "https://translate.google.com/?hl=en&tab=TT&sl=en&tl=vi&text=school&op=translate
        //String urlLink = "https://translate.google.com/?sl=en&tl=vi&text=school&op=translate";
        //downloadUsingNIO(urlLink, "D:\\Tmp\\Test\\web1.html");
        //downloadUsingStream(urlLink, "D:\\Tmp\\Test\\web2.html");
        //downloadUsingHTTP(urlLink, "D:\\Tmp\\Test\\web3.html");

        String folderWorking = tfFolderWorking.getText().trim();
        String[] vocabularyList = taVocabularyList.getText().split("\n");

        try {
            int index = 1;
            for (String vocabulary : vocabularyList) {
                String subFolder = getFolderProcess(vocabulary);
                System.out.println(index + " ==================");
                String filePath = folderWorking + subFolder + vocabulary + ".txt";
                System.out.println("filePath: " + filePath);
                
                if (!UtilityFileFolder.isExistsFile(filePath)) {
                    if (index % 2 == 0) {
                        TimeUnit.SECONDS.sleep(2);
                    } else {
                        TimeUnit.SECONDS.sleep(3);
                    }
                }                  

                downloadUsingJSOUP(vocabulary, filePath);
                index++;
                
                //downloadTest(urlLink, "D:\\Tmp\\Test\\web5.html");
                //getTranslateVn("school");
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(DownloadWebFromUrl.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String[] vocabularyList = taVocabularyList.getText().split("\n");
        String folderWorking = tfFolderWorking.getText().trim();
        if (!folderWorking.endsWith("\\")) {
            folderWorking += "\\";
        }
        taReadContent.setText("");

        for (String vocabulary : vocabularyList) {
            System.out.println("=============================================");
            String subFolder = getFolderProcess(vocabulary);
            String filePath = folderWorking + subFolder + vocabulary + ".txt";
            processEnglishGoogleData(filePath, vocabulary);
        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        List<String> vocabularyList = new ArrayList<>();
        vocabularyList.addAll(Arrays.asList(StringUtils.stripAll(taVocabularyList.getText().split("[\\r\\n]"))));
        vocabularyList.removeAll(Collections.singleton(null));
        vocabularyList.removeAll(Collections.singleton(""));
        UtilityList.removeDuplication(vocabularyList);

        List<String> readContentList = new ArrayList<>();
        readContentList.addAll(Arrays.asList(StringUtils.stripAll(taReadContent.getText().split("[\\r\\n]"))));
        readContentList.removeAll(Collections.singleton(null));
        readContentList.removeAll(Collections.singleton(""));
        UtilityList.removeDuplication(readContentList);

        List<ObjWord> objWordList = new ArrayList<>();
        for (String tmp : readContentList) {
            String[] arrTmp = tmp.split("↨");
            ObjWord objWord = new ObjWord();
            objWord.setEn(arrTmp[0]);
            objWord.setEnClass(arrTmp[1]);
            objWord.setVn(arrTmp[2]);
            objWord.setFrequency(Integer.parseInt(arrTmp[3]));

            objWordList.add(objWord);

        }

        insertDictionaryEnWordClasses(objWordList);
        insertDictionaryEnWordTranslateToVn(objWordList);
        //List<ObjDictionaryEnWord> ObjDictionaryEnWordList = getListIdOfWord(inputRoot);
        //System.out.println(ObjDictionaryEnWordList);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void btBrittanicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btBrittanicaActionPerformed
        //String urlRoot = "https://brittanica.info/aula/making-tacos-with-my-family/";
        String urlBrittanica = "https://brittanica.info/aula/making-tacos-with-my-family/";
        autoDownloadBrittanica(urlBrittanica);

    }//GEN-LAST:event_btBrittanicaActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        String link = "https://sentencedict.com/word/list_";
        
        for (int i = 31; i <= 50; i++) {
            String tmpLink = link + i + ".html";
            System.out.println("Page: " + i + " - " + "tmpLink: " + tmpLink);
            autoDownloadSentenceDict(tmpLink);
        }

    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        String folderWorking = tfFolderWorking.getText().trim();
        List<String> listPathFile = UtilityFileFolder.getListPathFileInFolder(folderWorking, ".txt", true);
        List<String> data = new ArrayList<>();
        List<String> dataFile = new ArrayList<>();
        
        for (String pathFile : listPathFile) {
            data.clear();
            dataFile.clear();

            dataFile = UtilityFileFolder.readRowTextFileToListString(pathFile);
            for (String rowText : dataFile) {
                rowText = UtilityString.trimSpace(rowText);
                if (!rowText.isEmpty() && !rowText.startsWith("►")) {
                    data.add(rowText);
                }
            }
            
            System.out.println("== Path file: " + pathFile);
            System.out.println("== Total insert: " + data.size());
            insertDictionaryEnSentences(data);
        }
        
        
        
    }//GEN-LAST:event_jButton5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DownloadWebFromUrl.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DownloadWebFromUrl.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DownloadWebFromUrl.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DownloadWebFromUrl.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new DownloadWebFromUrl().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btBrittanica;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea taReadContent;
    private javax.swing.JTextArea taVocabularyList;
    private javax.swing.JTextField tfFReqId;
    private javax.swing.JTextField tfFolderWorking;
    // End of variables declaration//GEN-END:variables
}
