/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.event.HyperlinkEvent;
import object.ObjWebtoonsComment;
import object.ObjWebtoonsEpisode;
import object.ObjWebtoonsStory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import utility.IDM;
import utility.UtilityString;

/**
 *
 * @author bnson
 */
public class Webtoons extends javax.swing.JFrame {

    private final IDM idm;
    private final String defaultFolderDownload;
    /**
     * Creates new form Download
     */
    public Webtoons() {
        initComponents();
        
        idm = new IDM();
        defaultFolderDownload = "F:\\Video\\Anime Hentai\\";
        
        epShowHtml.addHyperlinkListener((HyperlinkEvent e) -> {
            if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
                if (Desktop.isDesktopSupported()) {
                    try {
                        Desktop.getDesktop().browse(e.getURL().toURI());
                    } catch (URISyntaxException | IOException ex) {
                        Logger.getLogger(Webtoons.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        });
    }
    
    private String processString(String str) {
        String strProcess = UtilityString.trimSpace(str);
        
        strProcess = strProcess.replace("::", ":");
        strProcess = strProcess.replace("\"", "“");
        
        strProcess = UtilityString.trimSpace(strProcess);
        return strProcess;
    }
    
    private void getVideoInformationWebToons(String linkWeb) {
        try {
            ObjWebtoonsStory objWebtoonsStory = new ObjWebtoonsStory();
            Document doc;
            Pattern p;
            Matcher m;
            int limitPage = 0;
            
            if (!tfLimitPage.getText().trim().isEmpty()) {
                limitPage = Integer.parseInt(tfLimitPage.getText().trim());
            }
            
            //==================================
            linkWeb = tfLinkWeb.getText().trim();
            doc = Jsoup.connect(linkWeb)
                    .data("query", "Java")
                    .userAgent("Mozilla/5.0")
                    .cookie("auth", "token")
                    .timeout(10000)
                    .get();

            Element storyName = doc.select("meta[property=og:title]").first();
            if (storyName.attr("content") != null) {
                objWebtoonsStory.setName(storyName.attr("content"));   
                System.out.println("Story Name: " + objWebtoonsStory.getName());
            }
            
            objWebtoonsStory.setLink(linkWeb);

            Elements storyPages = doc.select("div[class=paginate] > a");
            int storyPagesIndex = 1;
            for (Element storyPage : storyPages) {
                System.out.println("storyPage: " + storyPage.attr("abs:href"));

                if (storyPagesIndex == 1) {
                    objWebtoonsStory.getLinkPages().add(linkWeb + "&page=1");
                } else {
                    objWebtoonsStory.getLinkPages().add(storyPage.attr("abs:href"));
                }
                
                if (limitPage != 0) {
                    if (storyPagesIndex == limitPage) {
                        break;
                    }
                }

                storyPagesIndex++;
            }
            //===========================
            for (String linkPage : objWebtoonsStory.getLinkPages()) {

                doc = Jsoup.connect(linkPage)
                        .data("query", "Java")
                        .userAgent("Mozilla/5.0")
                        .cookie("auth", "token")
                        .timeout(10000)
                        .get();

                Elements episodes = doc.select("ul[id=_listUl] > li > a");
                for (Element episode : episodes) {
                    ObjWebtoonsEpisode objWebtoonsEpisode = new ObjWebtoonsEpisode();

                    linkWeb = episode.attr("href");
                    System.out.println("Episode link: " + linkWeb);
                    doc = Jsoup.connect(linkWeb)
                            .data("query", "Java")
                            .userAgent("Mozilla/5.0")
                            .cookie("auth", "token")
                            .timeout(10000)
                            .get();

                    String docHtml = doc.html();

                    String apiDomain = "";
                    String apiDomainPattern = "(sApiDomain : ')([^']+)";
                    p = Pattern.compile(apiDomainPattern);
                    m = p.matcher(docHtml);
                    if (m.find()) {
                        apiDomain = m.group(2);
                        //System.out.println("apiDomain: " + apiDomain);
                    }

                    String ticket = "";
                    String ticketPattern = "(sTicket : ')([^']+)";
                    p = Pattern.compile(ticketPattern);
                    m = p.matcher(docHtml);
                    if (m.find()) {
                        ticket = m.group(2);
                        //System.out.println("ticket: " + ticket);
                    }

                    String templateId = "";
                    String templateIdPattern = "(sTemplateId : ')([^']+)";
                    p = Pattern.compile(templateIdPattern);
                    m = p.matcher(docHtml);
                    if (m.find()) {
                        templateId = m.group(2);
                        //System.out.println("ticket: " + templateId);
                    }

                    String language = "";
                    String languagePattern = "(sLanguage : ')([^']+)";
                    p = Pattern.compile(languagePattern);
                    m = p.matcher(docHtml);
                    if (m.find()) {
                        language = m.group(2);
                        //System.out.println("ticket: " + language);
                    }

                    String objectId = "";
                    String objectIdPattern = "(sObjectId : ')([^']+)";
                    p = Pattern.compile(objectIdPattern);
                    m = p.matcher(docHtml);
                    if (m.find()) {
                        objectId = m.group(2);
                        //System.out.println("objectId: " + objectId);
                    }

                    String consumerKey = "";
                    String consumerKeyPattern = "(sConsumerKey : ')([^']+)";
                    p = Pattern.compile(consumerKeyPattern);
                    m = p.matcher(docHtml);
                    if (m.find()) {
                        consumerKey = m.group(2);
                        //System.out.println("consumerKey: " + consumerKey);
                    }

                    String pageSize = "";
                    String pageSizePattern = "(nPageSize : )([^,]+)";
                    p = Pattern.compile(pageSizePattern);
                    m = p.matcher(docHtml);
                    if (m.find()) {
                        pageSize = m.group(2);
                        //System.out.println("pageSize: " + pageSize);
                    }

                    String replyIndexSize = "";
                    String replyIndexSizePattern = "(nPageSize : )([^,]+)";
                    p = Pattern.compile(replyIndexSizePattern);
                    m = p.matcher(docHtml);
                    if (m.find()) {
                        replyIndexSize = m.group(2);
                        //System.out.println("consumerKey: " + replyIndexSize);
                    }

                    int page = 1;

                    String referrerLink = "";
                    Elements eReferrerLinks = doc.select("link[rel=canonical]");
                    for (Element eReferrerLink : eReferrerLinks) {
                        if (eReferrerLink.attr("href").startsWith("https://www.webtoons.com/")) {
                            referrerLink = eReferrerLink.attr("href");
                            //System.out.println("referrerLink: " + referrerLink);
                            break;
                        }
                    }

                    String linkApiComments = apiDomain
                            + "/web_neo_list_jsonp.json?"
                            + "ticket=" + ticket
                            + "&templateId=" + templateId
                            + "&pool=ncc-cbox"
                            + "&lang=" + language
                            + "&country="
                            + "&objectId=" + objectId
                            + "&categoryId="
                            + "&pageSize=" + pageSize
                            + "&indexSize=" + replyIndexSize
                            + "&groupId="
                            + "&listType=OBJECT"
                            + "&pageType=default"
                            + "&token=null"
                            + "&consumerKey=" + consumerKey
                            + "&snsCode=null"
                            + "&page=" + page
                            + "&refresh=false"
                            + "&sort=NEW";
                    System.out.println("linkApiComments: " + linkApiComments);
                    objWebtoonsEpisode.setEpisodeNumber(episode.child(1).child(0).text());
                    objWebtoonsEpisode.setEpisodeLink(linkWeb);

                    //=========
                    doc = Jsoup.connect(linkApiComments)
                            .data("query", "Java")
                            .userAgent("Mozilla/5.0")
                            .cookie("auth", "token")
                            .referrer(referrerLink)
                            .ignoreContentType(true)
                            .timeout(10000)
                            .get();

                    String jsonString = doc.text();
                    jsonString = jsonString.substring(10, jsonString.length() - 2);
                    //System.out.println("jsonString: " + jsonString);
                    //epShow.setText(jsonString);

                    JSONObject obj = new JSONObject(jsonString);
                    JSONArray commentList = obj.getJSONObject("result").getJSONArray("commentList");
                    for (int i = 0; i < commentList.length(); i++) {
                        String contents = commentList.getJSONObject(i).getString("contents");
                        String regTime = commentList.getJSONObject(i).getString("regTime");

                        int replyCount = commentList.getJSONObject(i).getInt("replyCount");
                        int sortValue = commentList.getJSONObject(i).getInt("sortValue");

                        //System.out.println("contents: " + contents);

                        ObjWebtoonsComment objWebtoonsComment = new ObjWebtoonsComment();
                        objWebtoonsComment.setContents(contents);
                        objWebtoonsComment.setSortValue(sortValue);
                        objWebtoonsComment.setRegTime(regTime);
                        objWebtoonsComment.setReplyCount(replyCount);
                        objWebtoonsComment.setLinkEpisodeReference(linkWeb);
                        objWebtoonsComment.setEpisodeNumberReference(episode.child(1).child(0).text());

                        objWebtoonsEpisode.getObjWebtoonsComments().add(objWebtoonsComment);
                    }

                    objWebtoonsStory.getEpisodes().add(objWebtoonsEpisode);

                }
            }
            
            //===========================
            //Gson gson = new GsonBuilder().setPrettyPrinting().create();
            //String jsonData = gson.toJson(objWebtoonsStory);     
            //System.out.println("jsonData: " + jsonData);
            
            String html = "";
            //String htmlTable = "<tr><td>$1</td></tr>";
            String htmlTable = "<tr><td width=\"20%\"><a href='$1'><h3>$2</h3></a></td><td width=\"7%\">$3</td><td>$4</td></tr>";
            String htmlTableHyperLink = "<tr><td><a href='$1'><h1>$2</h1></a></td></tr>";
            String currentDate = java.time.LocalDate.now().toString();
            System.out.println("currentDate: " + currentDate);
            
            //-- DISPLAY COMMENT BY CHAPTER.
//            for (ObjWebtoonsEpisode episode : objWebtoonsStory.getEpisodes()) {
//
//                    
//                String episodeHtml = htmlTableHyperLink.replace("$1", episode.getEpisodeLink()).replace("$2", episode.getEpisodeNumber());
//                html += episodeHtml + "\r\n";
//                Collections.sort(episode.getObjWebtoonsComments(), Comparator.comparing((objWebtoonsComment) -> objWebtoonsComment.getSortValue()));
//                Collections.reverse(episode.getObjWebtoonsComments());
//                for (ObjWebtoonsComment comment : episode.getObjWebtoonsComments()) {
//                    String commentHtml = "";
//                    if (comment.getRegTime().contains(currentDate)) {
//                        commentHtml = htmlTable.replace("$1", "<font color=\"orange\">" + comment.getContents() + "<br>(" + comment.getRegTime() + ")(Replies " + comment.getReplyCount() + ")</font><br>");
//                    } else {
//                        commentHtml = htmlTable.replace("$1", comment.getContents() + "<br>(" + comment.getRegTime() + ")(Replies " + comment.getReplyCount() + ")<br>");
//                    }
//                    
//                    html += commentHtml + "\r\n";
//                    
//                }
//            }
            

            //-- DISPLOY COMMENT BY DATE.            
            List<ObjWebtoonsComment> listObjWebtoonsComment = new ArrayList<>();
            for (ObjWebtoonsEpisode episode : objWebtoonsStory.getEpisodes()) {
                listObjWebtoonsComment.addAll(episode.getObjWebtoonsComments());
            }
            
            Collections.sort(listObjWebtoonsComment, Comparator.comparing((objWebtoonsComment) -> objWebtoonsComment.getRegTime()));
            Collections.reverse(listObjWebtoonsComment);
            for (ObjWebtoonsComment comment : listObjWebtoonsComment) {
                String commentHtml = htmlTable.replace("$1", comment.getLinkEpisodeReference()).replace("$2", comment.getEpisodeNumberReference());
                
                commentHtml = commentHtml.replace("$3", comment.getRegTime().replace("T", "<br>"));
                if (comment.getRegTime().contains(currentDate)) {
                    commentHtml = commentHtml.replace("$4", "<font color=\"orange\">" + comment.getContents() + "<br>(Replies " + comment.getReplyCount() + ")</font><br>");
                } else {
                    commentHtml = commentHtml.replace("$4", comment.getContents() + "<br>(Replies " + comment.getReplyCount() + ")<br>");
                }
                html += commentHtml + "\r\n";
            }
            
            html = "<html><head></head><body><table style=\"width:100%\" cellpadding=\"5\"  cellspacing=\"5\" border=\"1\">" + html + "</table></body></html>";
            //System.out.println("html: " + html);
            epShowHtml.setText(html);
            epShowHtml.setCaretPosition(0);

        } catch (IOException ex) {
            Logger.getLogger(Webtoons.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        tfLinkWeb = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        epShowHtml = new javax.swing.JEditorPane();
        jPanel1 = new javax.swing.JPanel();
        btGetInformation = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        tfLimitPage = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Webtoon");

        jLabel1.setText("Link Web");

        epShowHtml.setEditable(false);
        epShowHtml.setContentType("text/html"); // NOI18N
        epShowHtml.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jScrollPane2.setViewportView(epShowHtml);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btGetInformation.setText("Get Information");
        btGetInformation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btGetInformationActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btGetInformation)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btGetInformation)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel2.setText("Limit Page:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfLinkWeb, javax.swing.GroupLayout.DEFAULT_SIZE, 763, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfLimitPage, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(tfLinkWeb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(tfLimitPage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 392, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btGetInformationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btGetInformationActionPerformed
        String linkWeb = tfLinkWeb.getText().trim();
        
        if (linkWeb.contains("webtoons.com")) {
            getVideoInformationWebToons(linkWeb);
        }        
        
    }//GEN-LAST:event_btGetInformationActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Webtoons.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Webtoons.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Webtoons.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Webtoons.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Webtoons().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btGetInformation;
    private javax.swing.JEditorPane epShowHtml;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField tfLimitPage;
    private javax.swing.JTextField tfLinkWeb;
    // End of variables declaration//GEN-END:variables

}
