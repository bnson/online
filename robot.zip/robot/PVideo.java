/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import com.google.gson.Gson;
import com.ibm.icu.text.SimpleDateFormat;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javax.swing.JOptionPane;
import object.ObjPVideo;
import object.ObjPerson;
import object.ObjWord;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DurationFormatUtils;
import utility.UtilityFileFolder;
import utility.UtilityString;

/**
 *
 * @author bnson
 */
public class PVideo extends javax.swing.JFrame {

    private final String BALABOLKA = "C:\\Program Files (x86)\\Balabolka\\balabolka.exe";
    private final String FFMPEG_PATH = "D:\\Application\\ffmpeg\\ffmpeg-20171115-ff8f40a-win64-static\\bin\\ffmpeg";
    private final FFmpeg ffmpeg;
    //==
    private Gson gson;
    private String pathFolder;

    private ObjPerson personMale;
    private ObjPerson personFemale;
    private ObjPerson person1;
    private ObjPerson person2;
    private ObjPerson person3;
    private ObjPerson person4;
    private List<ObjPerson> personList;

    private String videoOption;
    
    private boolean enabledPronounce;
    private boolean enabledVietSub;
    
    //====
    ObjPVideo videoEnglish;
    ObjPVideo videoEnglishConversation;
    ObjPVideo videoEnglishAndVietnameseSubtitle;
    ObjPVideo videoBilingualVietnameseEnglish;
    ObjPVideo videoEnglishListening;
    ObjPVideo videoLearnEnglish;
    ObjPVideo videoReadEnglish;

    public PVideo() {
        initComponents();
        ffmpeg = new FFmpeg(FFMPEG_PATH);
    }

    private void setSetting() {

        pathFolder = tfPathFolder.getText().trim();
        if (!pathFolder.endsWith("\\")) {
            pathFolder = pathFolder + "\\";
        }

        //==
        enabledPronounce = cbEnabledPronounce.isSelected();
        enabledVietSub = cbEnabledVietSub.isSelected();
        
        //==
        videoOption = cbVideoOption.getSelectedItem().toString().toLowerCase();

        //==
        videoEnglish = new ObjPVideo("VideoEnglish", pathFolder);

        videoBilingualVietnameseEnglish = new ObjPVideo("VideoBilingualVietnameseEnglish", pathFolder);
        //videoBilingualVietnameseEnglish.setTitleVnEndfix("`Song ngữ");
        
        videoLearnEnglish = new ObjPVideo("VideoLearnEnglish", pathFolder);
        videoReadEnglish = new ObjPVideo("VideoReadEnglish", pathFolder);

        videoEnglishAndVietnameseSubtitle = new ObjPVideo("VideoEnglishAndVietnameseSubtitle", pathFolder);
        videoEnglishAndVietnameseSubtitle.setTitleVnEndfix("`Tiếng Anh và phụ đề Việt");

        videoEnglishListening = new ObjPVideo("VideoEnglishListening", pathFolder);
        videoEnglishListening.setTitleVnEndfix("`Luyện nghe tiếng Anh");
        videoEnglishListening.setHiddenText(true);

        videoEnglishConversation = new ObjPVideo("VideoEnglishConversation", pathFolder);

        //==
        personMale = new ObjPerson("Male", cbVoiceDefaultMale.getSelectedItem().toString(), 0, -3, 100);
        personFemale = new ObjPerson("Female", cbVoiceDefaultFemale.getSelectedItem().toString(), 0, 3, 100);
        person1 = new ObjPerson(tfPerson1.getText().trim(), cbVoicePerson1.getSelectedItem().toString(), 0, 0, 100);
        person2 = new ObjPerson(tfPerson2.getText().trim(), cbVoicePerson2.getSelectedItem().toString(), 0, 0, 100);
        person3 = new ObjPerson(tfPerson3.getText().trim(), cbVoicePerson3.getSelectedItem().toString(), 0, 0, 100);
        person4 = new ObjPerson(tfPerson4.getText().trim(), cbVoicePerson4.getSelectedItem().toString(), 0, 0, 100);

        personList = new ArrayList<>();
        personList.add(personMale);
        personList.add(personFemale);
        personList.add(person1);
        personList.add(person2);
        personList.add(person3);
        personList.add(person4);

    }

    private void setSettingVideoObjFileAss(ObjPVideo objPVideo) {
        //== Setting default for ass file.
        objPVideo.getObjFileAss().setPlayResX(Integer.parseInt(tfAssPlayResX.getText().trim()));
        objPVideo.getObjFileAss().setPlayResY(Integer.parseInt(tfAssPlayResY.getText().trim()));

        objPVideo.getObjFileAss().getStyle().setName(cbAssStyleName.getSelectedItem().toString());

        objPVideo.getObjFileAss().getStyle().setvFontname(cbAssFontName.getSelectedItem().toString());
        objPVideo.getObjFileAss().getStyle().setvFontsize(cbAssFontSize.getSelectedItem().toString());

        objPVideo.getObjFileAss().getStyle().setvPrimaryColour(cbAssPrimaryColour.getSelectedItem().toString().split("-")[1].trim());

        objPVideo.getObjFileAss().getStyle().setvAlignment(cbAssAlignment.getSelectedItem().toString().split("-")[0].trim());

        objPVideo.getObjFileAss().getStyle().setvMarginL(tfAssMarginLeft.getText().trim());
        objPVideo.getObjFileAss().getStyle().setvMarginR(tfAssMarginRight.getText().trim());
        objPVideo.getObjFileAss().getStyle().setvMarginV(tfAssMarginVert.getText().trim());

        objPVideo.getObjFileAss().getStyle().setvBold(((chbAssFontBold.isSelected()) ? "-1" : "0"));
        objPVideo.getObjFileAss().getStyle().setvItalic(((chbAssFontItalic.isSelected()) ? "-1" : "0"));
        objPVideo.getObjFileAss().getStyle().setvUnderline(((chbAssFontUnderline.isSelected()) ? "-1" : "0"));
        objPVideo.getObjFileAss().getStyle().setvStrikeOut(((chbAssFontStrikeout.isSelected()) ? "-1" : "0"));

        //== Setting text format for title.
        String title = objPVideo.getObjFileAss().getDialogues().get(0).getText();

        String hiddenText;
        for (int i = 0; i < objPVideo.getObjFileAss().getDialogues().size(); i++) {

            if (objPVideo.isHiddenText() && !objPVideo.getObjFileAss().getDialogues().get(i).getText().equalsIgnoreCase(title)) {
                hiddenText = objPVideo.getObjFileAss().getDialogues().get(i).getText().replaceAll("\\w", "❒");
                objPVideo.getObjFileAss().getDialogues().get(i).setText(hiddenText);
            }            
            
            if (!objPVideo.getType().equalsIgnoreCase("VideoHeader") && !objPVideo.getType().equalsIgnoreCase("VideoFooter")) {
                if (objPVideo.getObjFileAss().getDialogues().get(i).getText().equalsIgnoreCase(title)) {
                    objPVideo.getObjFileAss().getDialogues().get(i).getTextFormatTitle().setFontname(cbFontStyleVideoBodyTitle.getSelectedItem().toString());
                    objPVideo.getObjFileAss().getDialogues().get(i).getTextFormatTitle().setFontsize(cbFontSizeVideoBodyTitle.getSelectedItem().toString());
                    objPVideo.getObjFileAss().getDialogues().get(i).getTextFormatTitle().setPrimaryColour(cbFontColorVideoBodyTitle.getSelectedItem().toString().split("-")[1].trim());
                    objPVideo.getObjFileAss().getDialogues().get(i).setTextFormatTitle();                        
                }
            } else if (i % 2 != 0) {
                objPVideo.getObjFileAss().getDialogues().get(i).setMarginL(tfVideoBodyTextRow1MarginsLeft.getText().trim());
                objPVideo.getObjFileAss().getDialogues().get(i).setMarginR(tfVideoBodyTextRow1MarginsRight.getText().trim());
                objPVideo.getObjFileAss().getDialogues().get(i).setMarginV(tfVideoBodyTextRow1MarginsVert.getText().trim());
            } else {
                objPVideo.getObjFileAss().getDialogues().get(i).setMarginL(tfVideoBodyTextRow2MarginsLeft.getText().trim());
                objPVideo.getObjFileAss().getDialogues().get(i).setMarginR(tfVideoBodyTextRow2MarginsRight.getText().trim());
                objPVideo.getObjFileAss().getDialogues().get(i).setMarginV(tfVideoBodyTextRow2MarginsVert.getText().trim());
            }

            objPVideo.getObjFileAss().getDialogues().get(i).getTextFormatRow1().setFontname(cbFontStyleVideoBodyRow1.getSelectedItem().toString());
            objPVideo.getObjFileAss().getDialogues().get(i).getTextFormatRow1().setFontsize(cbFontSizeVideoBodyRow1.getSelectedItem().toString());
            objPVideo.getObjFileAss().getDialogues().get(i).getTextFormatRow1().setPrimaryColour(cbFontColorVideoBodyRow1.getSelectedItem().toString().split("-")[1].trim());

            objPVideo.getObjFileAss().getDialogues().get(i).getTextFormatRow2().setFontname(cbFontStyleVideoBodyRow2.getSelectedItem().toString());
            objPVideo.getObjFileAss().getDialogues().get(i).getTextFormatRow2().setFontsize(cbFontSizeVideoBodyRow2.getSelectedItem().toString());
            objPVideo.getObjFileAss().getDialogues().get(i).getTextFormatRow2().setPrimaryColour(cbFontColorVideoBodyRow2.getSelectedItem().toString().split("-")[1].trim());

            objPVideo.getObjFileAss().getDialogues().get(i).getTextFormatRow3().setFontname(cbFontStyleVideoBodyRow3.getSelectedItem().toString());
            objPVideo.getObjFileAss().getDialogues().get(i).getTextFormatRow3().setFontsize(cbFontSizeVideoBodyRow3.getSelectedItem().toString());
            objPVideo.getObjFileAss().getDialogues().get(i).getTextFormatRow3().setPrimaryColour(cbFontColorVideoBodyRow3.getSelectedItem().toString().split("-")[1].trim());

            objPVideo.getObjFileAss().getDialogues().get(i).setTextFormatRow();

            System.out.println("Dialogues text line: " + objPVideo.getObjFileAss().getDialogues().get(i).getText());

        }
    }

    private boolean makeMp3(String fileAudioTxt, String fileAudioMp3) {
        System.out.println("== Make MP3 file...");
        try {
            ProcessBuilder process = new ProcessBuilder("cmd.exe", "/c", "start", "chcp", "65001", "&", BALABOLKA, "-msq", fileAudioTxt, fileAudioMp3);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }

            if (p.waitFor() == 0) {
                return true;
            }
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(EnglishV1.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    private String processSpecialCharacter(String text) {
        String rs = StringUtils.trim(text);
        rs = rs.replace("’", "'");
        rs = rs.replace("…", "...");
        return rs;
    }

    private void makeVideo(boolean isAuto) {
        if (!isAuto) {
            setSetting();
        }

        switch (videoOption) {
            case "english":
                createVideo(videoEnglish);
                break;
            case "english listening":
                createVideo(videoEnglishListening);
                break;
            case "english conversation":
                createVideo(videoEnglishConversation);
                break;
            case "english and vietnamese subtitle":
                createVideo(videoEnglishAndVietnameseSubtitle);
                break;
            case "bilingual vietnamese english":
                createVideo(videoBilingualVietnameseEnglish);
                break;
            case "learn english":
                createVideo(videoLearnEnglish);
                break;
            case "read english":
                createVideo(videoReadEnglish);
                break;                
            case "youtube":
                createVideoYouTube();
                break;
            default:
                System.exit(0);
        }

    }
    
    private void settingEnglishConversation() {
        
        cbAssFontName.setSelectedIndex(0);
        cbAssFontSize.setSelectedIndex(6);
        chbAssFontBold.setSelected(true);
        
        cbAssPrimaryColour.setSelectedIndex(1);
        cbAssSecondaryColour.setSelectedIndex(1);
        cbAssOutlineColour.setSelectedIndex(1);
        cbAssBackColour.setSelectedIndex(1);
        
        cbAssAlignment.setSelectedIndex(7);

        tfAssMarginLeft.setText("65");
        tfAssMarginRight.setText("65");
        tfAssMarginVert.setText("500");
        
        
        cbFontSizeVideoBodyTitle.setSelectedIndex(8);
        cbFontColorVideoBodyTitle.setSelectedIndex(2);
        
        cbFontSizeVideoBodyRow1.setSelectedIndex(6);
        cbFontColorVideoBodyRow1.setSelectedIndex(2);
        
        cbFontSizeVideoBodyRow2.setSelectedIndex(6);
        cbFontColorVideoBodyRow2.setSelectedIndex(2);
        
        cbFontSizeVideoBodyRow3.setSelectedIndex(6);
        cbFontColorVideoBodyRow3.setSelectedIndex(2);        
        
    }
    
    private void settingEnglish() {
        
        cbAssFontName.setSelectedIndex(0);
        cbAssFontSize.setSelectedIndex(8);
        chbAssFontBold.setSelected(true);
        
        cbAssPrimaryColour.setSelectedIndex(1);
        cbAssSecondaryColour.setSelectedIndex(1);
        cbAssOutlineColour.setSelectedIndex(1);
        cbAssBackColour.setSelectedIndex(1);
        
        cbAssAlignment.setSelectedIndex(5);

        tfAssMarginLeft.setText("150");
        tfAssMarginRight.setText("150");
        tfAssMarginVert.setText("0");
        
        
        cbFontSizeVideoBodyTitle.setSelectedIndex(12);
        cbFontColorVideoBodyTitle.setSelectedIndex(2);
        
        cbFontSizeVideoBodyRow1.setSelectedIndex(8);
        cbFontColorVideoBodyRow1.setSelectedIndex(2);
        
        cbFontSizeVideoBodyRow2.setSelectedIndex(8);
        cbFontColorVideoBodyRow2.setSelectedIndex(2);
        
        cbFontSizeVideoBodyRow3.setSelectedIndex(8);
        cbFontColorVideoBodyRow3.setSelectedIndex(2);      
        
        tfPerson1.setText("");
        tfPerson2.setText("");
        tfPerson3.setText("");
        tfPerson4.setText("");
        
    }    
    
    private void settingHeader() {
        
        cbAssFontName.setSelectedIndex(0);
        cbAssFontSize.setSelectedIndex(8);
        chbAssFontBold.setSelected(true);
        
        cbAssPrimaryColour.setSelectedIndex(1);
        cbAssSecondaryColour.setSelectedIndex(1);
        cbAssOutlineColour.setSelectedIndex(1);
        cbAssBackColour.setSelectedIndex(1);
        
        cbAssAlignment.setSelectedIndex(4);

        tfAssMarginLeft.setText("50");
        tfAssMarginRight.setText("50");
        tfAssMarginVert.setText("0");
        
        
        cbFontSizeVideoBodyTitle.setSelectedIndex(8);
        cbFontColorVideoBodyTitle.setSelectedIndex(2);
        
        cbFontSizeVideoBodyRow1.setSelectedIndex(8);
        cbFontColorVideoBodyRow1.setSelectedIndex(2);
        
        cbFontSizeVideoBodyRow2.setSelectedIndex(6);
        cbFontColorVideoBodyRow2.setSelectedIndex(2);
        
        cbFontSizeVideoBodyRow3.setSelectedIndex(6);
        cbFontColorVideoBodyRow3.setSelectedIndex(2);      
        
        tfPerson1.setText("");
        tfPerson2.setText("");
        tfPerson3.setText("");
        tfPerson4.setText("");
        
        cbEnabledPronounce.setSelected(false);
        cbEnabledVietSub.setSelected(false);
        
    }      
    
    private void settingBilingualVietnameseEnglish() {
        cbShowTitleOption.setSelectedIndex(1);
        
        cbAssFontName.setSelectedIndex(0);
        cbAssFontSize.setSelectedIndex(6);
        chbAssFontBold.setSelected(false);
        
        cbAssPrimaryColour.setSelectedIndex(1);
        cbAssSecondaryColour.setSelectedIndex(1);
        cbAssOutlineColour.setSelectedIndex(1);
        cbAssBackColour.setSelectedIndex(1);
        
        cbAssAlignment.setSelectedIndex(5);

        tfAssMarginLeft.setText("60");
        tfAssMarginRight.setText("60");
        tfAssMarginVert.setText("0");
        
        
        cbFontSizeVideoBodyTitle.setSelectedIndex(8);
        cbFontColorVideoBodyTitle.setSelectedIndex(2);
        
        cbFontSizeVideoBodyRow1.setSelectedIndex(6);
        cbFontColorVideoBodyRow1.setSelectedIndex(2);
        
        cbFontSizeVideoBodyRow2.setSelectedIndex(6);
        cbFontColorVideoBodyRow2.setSelectedIndex(3);
        
        cbFontSizeVideoBodyRow3.setSelectedIndex(6);
        cbFontColorVideoBodyRow3.setSelectedIndex(3);      
        
        tfPerson1.setText("");
        tfPerson2.setText("");
        tfPerson3.setText("");
        tfPerson4.setText("");
        
    }        

    private void settingEnglishListening() {
        
        cbAssFontName.setSelectedIndex(0);
        cbAssFontSize.setSelectedIndex(8);
        chbAssFontBold.setSelected(true);
        
        cbAssPrimaryColour.setSelectedIndex(1);
        cbAssSecondaryColour.setSelectedIndex(1);
        cbAssOutlineColour.setSelectedIndex(1);
        cbAssBackColour.setSelectedIndex(1);
        
        cbAssAlignment.setSelectedIndex(5);

        tfAssMarginLeft.setText("100");
        tfAssMarginRight.setText("100");
        tfAssMarginVert.setText("0");
        
        
        cbFontSizeVideoBodyTitle.setSelectedIndex(12);
        cbFontColorVideoBodyTitle.setSelectedIndex(2);
        
        cbFontSizeVideoBodyRow1.setSelectedIndex(8);
        cbFontColorVideoBodyRow1.setSelectedIndex(2);
        
        cbFontSizeVideoBodyRow2.setSelectedIndex(8);
        cbFontColorVideoBodyRow2.setSelectedIndex(3);
        
        cbFontSizeVideoBodyRow3.setSelectedIndex(8);
        cbFontColorVideoBodyRow3.setSelectedIndex(3);      
        
        tfPerson1.setText("");
        tfPerson2.setText("");
        tfPerson3.setText("");
        tfPerson4.setText("");
        
    }          
    
    private void settingEnglishAndVietnameseSubtitle() {
        cbAssFontName.setSelectedIndex(0);
        cbAssFontSize.setSelectedIndex(8);
        chbAssFontBold.setSelected(true);
        
        cbAssPrimaryColour.setSelectedIndex(1);
        cbAssSecondaryColour.setSelectedIndex(1);
        cbAssOutlineColour.setSelectedIndex(1);
        cbAssBackColour.setSelectedIndex(1);
        
        cbAssAlignment.setSelectedIndex(5);

        tfAssMarginLeft.setText("100");
        tfAssMarginRight.setText("100");
        tfAssMarginVert.setText("0");
        
        
        cbFontSizeVideoBodyTitle.setSelectedIndex(12);
        cbFontColorVideoBodyTitle.setSelectedIndex(2);
        
        cbFontSizeVideoBodyRow1.setSelectedIndex(8);
        cbFontColorVideoBodyRow1.setSelectedIndex(2);
        
        cbFontSizeVideoBodyRow2.setSelectedIndex(8);
        cbFontColorVideoBodyRow2.setSelectedIndex(3);
        
        cbFontSizeVideoBodyRow3.setSelectedIndex(8);
        cbFontColorVideoBodyRow3.setSelectedIndex(3);      
        
        tfPerson1.setText("");
        tfPerson2.setText("");
        tfPerson3.setText("");
        tfPerson4.setText("");
        
    }        
    
    
    private void processFolder(String pathProcessFolder) {
        try {
            if (UtilityFileFolder.isExistsFolder(pathProcessFolder)) {
                FileUtils.deleteDirectory(new File(pathProcessFolder));
            }

            if (!UtilityFileFolder.createDirectory(pathProcessFolder)) {
                JOptionPane.showMessageDialog(this, "Can't create folder:\n" + pathProcessFolder, "ERROR", JOptionPane.ERROR_MESSAGE);
                System.exit(0);
            }
        } catch (IOException ex) {
            Logger.getLogger(PVideo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void makeAudioTextEnglishConversation(List<String> linesTextAudio, ObjWord objWord) {
        String tmpVoiceEn = personFemale.readEnglish(objWord.getEn());
        String tmpVoiceEnPause = personFemale.readMute(objWord.getEn());

        for (ObjPerson objPerson : personList) {
            if (!objPerson.getName().isEmpty() && objWord.getEn().startsWith(objPerson.getName())) {
                tmpVoiceEn = objPerson.readEnglish(objWord.getEn());
                tmpVoiceEnPause = objPerson.readMute(objWord.getEn());
                break;
            }
        }

        linesTextAudio.add(tmpVoiceEn);
        linesTextAudio.add(tmpVoiceEnPause);
    }

    
    private void makeAutioTitle(List<String> linesTextAudio, ObjPVideo objPVideo) {
        String lineVn = objPVideo.getTitleVn().trim();
        String lineEn = objPVideo.getTitleEn().trim();
        
        String showTitleOption = cbShowTitleOption.getSelectedItem().toString().toLowerCase();

        switch (showTitleOption) {
            case "title en":
                linesTextAudio.add(personFemale.readMute(lineEn));
                linesTextAudio.add(personFemale.readEnglish(lineEn));
                linesTextAudio.add(personFemale.readMute(lineEn));                  
                break;
            case "title vn":
                linesTextAudio.add(personFemale.readMute(lineVn));
                linesTextAudio.add(lineVn);
                linesTextAudio.add(personFemale.readMute(lineVn));                
                break;
            case "both titles":
                linesTextAudio.add(personFemale.readMute(lineEn) + " ` " + personFemale.readMute(lineVn));
                linesTextAudio.add(personFemale.readMute(lineEn) + " ` " + personFemale.readMute(lineVn));
                linesTextAudio.add(personFemale.readMute(lineEn) + " ` " + personFemale.readMute(lineVn));
                break;
            default:
                linesTextAudio.add(personFemale.readMute(lineEn) + " ` " + personFemale.readMute(lineVn));
                linesTextAudio.add(personFemale.readMute(lineEn) + " ` " + personFemale.readMute(lineVn));
                linesTextAudio.add(personFemale.readMute(lineEn) + " ` " + personFemale.readMute(lineVn));                
        }

    }

    private void makeAudioReadEnglish(List<String> linesTextAudio, ObjWord objWord) {
        String lineVn = objWord.getVn().get(0).trim();
        String lineEn = objWord.getEn();

        if (!lineEn.isEmpty() && !lineVn.isEmpty()) {
            linesTextAudio.add(person1.readEnglish(lineEn) + " ` " + personFemale.readMute(lineVn, 0));
            linesTextAudio.add(person2.readEnglish(lineEn) + " ` " + personFemale.readMute(lineVn, 0));
            linesTextAudio.add(person3.readEnglish(lineEn) + " ` " + personFemale.readMute(lineVn, 0));             
        } else if (lineEn.isEmpty() && !lineVn.isEmpty()) {
            linesTextAudio.add(lineVn);
            linesTextAudio.add(personFemale.readMute(lineVn, 10));
        } else if (!lineEn.isEmpty() && lineVn.isEmpty()) {
            linesTextAudio.add(person1.readEnglish(lineEn));
            linesTextAudio.add(person2.readEnglish(lineEn));
        } else {
            System.exit(0);
        }        
    }
    
    private void makeAudioLearnEnglish(List<String> linesTextAudio, ObjWord objWord) {
        String lineVn = objWord.getVn().get(0).trim();
        String lineEn = objWord.getEn();
        
        if (!lineEn.isEmpty() && !lineVn.isEmpty()) {
            linesTextAudio.add(person1.readMute(lineEn) + " ` " + lineVn);
            linesTextAudio.add(person1.readEnglish(lineEn) + " ` " + personFemale.readMute(lineVn, 0));
            linesTextAudio.add(person2.readEnglish(lineEn) + " ` " + personFemale.readMute(lineVn, 0));
            linesTextAudio.add(person3.readEnglish(lineEn) + " ` " + personFemale.readMute(lineVn, 0));            
        } else if (lineEn.isEmpty() && !lineVn.isEmpty()) {
            linesTextAudio.add(lineVn);
        } else if (!lineEn.isEmpty() && lineVn.isEmpty()) {
            linesTextAudio.add(person1.readEnglish(lineEn));
            linesTextAudio.add(person2.readEnglish(lineEn));
            linesTextAudio.add(person3.readEnglish(lineEn));
        } else {
            System.exit(0);
        }
    }
    
    
    private void makeAudioBilingualVietnameseEnglish(List<String> linesTextAudio, ObjWord objWord) {
        String lineVn = objWord.getVn().get(0).trim();
        
        linesTextAudio.add(person1.readMute(objWord.getEn()) + " ` " + lineVn);
        linesTextAudio.add(person1.readEnglish(objWord.getEn()) + " ` " + personFemale.readMute(lineVn));
        linesTextAudio.add(person2.readEnglish(objWord.getEn()) + " ` " + personFemale.readMute(lineVn));
        linesTextAudio.add(person3.readEnglish(objWord.getEn()) + " ` " + personFemale.readMute(lineVn));
        

    }

    private void makeAudioEnglishAndVietnameseSubtitle(List<String> linesTextAudio, ObjWord objWord, int loop) {
        String lineVn = objWord.getVn().get(0).trim();
        
        linesTextAudio.add(person1.readEnglish(objWord.getEn()) + " ` " + personFemale.readMute(lineVn));
        linesTextAudio.add(person2.readEnglish(objWord.getEn()) + " ` " + personFemale.readMute(lineVn));
        linesTextAudio.add(person3.readEnglish(objWord.getEn()) + " ` " + personFemale.readMute(lineVn));
        
    }

    private void makeAudioTextEnglish(List<String> linesTextAudio, ObjWord objWord) {
        String tmpVoiceEn = personMale.readEnglish(objWord.getEn());
        String tmpVoiceEnPause = personMale.readMute(objWord.getEn());
        
        if (enabledPronounce && objWord.getPronounceUk() != null && !objWord.getPronounceUk().isEmpty()) {
            tmpVoiceEn = tmpVoiceEn + personMale.readMute(" ` " + objWord.getPronounceUk().get(0));
            tmpVoiceEnPause = tmpVoiceEnPause + personMale.readMute(" ` " + objWord.getPronounceUk().get(0));
        }
        
        if (enabledVietSub && objWord.getPronounceUk() != null && !objWord.getPronounceUk().isEmpty()) {
            tmpVoiceEn = tmpVoiceEn + personMale.readMute(" ` " + objWord.getVn().get(0));
            tmpVoiceEnPause = tmpVoiceEnPause + personMale.readMute(" ` " + objWord.getVn().get(0));            
        }

        linesTextAudio.add(tmpVoiceEn);
        linesTextAudio.add(tmpVoiceEnPause);

    }

    public void autoMergeVideo() {
        String fileCover = tfCoverFile.getText().trim();
        List<String> pathFileMp3s = UtilityFileFolder.getListPathFileInFolder(pathFolder, "mp3", false);

        if (fileCover.endsWith(".mp4")) {
            for (int i = 0; i < pathFileMp3s.size(); i++) {
                System.out.println("pathFileMp3s: " + pathFileMp3s.get(i));
                String pathMp4FileOutput = pathFileMp3s.get(i).replace(".mp3", ".mp4");
                ffmpeg.mergeMp3AndMp4ToMp4RepeatMp4(pathFileMp3s.get(i), fileCover, pathMp4FileOutput);
            }            
        }
    }

    public void createVideoYouTube() {
        //====
        videoOption = "header";
        settingHeader();
        makeVideo(true);
        
        videoOption = "bilingual vietnamese english";
        settingBilingualVietnameseEnglish();
        makeVideo(true);   
        
        videoOption = "english and vietnamese subtitle";
        settingEnglishAndVietnameseSubtitle();
        makeVideo(true);        
        
        videoOption = "english listening";
        settingEnglishListening();
        makeVideo(true);
        
        //====
        setSetting();
        String pathFolderYouTube = pathFolder + "youtube";
        String fileMp4MergeList = pathFolderYouTube + "\\merge_video.txt";
        String fileMp4MergeExport = pathFolderYouTube + "\\video_youtube.mp4";

        processFolder(pathFolderYouTube);

        List<String> pathFileMp4s = new ArrayList<>();
        pathFileMp4s.add(videoBilingualVietnameseEnglish.getPathFileMp4Subtitle());
        pathFileMp4s.add(videoEnglishAndVietnameseSubtitle.getPathFileMp4Subtitle());
        pathFileMp4s.add(videoEnglishListening.getPathFileMp4Subtitle());

        pathFileMp4s = pathFileMp4s.stream().map(s -> "file '" + s + "'").collect(Collectors.toList());
        //pathFileMp4s = pathFileMp4s.stream().map(s -> s.replace(" ", "%20")).collect(Collectors.toList());

        UtilityFileFolder.writeTextFileWithApache(fileMp4MergeList, "utf-8", String.join("\n", pathFileMp4s), false);

        ffmpeg.combineMultipleMp4(pathFolder, fileMp4MergeList, fileMp4MergeExport);

        //===
        System.out.println("Video Body Bilingual Vn En Duration: " + videoBilingualVietnameseEnglish.getDurationOfFileMp4Subtitle());
        System.out.println("Video Body En Vn Subtitle Duration: " + videoEnglishAndVietnameseSubtitle.getDurationOfFileMp4Subtitle());
        System.out.println("Video Body EnListening Practice Duration: " + videoEnglishListening.getDurationOfFileMp4Subtitle());

    }

    private boolean isValidation(ObjPVideo objPVideo) {
        String errMessage = "";
        
        if (tfPathFolder.getText().trim().isEmpty()) {
            errMessage = "Path folder is empty.";
        } else if (!UtilityFileFolder.isExistsFolder(objPVideo.getFolderInput())) {
            errMessage = "Folder input don't exist.";
        } else if (!UtilityFileFolder.isExistsFile(objPVideo.getFileCover())) {
            //errMessage = "Conver file don't exist.";
        }
        
        //====
        if (taVideoBodyContent.getText().trim().isEmpty()) {
            errMessage = "Video body content is empty.";
        }
        
        if (!errMessage.isEmpty()) {
            JOptionPane.showMessageDialog(this, errMessage, "ERROR", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }

    private void createVideo(ObjPVideo objPVideo) {
        setSetting();
        if (isValidation(objPVideo)) {
            int index = 0;
            List<String> linesTextAudio = new ArrayList<>();

            processFolder(objPVideo.getFolderOutput());
            
            objPVideo.getContent().addAll(Arrays.asList(taVideoBodyContent.getText().split("\\n")));

            //== Process special character ==
            Collections.replaceAll(objPVideo.getContent(), "’", "'");
            Collections.replaceAll(objPVideo.getContent(), "…", "...");
            
            if (objPVideo.getContent().get(0).contains("↨")) {
                String[] firstRow = objPVideo.getContent().get(0).split("↨", -1);
                objPVideo.setTitleEn(firstRow[0]);
                objPVideo.setTitleVn(firstRow[1]);                
            } else {
                objPVideo.setTitleEn(objPVideo.getContent().get(0));
            }
            
            makeAutioTitle(linesTextAudio, objPVideo);

            for (String line : objPVideo.getContent()) {
                if (index > 0 && !line.isEmpty()) {
                    ObjWord objWord = new ObjWord();
                    
                    if (line.contains("↨")) {
                        String[] tmp = line.split("↨", -1);
                        //objWord.setEn(processSpecialCharacter(UtilityString.trimSpace(tmp[0])));
                        //objWord.getVn().add(processSpecialCharacter(UtilityString.trimSpace(tmp[1])));                    

                        objWord.setEn(UtilityString.trimSpace(tmp[0]));
                        objWord.getVn().add(UtilityString.trimSpace(tmp[1]));
                        
                        if (tmp.length > 2) {
                            objWord.getPronounceUk().add(UtilityString.trimSpace(tmp[2]));
                        }                        
                    } else {
                        objWord.setEn(UtilityString.trimSpace(line));
                    }

                    //== MAKE AUDIO TEXT ==
                    if (objPVideo.getType().equalsIgnoreCase("VideoEnglish") && !objWord.getEn().isEmpty()) {
                        makeAudioTextEnglish(linesTextAudio, objWord);
                    }
                    //====
                    if (objPVideo.getType().equalsIgnoreCase("VideoEnglishListening") && !objWord.getEn().isEmpty()) {
                        makeAudioTextEnglish(linesTextAudio, objWord);
                    }
                    //====
                    if (objPVideo.getType().equalsIgnoreCase("VideoEnglishConversation") && !objWord.getEn().isEmpty()) {
                        makeAudioTextEnglishConversation(linesTextAudio, objWord);
                    }
                    //====
                    if (objPVideo.getType().equalsIgnoreCase("VideoBilingualVietnameseEnglish") && !objWord.getEn().isEmpty() && !objWord.getVn().get(0).isEmpty()) {
                        makeAudioBilingualVietnameseEnglish(linesTextAudio, objWord);
                    }
                    //====
                    if (objPVideo.getType().equalsIgnoreCase("VideoEnglishAndVietnameseSubtitle") && !objWord.getEn().isEmpty() && !objWord.getVn().get(0).isEmpty()) {
                        makeAudioEnglishAndVietnameseSubtitle(linesTextAudio, objWord, 1);
                    }
                    //====
                    if (objPVideo.getType().equalsIgnoreCase("videoLearnEnglish")) {
                        makeAudioLearnEnglish(linesTextAudio, objWord);
                    }  
                    if (objPVideo.getType().equalsIgnoreCase("videoReadEnglish")) {
                        makeAudioReadEnglish(linesTextAudio, objWord);
                    }                     

                }
                index++;
            }

            UtilityFileFolder.writeTextFileWithBufferedWriter(objPVideo.getFileTxtRoot(), "UTF-8", StringUtils.join(objPVideo.getContent(), "\n"), false);
            UtilityFileFolder.writeTextFileWithBufferedWriter(objPVideo.getFileTxtAudio(), "UTF-8", StringUtils.join(linesTextAudio, "\n"), false);

            //makeVideoSubtitle(objPVideo);

        }

    }

    private void makeVideoSubtitle(ObjPVideo pVideo) {
        if (makeMp3(pVideo.getFileTxtAudio(), pVideo.getPathFileMp3())) {
            System.out.println("== Convert sub srt to ass...");
//            if (ffmpeg.convertSubSrtToAss(pVideo.getPathFileSrt())) {
//                //AssFile.process(pVideo.getFileAss(), pVideo);
//                processFileAss(pVideo);
//
//                System.out.println("== Merge MP3 and Mp4...");
//                if (UtilityFileFolder.isExistsFile(pVideo.getFileCover()) && pVideo.getFileCover().endsWith(".mp4")) {
//                    if (ffmpeg.mergeMp3AndMp4ToMp4RepeatMp4(pVideo.getPathFileMp3(), pVideo.getFileCover(), pVideo.getPathFileMp4())) {
//                        System.out.println("== Write sub to video...");
//                        ffmpeg.writeSubToVideo8(pVideo.getPathFileAss(), pVideo.getPathFileMp4(), pVideo.getPathFileMp4Subtitle());
//                    }
//                } else if (UtilityFileFolder.isExistsFile(pVideo.getFileCover()) && pVideo.getFileCover().endsWith(".png")) {
//                    System.out.println("== Merge MP3 and image...");
//                    if (ffmpeg.mergeImageAndMp3ToMp4(pVideo.getFileCover(), pVideo.getPathFileMp3())) {
//                        //System.out.println("== Write sub to video...");
//                        //ffmpeg.writeSubToVideo8(pVideo.getPathFileAss(), pVideo.getPathFileMp4(), pVideo.getPathFileMp4Subtitle());
//                    }
//                }
//
//            }
        }
    }

    private void processFileAss(ObjPVideo pVideo) {
        setSettingVideoObjFileAss(pVideo);
        pVideo.getObjFileAss().save();
    }

    private String converToHHMMSS(long duration) {
        long hours = (duration / 1000 / 1000) / 60 / 60;
        long minutes = (duration / 1000 / 1000) / 60;
        long seconds = (duration / 1000 / 1000) % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btAuto = new javax.swing.JButton();
        btTextToVoice = new javax.swing.JButton();
        btWriteSub = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        btConvertSrtToAss = new javax.swing.JButton();
        btMergeMp4 = new javax.swing.JButton();
        btConvertToJson = new javax.swing.JButton();
        btRemoveAudio = new javax.swing.JButton();
        btSlowDownVideo = new javax.swing.JButton();
        btTest = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        btMakeVideo = new javax.swing.JButton();
        cbVideoOption = new javax.swing.JComboBox<>();
        cbEnabledVietSub = new javax.swing.JCheckBox();
        cbEnabledPronounce = new javax.swing.JCheckBox();
        cbShowTitleOption = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        lbPathFolder = new javax.swing.JLabel();
        tfPathFolder = new javax.swing.JTextField();
        lbCoverFile = new javax.swing.JLabel();
        tfCoverFile = new javax.swing.JTextField();
        tpFooter = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        taVideoBodyContent = new javax.swing.JTextArea();
        jLabel33 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        cbFontColorVideoBodyRow2 = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        cbFontStyleVideoBodyTitle = new javax.swing.JComboBox<>();
        cbFontSizeVideoBodyTitle = new javax.swing.JComboBox<>();
        cbFontColorVideoBodyTitle = new javax.swing.JComboBox<>();
        cbFontStyleVideoBodyRow3 = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        cbFontSizeVideoBodyRow3 = new javax.swing.JComboBox<>();
        cbFontStyleVideoBodyRow1 = new javax.swing.JComboBox<>();
        cbFontColorVideoBodyRow3 = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        cbFontSizeVideoBodyRow1 = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        cbFontColorVideoBodyRow1 = new javax.swing.JComboBox<>();
        cbFontStyleVideoBodyRow2 = new javax.swing.JComboBox<>();
        cbFontSizeVideoBodyRow2 = new javax.swing.JComboBox<>();
        jPanel17 = new javax.swing.JPanel();
        jLabel45 = new javax.swing.JLabel();
        tfVideoBodyTextRow1MarginsLeft = new javax.swing.JTextField();
        tfVideoBodyTextRow2MarginsLeft = new javax.swing.JTextField();
        tfVideoBodyTextRow1MarginsRight = new javax.swing.JTextField();
        tfVideoBodyTextRow1MarginsVert = new javax.swing.JTextField();
        tfVideoBodyTextRow2MarginsRight = new javax.swing.JTextField();
        tfVideoBodyTextRow2MarginsVert = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        taVideoYouTube = new javax.swing.JTextArea();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        cbVoicePerson2 = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        cbVoicePerson1 = new javax.swing.JComboBox<>();
        tfPerson1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        tfPerson2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        tfPerson3 = new javax.swing.JTextField();
        cbVoicePerson3 = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        tfPerson4 = new javax.swing.JTextField();
        cbVoicePerson4 = new javax.swing.JComboBox<>();
        cbVoiceDefaultFemale = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cbVoiceDefaultMale = new javax.swing.JComboBox<>();
        jPanel9 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        tfAssPlayResX = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        tfAssPlayResY = new javax.swing.JTextField();
        jPanel11 = new javax.swing.JPanel();
        jLabel35 = new javax.swing.JLabel();
        cbAssPrimaryColour = new javax.swing.JComboBox<>();
        cbAssSecondaryColour = new javax.swing.JComboBox<>();
        jLabel36 = new javax.swing.JLabel();
        cbAssOutlineColour = new javax.swing.JComboBox<>();
        jLabel37 = new javax.swing.JLabel();
        cbAssBackColour = new javax.swing.JComboBox<>();
        jLabel38 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        cbAssFontName = new javax.swing.JComboBox<>();
        cbAssFontSize = new javax.swing.JComboBox<>();
        jLabel40 = new javax.swing.JLabel();
        chbAssFontBold = new javax.swing.JCheckBox();
        chbAssFontItalic = new javax.swing.JCheckBox();
        chbAssFontUnderline = new javax.swing.JCheckBox();
        chbAssFontStrikeout = new javax.swing.JCheckBox();
        jPanel13 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        cbAssAlignment = new javax.swing.JComboBox<>();
        jPanel14 = new javax.swing.JPanel();
        tfAssMarginLeft = new javax.swing.JTextField();
        jLabel42 = new javax.swing.JLabel();
        tfAssMarginRight = new javax.swing.JTextField();
        tfAssMarginVert = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        cbAssStyleName = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Video Process");

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btAuto.setText("Auto");
        btAuto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAutoActionPerformed(evt);
            }
        });

        btTextToVoice.setText("Text to Voice");
        btTextToVoice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btTextToVoiceActionPerformed(evt);
            }
        });

        btWriteSub.setText("Write Sub");
        btWriteSub.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btWriteSubActionPerformed(evt);
            }
        });

        jButton4.setText("Make Video");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        btConvertSrtToAss.setText("SRT → ASS");
        btConvertSrtToAss.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btConvertSrtToAssActionPerformed(evt);
            }
        });

        btMergeMp4.setText("Merge Mp4");
        btMergeMp4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btMergeMp4ActionPerformed(evt);
            }
        });

        btConvertToJson.setText("Convert To Json");
        btConvertToJson.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btConvertToJsonActionPerformed(evt);
            }
        });

        btRemoveAudio.setText("Remove Audio");
        btRemoveAudio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btRemoveAudioActionPerformed(evt);
            }
        });

        btSlowDownVideo.setText("Slow Down");
        btSlowDownVideo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSlowDownVideoActionPerformed(evt);
            }
        });

        btTest.setText("Test");
        btTest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btTestActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btAuto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btTextToVoice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btSlowDownVideo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btTest, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btConvertSrtToAss, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btConvertToJson, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btWriteSub, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btMergeMp4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btRemoveAudio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btAuto)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btTextToVoice)
                    .addComponent(btConvertSrtToAss)
                    .addComponent(jButton4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btConvertToJson)
                    .addComponent(btRemoveAudio)
                    .addComponent(btSlowDownVideo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btWriteSub)
                    .addComponent(btMergeMp4)
                    .addComponent(btTest))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btMakeVideo.setText("Make Video");
        btMakeVideo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btMakeVideoActionPerformed(evt);
            }
        });

        cbVideoOption.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Auto", "English", "English Listening", "English Conversation", "English And Vietnamese Subtitle", "Vietnamese", "Bilingual Vietnamese English", "Header", "YouTube", "Learn English", "Read English", " " }));
        cbVideoOption.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbVideoOptionItemStateChanged(evt);
            }
        });
        cbVideoOption.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbVideoOptionActionPerformed(evt);
            }
        });

        cbEnabledVietSub.setText("VietSub");

        cbEnabledPronounce.setSelected(true);
        cbEnabledPronounce.setText("Pronounce");

        cbShowTitleOption.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Title EN", "Title VN", "Both titles" }));

        jLabel11.setText("Show");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(cbEnabledPronounce)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbEnabledVietSub)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbShowTitleOption, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(btMakeVideo, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cbVideoOption, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btMakeVideo)
                    .addComponent(cbVideoOption, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(cbShowTitleOption, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbEnabledPronounce)
                    .addComponent(cbEnabledVietSub))
                .addContainerGap())
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lbPathFolder.setText("Folder");

        lbCoverFile.setText("Cover File");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tfCoverFile, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbCoverFile)
                            .addComponent(lbPathFolder))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(tfPathFolder))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbPathFolder)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfPathFolder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbCoverFile)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfCoverFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        taVideoBodyContent.setColumns(20);
        taVideoBodyContent.setRows(5);
        jScrollPane3.setViewportView(taVideoBodyContent);

        jPanel16.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        cbFontColorVideoBodyRow2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Default - Default", "Black - 000000", "White - FFFFFF", "Gray - HBABABA" }));
        cbFontColorVideoBodyRow2.setSelectedIndex(2);

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel10.setText("ROW 1:");

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel22.setText("ROW 2:");

        jLabel32.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel32.setText("TITLE:");

        cbFontStyleVideoBodyTitle.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Default", "Arial" }));

        cbFontSizeVideoBodyTitle.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "10", "20", "30", "40", "50", "60", "70", "80", "90", "100", "110", "120", "130", "140", "150", "160" }));
        cbFontSizeVideoBodyTitle.setSelectedIndex(12);

        cbFontColorVideoBodyTitle.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Default - Default", "Black - 000000", "White - FFFFFF", "Gray - HBABABA" }));
        cbFontColorVideoBodyTitle.setSelectedIndex(2);

        cbFontStyleVideoBodyRow3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Default", "Arial" }));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("Row 3");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel7.setText("Style");

        cbFontSizeVideoBodyRow3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "10", "20", "30", "40", "50", "60", "70", "80", "90", "100", "110", "120", "130", "140", "150", "160" }));
        cbFontSizeVideoBodyRow3.setSelectedIndex(8);

        cbFontStyleVideoBodyRow1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Default", "Arial" }));

        cbFontColorVideoBodyRow3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Default - Default", "Black - 000000", "White - FFFFFF", "Gray - HBABABA" }));
        cbFontColorVideoBodyRow3.setSelectedIndex(2);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel8.setText("Size");
        jLabel8.setToolTipText("");

        cbFontSizeVideoBodyRow1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "10", "20", "30", "40", "50", "60", "70", "80", "90", "100", "110", "120", "130", "140", "150", "160" }));
        cbFontSizeVideoBodyRow1.setSelectedIndex(8);

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel13.setText("Color");

        cbFontColorVideoBodyRow1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Default - Default", "Black - 000000", "White - FFFFFF", "Gray - HBABABA" }));
        cbFontColorVideoBodyRow1.setSelectedIndex(2);

        cbFontStyleVideoBodyRow2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Default", "Arial" }));

        cbFontSizeVideoBodyRow2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "10", "20", "30", "40", "50", "60", "70", "80", "90", "100", "110", "120", "130", "140", "150", "160" }));
        cbFontSizeVideoBodyRow2.setSelectedIndex(8);

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel32, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel22, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cbFontStyleVideoBodyRow2, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cbFontStyleVideoBodyRow1, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cbFontStyleVideoBodyTitle, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel7)
                    .addComponent(cbFontStyleVideoBodyRow3, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel8)
                    .addComponent(cbFontSizeVideoBodyTitle, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cbFontSizeVideoBodyRow1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cbFontSizeVideoBodyRow2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cbFontSizeVideoBodyRow3, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cbFontColorVideoBodyRow2, javax.swing.GroupLayout.Alignment.TRAILING, 0, 197, Short.MAX_VALUE)
                    .addComponent(cbFontColorVideoBodyRow1, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel13)
                    .addComponent(cbFontColorVideoBodyRow3, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cbFontColorVideoBodyTitle, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(cbFontStyleVideoBodyTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbFontSizeVideoBodyTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbFontColorVideoBodyTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(cbFontSizeVideoBodyRow1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbFontColorVideoBodyRow1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbFontStyleVideoBodyRow1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(cbFontSizeVideoBodyRow2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbFontStyleVideoBodyRow2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbFontColorVideoBodyRow2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbFontStyleVideoBodyRow3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(cbFontSizeVideoBodyRow3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbFontColorVideoBodyRow3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel17.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel45.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel45.setText("Odd");

        tfVideoBodyTextRow1MarginsLeft.setText("0");

        tfVideoBodyTextRow2MarginsLeft.setText("0");

        tfVideoBodyTextRow1MarginsRight.setText("0");
        tfVideoBodyTextRow1MarginsRight.setToolTipText("");

        tfVideoBodyTextRow1MarginsVert.setText("0");

        tfVideoBodyTextRow2MarginsRight.setText("0");

        tfVideoBodyTextRow2MarginsVert.setText("0");

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel15.setText("Left");

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel16.setText("Right");

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel17.setText("Vert");

        jLabel46.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel46.setText("Even");

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel45)
                    .addComponent(jLabel46))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(tfVideoBodyTextRow1MarginsLeft)
                        .addComponent(tfVideoBodyTextRow2MarginsLeft, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(tfVideoBodyTextRow1MarginsRight)
                        .addComponent(tfVideoBodyTextRow2MarginsRight, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel16))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17)
                    .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(tfVideoBodyTextRow1MarginsVert)
                        .addComponent(tfVideoBodyTextRow2MarginsVert, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(jLabel16)
                    .addComponent(jLabel17))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfVideoBodyTextRow1MarginsLeft, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfVideoBodyTextRow1MarginsRight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfVideoBodyTextRow1MarginsVert, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel45))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfVideoBodyTextRow2MarginsLeft, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfVideoBodyTextRow2MarginsRight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfVideoBodyTextRow2MarginsVert, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel46))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 254, Short.MAX_VALUE)
                                .addComponent(jLabel33)
                                .addGap(0, 251, Short.MAX_VALUE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel33)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 380, Short.MAX_VALUE)
                .addContainerGap())
        );

        tpFooter.addTab("Body", jPanel4);

        taVideoYouTube.setColumns(20);
        taVideoYouTube.setRows(5);
        taVideoYouTube.setText("Xem thêm tại: https://www.youtube.com/watch?v=VwMslBeIjKY&list=PLsjNRa41wJ8N88Tb2u9fOdfzH0R2_-eNm\n\n==========\nBài văn miêu tả về mẹ của tôi bằng tiếng Anh ★ Đoạn văn số 12 ★ \n• 00:00:00 Song ngữ Việt - Anh\n• $time001 Phụ đề tiếng Việt\n• $time002 Luyện nghe tiếng Anh\n\n==========\nSOURCES:\n• Video: https://ehosito.com/\n• Audio: https://ehosito.com/\n• Video: ");
        jScrollPane4.setViewportView(taVideoYouTube);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 730, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 555, Short.MAX_VALUE)
                .addContainerGap())
        );

        tpFooter.addTab("YouTube", jPanel3);

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        cbVoicePerson2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cortana", "Microsoft David Desktop", "Microsoft Eva Mobile", "Microsoft Mark", "Microsoft Zira Desktop" }));
        cbVoicePerson2.setSelectedIndex(1);
        cbVoicePerson2.setMinimumSize(new java.awt.Dimension(150, 20));

        jLabel2.setText("Person 1");

        cbVoicePerson1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cortana", "Microsoft David Desktop", "Microsoft Eva Mobile", "Microsoft Mark", "Microsoft Zira Desktop" }));
        cbVoicePerson1.setSelectedIndex(4);
        cbVoicePerson1.setToolTipText("");
        cbVoicePerson1.setMinimumSize(new java.awt.Dimension(150, 20));

        jLabel3.setText("Person 2");

        jLabel4.setText("Person 3");

        cbVoicePerson3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cortana", "Microsoft David Desktop", "Microsoft Eva Mobile", "Microsoft Mark", "Microsoft Zira Desktop" }));
        cbVoicePerson3.setSelectedIndex(2);
        cbVoicePerson3.setToolTipText("");
        cbVoicePerson3.setMinimumSize(new java.awt.Dimension(150, 20));

        jLabel5.setText("Person 4");

        cbVoicePerson4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cortana", "Microsoft David Desktop", "Microsoft Eva Mobile", "Microsoft Mark", "Microsoft Zira Desktop" }));
        cbVoicePerson4.setSelectedIndex(3);
        cbVoicePerson4.setMinimumSize(new java.awt.Dimension(150, 20));

        cbVoiceDefaultFemale.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cortana", "Microsoft David Desktop", "Microsoft Eva Mobile", "Microsoft Mark", "Microsoft Zira Desktop" }));
        cbVoiceDefaultFemale.setSelectedIndex(4);

        jLabel1.setText("Voice Default - Female");

        jLabel6.setText("Voice Default - Male");
        jLabel6.setToolTipText("");

        cbVoiceDefaultMale.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cortana", "Microsoft David Desktop", "Microsoft Eva Mobile", "Microsoft Mark", "Microsoft Zira Desktop" }));
        cbVoiceDefaultMale.setSelectedIndex(1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbVoiceDefaultFemale, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cbVoiceDefaultMale, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel6)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(tfPerson4)
                            .addComponent(tfPerson3)
                            .addComponent(tfPerson1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE)
                            .addComponent(tfPerson2, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbVoicePerson1, 0, 211, Short.MAX_VALUE)
                            .addComponent(cbVoicePerson2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbVoicePerson3, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbVoicePerson4, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbVoiceDefaultMale, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbVoiceDefaultFemale, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfPerson1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbVoicePerson1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfPerson2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbVoicePerson2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfPerson3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbVoicePerson3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfPerson4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbVoicePerson4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(256, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Voice Setting", jPanel2);

        jPanel9.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel10.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel18.setText("PlayResX");

        tfAssPlayResX.setText("1920");

        jLabel34.setText("PlayResY");

        tfAssPlayResY.setText("1080");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tfAssPlayResX)
                    .addComponent(jLabel18))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel34)
                    .addComponent(tfAssPlayResY))
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(jLabel34))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfAssPlayResX, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfAssPlayResY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel11.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel35.setText("Primary");

        cbAssPrimaryColour.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Black - &H000000", "White - &HFFFFFF", "Gray - &HHBABABA" }));
        cbAssPrimaryColour.setSelectedIndex(1);

        cbAssSecondaryColour.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Black - &H000000", "White - &HFFFFFF", "Gray - &HHBABABA" }));
        cbAssSecondaryColour.setSelectedIndex(1);

        jLabel36.setText("Secondary");

        cbAssOutlineColour.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Black - &H000000", "White - &HFFFFFF", "Gray - &HHBABABA" }));
        cbAssOutlineColour.setSelectedIndex(1);

        jLabel37.setText("Outline");

        cbAssBackColour.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Black - &H000000", "White - &HFFFFFF", "Gray - &HHBABABA" }));
        cbAssBackColour.setSelectedIndex(1);

        jLabel38.setText("Back");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel35)
                    .addComponent(jLabel37)
                    .addComponent(cbAssPrimaryColour, 0, 146, Short.MAX_VALUE)
                    .addComponent(cbAssOutlineColour, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel38)
                    .addComponent(cbAssSecondaryColour, 0, 147, Short.MAX_VALUE)
                    .addComponent(cbAssBackColour, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel36))
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35)
                    .addComponent(jLabel36))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbAssPrimaryColour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbAssSecondaryColour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(jLabel38))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbAssOutlineColour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbAssBackColour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel12.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel39.setText("Font Name");

        cbAssFontName.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Arial" }));

        cbAssFontSize.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "10", "20", "30", "40", "50", "60", "70", "80", "90", "100", "110", "120", "130", "140", "150", "160" }));
        cbAssFontSize.setSelectedIndex(8);

        jLabel40.setText("Font Size");

        chbAssFontBold.setSelected(true);
        chbAssFontBold.setText("Bold");

        chbAssFontItalic.setText("Italic");

        chbAssFontUnderline.setText("Underline");

        chbAssFontStrikeout.setText("Strikeout");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addComponent(chbAssFontBold)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(chbAssFontItalic)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(chbAssFontUnderline)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(chbAssFontStrikeout)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbAssFontName, 0, 203, Short.MAX_VALUE)
                            .addComponent(jLabel39))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel40)
                            .addComponent(cbAssFontSize, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel39)
                    .addComponent(jLabel40))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbAssFontName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbAssFontSize, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chbAssFontBold)
                    .addComponent(chbAssFontItalic)
                    .addComponent(chbAssFontUnderline)
                    .addComponent(chbAssFontStrikeout))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jPanel13.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel41.setText("Alignment");

        cbAssAlignment.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Default", "1 - Bottom Right", "2 - Bottom Center", "3 - Bottom Left", "4 - Middle Right", "5 - Middle Center", "6 - Middle Left", "7 - Top Right", "8 - Top Center", "9 - Top Left" }));
        cbAssAlignment.setSelectedIndex(5);

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addComponent(jLabel41)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(cbAssAlignment, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel41)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbAssAlignment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel14.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        tfAssMarginLeft.setText("65");

        jLabel42.setText("Margin Left");

        tfAssMarginRight.setText("65");
        tfAssMarginRight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfAssMarginRightActionPerformed(evt);
            }
        });

        tfAssMarginVert.setText("500");

        jLabel43.setText("Margin Right");

        jLabel44.setText("Margin Vert");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tfAssMarginLeft)
                    .addComponent(jLabel42))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tfAssMarginRight)
                    .addComponent(jLabel43))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel44)
                    .addComponent(tfAssMarginVert))
                .addContainerGap())
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel42)
                    .addComponent(jLabel43)
                    .addComponent(jLabel44))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfAssMarginLeft, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfAssMarginRight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfAssMarginVert, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel15.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel14.setText("Style Name");

        cbAssStyleName.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Default" }));

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(cbAssStyleName, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbAssStyleName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Sub Setting", jPanel9);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jTabbedPane1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tpFooter)
                            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tpFooter))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTabbedPane1)
                        .addGap(12, 12, 12)))
                .addContainerGap())
        );

        tpFooter.getAccessibleContext().setAccessibleName("Body");

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btAutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAutoActionPerformed
        setSetting();
        autoMergeVideo();
        
        //videoOption = "header";
        //makeVideo(true);
        
        //videoOption = "youtube";
        //makeVideo(true);
        
//        List<String> pathFilesMp4 = UtilityFileFolder.getListPathFileInFolder(pathFolder, "mp4", false);
//        if (pathFilesMp4.size() == 1) {
//            String fileMp4Output = pathFolder + "scale.mp4";
//            String fileMp4Input = pathFilesMp4.get(0);
//            
//            ffmpeg.resizeVideo(fileMp4Input, fileMp4Output, "1920x1080");            
//        }        
//        
        
    }//GEN-LAST:event_btAutoActionPerformed

    private void btTextToVoiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btTextToVoiceActionPerformed
        setSetting();
        //makeMp3(fileAudioTxt, fileAudioMp3);
    }//GEN-LAST:event_btTextToVoiceActionPerformed

    private void btWriteSubActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btWriteSubActionPerformed
        setSetting();
        String pathMp4 = UtilityFileFolder.getListPathFileInFolder(pathFolder, "mp4", false).get(0);        
        String pathMp4Sub = pathMp4.replace(".mp4", "_sub.mp4");
        String pathAss = UtilityFileFolder.getListPathFileInFolder(pathFolder, "ass", false).get(0);

        File fileMp4 = new File(pathMp4);
        File fileAss = new File(pathAss);
        
        if (fileMp4.exists() && fileAss.exists()) {        
            ffmpeg.writeSubToVideo8(pathAss, pathMp4, pathMp4Sub);
        }      

    }//GEN-LAST:event_btWriteSubActionPerformed

    private void btMakeVideoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btMakeVideoActionPerformed
        makeVideo(false);
    }//GEN-LAST:event_btMakeVideoActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        setSetting();
        //ffmpeg.mergeImageAndMp3ToMp4(fileCover, fileAudioMp3);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void btConvertSrtToAssActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btConvertSrtToAssActionPerformed
        try {
            setSetting();
            String fileSrt = UtilityFileFolder.getListPathFileInFolder(pathFolder, "srt", false).get(0);
            String fileAss = fileSrt.replace(".srt", ".ass");
            
            File file = new File(fileAss);
            if (file.exists()) {
                FileUtils.forceDelete(file);
                System.out.println("Deleted: " + fileAss);
            }

            if (ffmpeg.convertSubSrtToAss(fileSrt)) {
                System.out.println("Convert srt to ass successfully.");
            }
        } catch (IOException ex) {
            System.out.println("File deletion failed.");
            Logger.getLogger(PVideo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btConvertSrtToAssActionPerformed

    private void btMergeMp4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btMergeMp4ActionPerformed
//        setSetting();
//        
//        List<String> pathFileMp4s = UtilityFileFolder.getListPathFileInFolder(pathFolder, "mp4", false);
//        pathFileMp4s = pathFileMp4s.stream().map(s -> "file '" + s + "'").collect(Collectors.toList());
//        //pathFileMp4s = pathFileMp4s.stream().map(s -> s.replace(" ", "%20")).collect(Collectors.toList());
//        
//        UtilityFileFolder.writeTextFileWithApache(fileMp4MergeList, "utf-8", String.join("\n", pathFileMp4s), false);
//
//        ffmpeg.combineMultipleMp4(pathFolder, fileMp4MergeList, fileMp4MergeExport);

    }//GEN-LAST:event_btMergeMp4ActionPerformed

    private void btConvertToJsonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btConvertToJsonActionPerformed
        setSetting();
//        List<String> linesTextRoot = UtilityFileFolder.readRowTextFileToListString(fileRoot);
//        List<ObjWord> linesJson = new ArrayList<>();
//
//        for (String line : linesTextRoot) {
//            String[] arrLine = line.split("↨", -1);
//            ObjWord objWords = new ObjWord();
//            objWords.setEn(arrLine[0]);
//            objWords.getVn().add(arrLine[1]);
//            objWords.getPronounceUk().add(arrLine[2]);
//            linesJson.add(objWords);
//        }
//        
//        gson = new GsonBuilder().setPrettyPrinting().create();
//        String jsonData = gson.toJson(linesJson);
//        UtilityFileFolder.writeTextFileWithBufferedWriter(fileJson, "UTF-8", jsonData, false);

    }//GEN-LAST:event_btConvertToJsonActionPerformed

    private void btRemoveAudioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btRemoveAudioActionPerformed
        setSetting();
        
        List<String> pathFilesMp4 = UtilityFileFolder.getListPathFileInFolder(pathFolder, "mp4", false);
        if (pathFilesMp4.size() == 1) {
            String fileCover = pathFolder + "cover.mp4";
            String fileMp4Input = pathFilesMp4.get(0);
            String fileMp4Output = fileCover.replace("cover", "cover_remove_audio");
            //String fileMp4OutputChangeFrameRate = fileCover.replace("cover", "cover_remove_audio_change_frame_rate");
            
            ffmpeg.removeAudioFromVideo(fileMp4Input, fileMp4Output);
            ffmpeg.changeFrameRate(fileMp4Output, fileCover, 25);            
        }

    }//GEN-LAST:event_btRemoveAudioActionPerformed

    private void btSlowDownVideoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSlowDownVideoActionPerformed
        setSetting();
        //String fileMp4Output001 = fileCover.replace(".mp4", "_slow_down.mp4");
        //ffmpeg.videoSlowDown(fileCover, fileMp4Output);
        //String fileMp4Output = fileMp4Output001.replace(".mp4", "_smooth.mp4");
        //ffmpeg.videoSmooth(fileMp4Output001, fileMp4Output);
    }//GEN-LAST:event_btSlowDownVideoActionPerformed

    private void btTestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btTestActionPerformed

        setSetting();

        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");

        long durationVideoBilingualVietnameseEnglish = videoBilingualVietnameseEnglish.getDurationMilliSecondsOfFileMp4Subtitle();
        long durationVideoEnglishAndVietnameseSubtitle = videoEnglishAndVietnameseSubtitle.getDurationMilliSecondsOfFileMp4Subtitle();
        long durationVideoEnglishListening = videoEnglishListening.getDurationMilliSecondsOfFileMp4Subtitle();

        long lTime001 = durationVideoBilingualVietnameseEnglish;
        long lTime002 = lTime001 + durationVideoEnglishAndVietnameseSubtitle;

        System.out.println("Duration: " + DurationFormatUtils.formatDuration(lTime001, "HH:mm:ss"));
        System.out.println("Duration: " + DurationFormatUtils.formatDuration(lTime002, "HH:mm:ss"));

        String time001 = converToHHMMSS(lTime001);
        String time002 = converToHHMMSS(lTime002);

        String data = taVideoYouTube.getText();
        data = data.replace("$time001", time001);
        data = data.replace("$time002", time002);
        taVideoYouTube.setText(data);

    }//GEN-LAST:event_btTestActionPerformed

    private void tfAssMarginRightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfAssMarginRightActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfAssMarginRightActionPerformed

    private void cbVideoOptionItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbVideoOptionItemStateChanged
        videoOption = cbVideoOption.getSelectedItem().toString().toLowerCase();
        
        switch (videoOption) {
            case "header":
                settingHeader();
                break;
            case "footer":
                break;
            case "english":
                settingEnglish();
                break;
            case "english listening":
                settingEnglishListening();
                break;                  
            case "english conversation":
                settingEnglishConversation();
                break;                              
            case "english and vietnamese subtitle":
                settingEnglishAndVietnameseSubtitle();
                break;                
            case "bilingual vietnamese english":
                settingBilingualVietnameseEnglish();
                break;
            case "youtube":
                break;
            case "learn english":
                settingBilingualVietnameseEnglish();
                break;                
            case "read english":
                settingBilingualVietnameseEnglish();
                break;                
            default:
                System.exit(0);
        }

    }//GEN-LAST:event_cbVideoOptionItemStateChanged

    private void cbVideoOptionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbVideoOptionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbVideoOptionActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PVideo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new PVideo().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAuto;
    private javax.swing.JButton btConvertSrtToAss;
    private javax.swing.JButton btConvertToJson;
    private javax.swing.JButton btMakeVideo;
    private javax.swing.JButton btMergeMp4;
    private javax.swing.JButton btRemoveAudio;
    private javax.swing.JButton btSlowDownVideo;
    private javax.swing.JButton btTest;
    private javax.swing.JButton btTextToVoice;
    private javax.swing.JButton btWriteSub;
    private javax.swing.JComboBox<String> cbAssAlignment;
    private javax.swing.JComboBox<String> cbAssBackColour;
    private javax.swing.JComboBox<String> cbAssFontName;
    private javax.swing.JComboBox<String> cbAssFontSize;
    private javax.swing.JComboBox<String> cbAssOutlineColour;
    private javax.swing.JComboBox<String> cbAssPrimaryColour;
    private javax.swing.JComboBox<String> cbAssSecondaryColour;
    private javax.swing.JComboBox<String> cbAssStyleName;
    private javax.swing.JCheckBox cbEnabledPronounce;
    private javax.swing.JCheckBox cbEnabledVietSub;
    private javax.swing.JComboBox<String> cbFontColorVideoBodyRow1;
    private javax.swing.JComboBox<String> cbFontColorVideoBodyRow2;
    private javax.swing.JComboBox<String> cbFontColorVideoBodyRow3;
    private javax.swing.JComboBox<String> cbFontColorVideoBodyTitle;
    private javax.swing.JComboBox<String> cbFontSizeVideoBodyRow1;
    private javax.swing.JComboBox<String> cbFontSizeVideoBodyRow2;
    private javax.swing.JComboBox<String> cbFontSizeVideoBodyRow3;
    private javax.swing.JComboBox<String> cbFontSizeVideoBodyTitle;
    private javax.swing.JComboBox<String> cbFontStyleVideoBodyRow1;
    private javax.swing.JComboBox<String> cbFontStyleVideoBodyRow2;
    private javax.swing.JComboBox<String> cbFontStyleVideoBodyRow3;
    private javax.swing.JComboBox<String> cbFontStyleVideoBodyTitle;
    private javax.swing.JComboBox<String> cbShowTitleOption;
    private javax.swing.JComboBox<String> cbVideoOption;
    private javax.swing.JComboBox<String> cbVoiceDefaultFemale;
    private javax.swing.JComboBox<String> cbVoiceDefaultMale;
    private javax.swing.JComboBox<String> cbVoicePerson1;
    private javax.swing.JComboBox<String> cbVoicePerson2;
    private javax.swing.JComboBox<String> cbVoicePerson3;
    private javax.swing.JComboBox<String> cbVoicePerson4;
    private javax.swing.JCheckBox chbAssFontBold;
    private javax.swing.JCheckBox chbAssFontItalic;
    private javax.swing.JCheckBox chbAssFontStrikeout;
    private javax.swing.JCheckBox chbAssFontUnderline;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lbCoverFile;
    private javax.swing.JLabel lbPathFolder;
    private javax.swing.JTextArea taVideoBodyContent;
    private javax.swing.JTextArea taVideoYouTube;
    private javax.swing.JTextField tfAssMarginLeft;
    private javax.swing.JTextField tfAssMarginRight;
    private javax.swing.JTextField tfAssMarginVert;
    private javax.swing.JTextField tfAssPlayResX;
    private javax.swing.JTextField tfAssPlayResY;
    private javax.swing.JTextField tfCoverFile;
    private javax.swing.JTextField tfPathFolder;
    private javax.swing.JTextField tfPerson1;
    private javax.swing.JTextField tfPerson2;
    private javax.swing.JTextField tfPerson3;
    private javax.swing.JTextField tfPerson4;
    private javax.swing.JTextField tfVideoBodyTextRow1MarginsLeft;
    private javax.swing.JTextField tfVideoBodyTextRow1MarginsRight;
    private javax.swing.JTextField tfVideoBodyTextRow1MarginsVert;
    private javax.swing.JTextField tfVideoBodyTextRow2MarginsLeft;
    private javax.swing.JTextField tfVideoBodyTextRow2MarginsRight;
    private javax.swing.JTextField tfVideoBodyTextRow2MarginsVert;
    private javax.swing.JTabbedPane tpFooter;
    // End of variables declaration//GEN-END:variables
}
