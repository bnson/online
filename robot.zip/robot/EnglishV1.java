/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import javax.swing.JOptionPane;
import object.ObjText;
import object.ObjWord;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import utility.FFMPEG;
import utility.UtilityFileFolder;
import utility.UtilityList;
import utility.UtilityString;

/**
 *
 * @author bnson
 */
public class EnglishV1 extends javax.swing.JFrame {

    private Gson gson;
    private final String BALABOLKA = "C:\\Program Files (x86)\\Balabolka\\balabolka.exe";
    //private final String BALCON = "D:\\Application\\balcon\\balcon.exe";
    private final String FFMPEG_PATH = "D:\\Application\\ffmpeg\\ffmpeg-20171115-ff8f40a-win64-static\\bin\\ffmpeg";
    private final FFMPEG ffmpeg;    
    
    public EnglishV1() {
        initComponents();
        ffmpeg = new FFMPEG(FFMPEG_PATH);
    }

    private String getTranslateVn(String vocabulary) {
        String translateVn = "";
        try {
            String referrerLink = "https://translate.google.com/";
            String link = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=vi&dt=t&q=" + vocabulary;
            System.out.println("link: " + link);
            Document doc = Jsoup.connect(link)
                    .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36")
                    .referrer(referrerLink)
                    .ignoreContentType(true)
                    .timeout(10000)
                    .header("content-type", "application/json")
                    .get();

            translateVn = doc.text();
            
        } catch (IOException ex) {
            Logger.getLogger(EnglishV1.class.getName()).log(Level.SEVERE, null, ex);
        }
        return translateVn;
    }

    private String getVocabularyFromCambride(String vocabulary) {
        String rs = "";
        String workClasses = "";
        String pronounceUk = "";
        String pronounceUs = "";

        try {
            Document doc = Jsoup.connect("https://dictionary.cambridge.org/dictionary/english/" + vocabulary).get();
            
            Element eWorkClasses = doc.select("div[class=posgram dpos-g hdib lmr-5] > span[class=pos dpos]").first();
            if (eWorkClasses != null) {
                workClasses = eWorkClasses.text();
            } else {
                System.out.println("NULL");
            }

            Element ePronounceUk = doc.select("span[class=uk dpron-i ] > span[class=pron dpron]").first();
            if (ePronounceUk != null) {
                pronounceUk = ePronounceUk.text();
            } else {
                System.out.println("NULL");
            }

            Element ePronounceUs = doc.select("span[class=us dpron-i ] > span[class=pron dpron]").first();
            if (ePronounceUs != null) {
                pronounceUs = ePronounceUs.text();
            } else {
                System.out.println("NULL");
            }

            rs = workClasses + "↨" + pronounceUk + "↨" + pronounceUs;
            
            System.out.println("↨" + pronounceUk);
            //System.out.println("Vocabulary: " + vocabulary + "↨" + rs);

        } catch (IOException ex) {
            pronounceUs = "";
            Logger.getLogger(EnglishV1.class.getName()).log(Level.SEVERE, null, ex);
        }

        return rs;
    }

    public void processText() {
        String pathFolder = tfPathFolder.getText().trim();
        String pahtFileText = pathFolder + "\\root.txt";
        String pahtFileJson = pathFolder + "\\root.json";
        String pahtFileHtml = pathFolder + "\\root.html";

        List<String> lines = UtilityFileFolder.readRowTextFileToListString(pahtFileText);
        List<String> linesEn = new ArrayList<>();
        List<String> linesVn = new ArrayList<>();
        List<ObjText> listObjText = new ArrayList<>();

        
        String template1Header = "<div class=\"words col border p-2 mb-2 d-flex flex-wrap align-items-center\">\n" +
                                "	<span class=\"words-english font-weight-bold\">$1</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-light font-italic\">$2</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-bold display-6 text-primary w-100\">$3</span>\n" +
                            "</div>";
        
        String template1 = "<div class=\"wordsTemplate1 col border p-2 mb-2 d-flex flex-wrap align-items-center\">\n" +
                                "	<span class=\"words-english\">$1</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-light font-italic\">$2</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-bold display-6 text-primary w-100\">$3</span>\n" +
                            "</div>";     
        
        String template1Bold = "<div class=\"wordsTemplate1 col border p-2 mb-2 d-flex flex-wrap align-items-center\">\n" +
                                "	<span class=\"words-english font-weight-bold\">$1</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-light font-italic\">$2</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-bold display-6 text-primary w-100\">$3</span>\n" +
                            "</div>"; 
        
        
        
        boolean isEn = true;
        for (String line : lines) {
            if (line.trim().equalsIgnoreCase("↔")) {
                isEn = false;
            } else {
                if (isEn) {
                    linesEn.add(line);
                } else {
                    linesVn.add(line);
                }
            }
        }
        
        if (linesEn.size() == linesVn.size()) {
            for (int i = 0 ; i < linesEn.size(); i++) {
                ObjText objText = new ObjText();
                objText.setEn(StringUtils.trim(linesEn.get(i)));
                objText.getVn().add(StringUtils.trim(linesVn.get(i)));
                listObjText.add(objText);
            }
            
            if (listObjText.size() > 0) {
                gson = new GsonBuilder().setPrettyPrinting().create();
                String jsonData = gson.toJson(listObjText);
                UtilityFileFolder.writeTextFileWithBufferedWriter(pahtFileJson, "UTF-8", jsonData, false);
            }
            
            String dataHtml = "";
            int numbericOrder = 0;
            for (ObjText objText : listObjText) {
                if (numbericOrder == 0) {
                    dataHtml = dataHtml + template1Header.replace("$1", objText.getEn()).replace("$3", objText.getVn().get(0)) + "\n";
                } else {
                    String textEn = objText.getEn();
                    if (textEn.contains(":")) {
                        textEn = objText.getEn().replaceFirst("(^[^\\:]+:)", "<b>$1</b>");
                    }
                    dataHtml = dataHtml + template1.replace("$1", textEn).replace("$3", objText.getVn().get(0)) + "\n";
                }
                numbericOrder++;
            }
            
            taOutput.setText(dataHtml);
            UtilityFileFolder.writeTextFileWithBufferedWriter(pahtFileHtml, "UTF-8", dataHtml, false);
        } else {
            JOptionPane.showMessageDialog(this, "Lines EN and Lines VN don't same!");
        }

    }
    
    public void processVocabulary() {
        try {
            List<String> inputRoot = new ArrayList<>();
            List<String> inputProcess = new ArrayList<>();
            
            String pathFolder = tfPathFolder.getText().trim();
            String pathFileRoot = pathFolder + "\\root.txt";
            String pahtFileJson = pathFolder + "\\root.json";
            String pathFileHtml = pathFolder + "\\root.html";

            inputRoot.addAll(Arrays.asList(StringUtils.stripAll(taInput.getText().split("[\\r\\n]"))));
            inputRoot.removeAll(Collections.singleton(null));
            inputRoot.removeAll(Collections.singleton(""));

            //-- REMOVE CHARACTER
            String strReplace;
            String pronounce;
            for (int i = 0; i < inputRoot.size(); i++) {
                strReplace = inputRoot.get(i);

                strReplace = strReplace.replaceAll(tfRegExRemove.getText().trim(), "");
                strReplace = StringUtils.trim(strReplace);
                //inputRoot.set(i, strReplace);

                //-- GET WORDS
                strReplace = strReplace.replaceAll("[/\\(][^\\n]+", "");
                strReplace = StringUtils.trim(strReplace);

                inputProcess.add(strReplace);
            }

            //-- VALIDATION
            if (!validationWords(inputRoot, inputProcess)) {
                System.out.println("validation words is invalid!");
            } else {
                //-- CLEAR DATA
                inputProcess.removeAll(Collections.singleton(null));
                inputProcess.removeAll(Collections.singleton(""));
                UtilityList.removeDuplication(inputProcess);
                
                if (cbSortByAlphabet.isSelected()) {
                    Collections.sort(inputProcess);
                }

                String tmpData = StringUtils.join(inputProcess, "\n");
                UtilityFileFolder.writeTextFileWithBufferedWriter(pathFileRoot, "UTF-8", tmpData, false);
                
                String translate = StringUtils.join(inputProcess, ". ") + ".";
                System.out.println("translate: " + translate);
                
                List<ObjWord> listObjWords = new ArrayList<>();
                
                translate = getTranslateVn(translate);
                JSONArray objArrs = new JSONArray(translate).getJSONArray(0);
                for (int i = 0; i < objArrs.length(); i++) {
                    ObjWord objWords = new ObjWord();
                    JSONArray objArr = objArrs.getJSONArray(i);
                    System.out.print("" + objArr.get(1).toString());
                    System.out.print("↨" + objArr.get(0).toString());
                    //--
                    String enWords = UtilityString.trimSpace(objArr.get(1).toString());
                    String vnWords = UtilityString.trimSpace(objArr.get(0).toString());
                    objWords.setEn(enWords);
                    objWords.getVn().add(vnWords);
                    //--
                    if (enWords.contains(" ")) {
                        String[] tmpWords = enWords.split(" ");
                        String tmpWordsClass = "";
                        String tmpWordsPronounceUk = "";
                        String tmpWordsPronounceUs = "";
                        for (String tmpWord : tmpWords) {
                            String[] arrTmp = getVocabularyFromCambride(tmpWord).split("↨", -1);
                            if (arrTmp.length == 3) {
                                //objWords.getClasses().add(arrTmp[0]);
                                //objWords.getPronounceUk().add(arrTmp[1]);
                                //objWords.getPronounceUs().add(arrTmp[2]);
                                tmpWordsClass = tmpWordsClass + " " + arrTmp[0];
                                tmpWordsPronounceUk = tmpWordsPronounceUk + " " + arrTmp[1];
                                tmpWordsPronounceUs = tmpWordsPronounceUs + " " + arrTmp[2];
                            } else {
                                System.out.println("[Error] Wrong length...");
                            }
                        }
                        
                        tmpWordsClass = UtilityString.trimSpace(tmpWordsClass);
                        tmpWordsPronounceUk = UtilityString.trimSpace(tmpWordsPronounceUk);
                        tmpWordsPronounceUs = UtilityString.trimSpace(tmpWordsPronounceUs);
                        //--
                        objWords.getClasses().add(UtilityString.trimSpace(tmpWordsClass));
                        objWords.getPronounceUk().add(UtilityString.trimSpace(tmpWordsPronounceUk));
                        objWords.getPronounceUs().add(UtilityString.trimSpace(tmpWordsPronounceUs));                        
                        
                    } else {
                        String[] arrTmp = getVocabularyFromCambride(enWords).split("↨", -1);
                        if (arrTmp.length == 3) {
                            objWords.getClasses().add(arrTmp[0]);
                            objWords.getPronounceUk().add(arrTmp[1]);
                            objWords.getPronounceUs().add(arrTmp[2]);
                        } else {
                            System.out.println("[Error] Wrong length...");
                        }
                    }

                    listObjWords.add(objWords);
                    if (i % 2 == 0) {
                        TimeUnit.SECONDS.sleep(2);
                    } else {
                        TimeUnit.SECONDS.sleep(1);
                    }

                }
                
                if (listObjWords.size() > 0) {
                    
                    for (ObjWord tmp : listObjWords) {
                        System.out.println(tmp.getEn() + ";" + tmp.getClasses().get(0) + ";" + tmp.getPronounceUk().get(0) + ";" + tmp.getVn().get(0));
                    }
                    
                    gson = new GsonBuilder().setPrettyPrinting().create();
                    String jsonData = gson.toJson(listObjWords);
                    taOutput.setText(jsonData);
                    UtilityFileFolder.writeTextFileWithBufferedWriter(pahtFileJson, "UTF-8", jsonData, false);
                    
                    if (UtilityFileFolder.isExistsFile(pahtFileJson)) {
                        makeFileHtml(pathFileHtml, jsonData);
                    }
                }                

            }
            
            TimeUnit.SECONDS.sleep(1);
        } catch (InterruptedException ex) {
            Logger.getLogger(EnglishV1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public boolean validationWords(List<String> inputRoot, List<String> inputProcess) {
        if (inputRoot.size() != inputProcess.size()) {
            return false;
        }

        for (int i = 0; i < inputRoot.size(); i++) {
            if (!inputRoot.get(i).startsWith(inputProcess.get(i))) {
                System.out.println("inputRoot.get(i): " + inputRoot.get(i));
                return false;
            }
        }

        return true;
    }
    
    private void makeFileHtml(String pathFileHtml, String text) {
        String template1 = "<div class=\"words col border p-2 mb-2\">\n"
                + "	<span class=\"font-weight-bold\">$1</span><br>\n"
                + "	<span class=\"font-weight-light font-italic\">$2</span><br>\n"
                + "	<span class=\"d-none font-weight-bold display-6 text-primary\">$3</span>\n"
                + "</div>";

        String jsonStr = text;

        //Gson GSON = new Gson();
        List<ObjWord> words = Arrays.asList(new GsonBuilder().create().fromJson(jsonStr, ObjWord[].class));

        List<String> tempateData = new ArrayList<>();
        for (ObjWord word : words) {
            String tmpTemplate = template1;
            tmpTemplate = tmpTemplate.replace("$1", word.getEn());
            tmpTemplate = tmpTemplate.replace("$2", word.getPronounceUs().get(0));
            tmpTemplate = tmpTemplate.replace("$3", word.getVn().get(0));
            tempateData.add(tmpTemplate);
        }

        String data = StringUtils.join(tempateData, "\n");
        taOutput.setText(data);

        UtilityFileFolder.writeTextFileWithBufferedWriter(pathFileHtml, "UTF-8", data, false);
    }
    
    public void actionEnglives001() {
        String start = "<volume level=\"0\">EngLives.</volume>\n<volume level=\"0\">EngLives.</volume>\n<volume level=\"0\">EngLives.</volume>\n";
        String title = "Unit 3 - Ways of Socialising - Vocabulary.\n<volume level=\"0\">Unit 3 - Ways of Socialising - Vocabulary.</volume>\n";
        String tmpTemplate = "$1. <volume level=\"0\">$1.</volume>";
        String end = "\n<volume level=\"0\">EngLives.</volume>\n<volume level=\"0\">EngLives.</volume>\n<volume level=\"0\">EngLives.</volume>";
        List<String> inputList = new ArrayList<>();
        List<String> inputProcess = new ArrayList<>();
        inputList.addAll(Arrays.asList(StringUtils.stripAll(taInput.getText().split("[\\r\\n]"))));
        UtilityList.removeDuplication(inputList);
        Collections.sort(inputList);
        
        for (String input : inputList) {
            inputProcess.add(tmpTemplate.replace("$1", input));
        }
        
        String output = StringUtils.join(inputProcess, "\n");
        output = start + title + output + end;
        taOutput.setText(output);         
    }
    
    public void actionEnglives002() {

        try {
            String folderProcess = tfPathFolder.getText().trim();
            
            String start = "<volume level=\"0\">EngLives.</volume>\n<volume level=\"0\">EngLives.</volume>\n<volume level=\"0\">EngLives.</volume>";
            String end   = "<volume level=\"0\">EngLives.</volume>\n<volume level=\"0\">EngLives.</volume>\n<volume level=\"0\">EngLives.</volume>";
            
            String title = "";
            //String title = "Unit 3 - Ways of Socialising - Vocabulary.\n<volume level=\"0\">Unit 3 - Ways of Socialising - Vocabulary.</volume>\n";
            //String tmpAudioTemplateZira = "<voice required=\"Name=Microsoft Zira Desktop\">$1 </voice><volume level=\"0\">$1</volume>";
            String tmpAudioTemplateDavid = "<voice required=\"Name=Microsoft David Desktop\">$1 </voice><volume level=\"0\">$1</volume>";
            
            String fileRoot = (folderProcess + "\\root.txt").replaceAll("\\+", "\\");
            //System.out.println("File root: " + fileRoot);
            
            String fileCover = fileRoot.replaceAll("root.txt", "cover.png");
            
            String fileAudioTxt = fileRoot.replaceAll("root.txt", "audio.txt");
            String fileAudioMp3 = fileRoot.replaceAll("root.txt", "audio.mp3");
            String fileAudioMp4 = fileRoot.replaceAll("root.txt", "audio.mp4");
            
            List<String> fileRootLines = UtilityFileFolder.readRowTextFileToListString(fileRoot);
            List<String> audioLines = new ArrayList<>();
            audioLines.add(start);
            
            int index = 0;
            for (String line : fileRootLines) {
                if (index == 0) {
                    title = line;
                }
                if (line.equals("↔")) {
                    break;
                }
                
                if (rbAuto.isSelected()) {
                    line = autoAddVocie(processLine(line));
                } else if (rbZira.isSelected()) {
                    line = addVoiceMicrosoftZiraDesktopWithSilence(processLine(line), 0);
                    
                } else {
                    line = addVoiceMicrosoftDavidDesktopWithSilence(processLine(line));
                }
                
                System.out.println("Line: "  + line);
//                if (cbDavid.isSelected()) {
//                    line = addVoiceMicrosoftDavidDesktopWithSilence(processLine(line));
//                } else {
//                    line = addVoiceMicrosoftZiraDesktopWithSilence(processLine(line));
//                }
                
                audioLines.add(line);
                index++;
            }
            audioLines.add(end);
            
            String dataAudio = StringUtils.join(audioLines, "\n");
            UtilityFileFolder.writeTextFileWithBufferedWriter(fileAudioTxt, "UTF-8", dataAudio, false);
            
            ProcessBuilder process = new ProcessBuilder("cmd.exe", "/c", "start", "chcp", "65001", "&", BALABOLKA, "-msq", fileAudioTxt, fileAudioMp3);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);
            }
            
            if (p.waitFor() == 0) {
                List<String> listSrtFiles = UtilityFileFolder.getListPathFileInFolder(folderProcess, "srt", false);
                ffmpeg.convertSubSrtToAss(listSrtFiles.get(0));
                //--
                List<String> assFile = UtilityFileFolder.getListPathFileInFolder(folderProcess, "ass", false);
                List<String> assFileLines = UtilityFileFolder.readRowTextFileToListString(assFile.get(0));
                List<String> assFileLinesWrite = new ArrayList<>();

                for (String assFileLine : assFileLines) {
                    if (assFileLine.contains("PlayResX: ")) {
                        assFileLine = "PlayResX: 1920";
                    }
                    if (assFileLine.contains("PlayResY: ")) {
                        assFileLine = "PlayResY: 1080";
                    }
                    if (assFileLine.contains("Style: Default")) {
                        //-- CENTER x MID
                        //assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,33,33,25,0";
                        //assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,77,77,25,0";
                        //assFileLine = "Style: Default,Arial,120,&H00FFFFFF,&H00FFFFFF,&H001F1F1F,&H000A0A0A,0,0,0,0,100,100,0,0,1,2,1,5,77,77,25,0";
                        assFileLine = "Style: Default,Arial,120,&H00000000,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,2,5,77,77,25,0";
                        //-- CENTER x BOTTOM
                        //assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,33,33,25,0";
                    }
                    if (assFileLine.contains(title)) {
                        assFileLine = assFileLine.replace(title, "{\\b1\\fs160}" + title);
                        assFileLine = assFileLine.replace(" - ", "\\N");
                    }
                    if (assFileLine.contains("EngLives")) {
                        assFileLine = assFileLine.replace("EngLives", "{\\b1\\fs172}Eng{\\c&H0000FF&}Lives");
                    }
                    //if (assFileLine.contains("\\N\\N/")) {
                    //    assFileLine = assFileLine.replace("\\N\\N/", "\\N\\N{\\i1\\c&HA1A1A1&\\fs90}/") + "{\\i0}";
                    //}

                    assFileLinesWrite.add(assFileLine);
                }
                String assFileLinesWriteData = String.join("\n", assFileLinesWrite);
                UtilityFileFolder.writeTextFileWithBufferedWriter(assFile.get(0), "UTF-8", assFileLinesWriteData, false);

                ffmpeg.mergeImageAndMp3ToMp4_New_1(fileCover, fileAudioMp3);

                List<String> listFilesMp4 = UtilityFileFolder.getListPathFileInFolder(folderProcess, "mp4", false);
                List<String> listFilesSub = UtilityFileFolder.getListPathFileInFolder(folderProcess, "ass", false);
                ffmpeg.writeSubToVideo2(listFilesSub.get(0), listFilesMp4.get(0));
            }
            
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(EnglishV1.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    
    private boolean makeMp3TemplateBasic(List<String> audioTextList, String fileAudioTxt, String fileAudioMp3) {
        audioTextList.removeAll(Collections.singleton(null));
        audioTextList.removeAll(Collections.singleton(""));
        //-- Create audio text file.
        UtilityFileFolder.writeTextFileWithBufferedWriter(fileAudioTxt, "UTF-8", StringUtils.join(audioTextList, "\n"), false);
        return procesMakeMp3(fileAudioTxt, fileAudioMp3);
    }    
    
    private boolean makeMp3Template1(List<String> audioTextList, String fileAudioTxt, String fileAudioMp3) {
        List<String> aduioTextListProcess = new ArrayList<>();
        audioTextList.removeAll(Collections.singleton(null));
        audioTextList.removeAll(Collections.singleton(""));        
        
        String start = "<volume level=\"0\">EngLives.</volume>\n<volume level=\"0\">EngLives.</volume>\n<volume level=\"0\">EngLives.</volume>";
        String end   = "<volume level=\"0\">EngLives.</volume>\n<volume level=\"0\">EngLives.</volume>\n<volume level=\"0\">EngLives.</volume>";        
        
        aduioTextListProcess.add(start);
        for (String line : audioTextList) {
            if (rbDavid.isSelected()) {
                line = addVoiceMicrosoftDavidDesktopWithSilence(processLine(line));
            } else {
                line = addVoiceMicrosoftZiraDesktopWithSilence(processLine(line), 0);
            }            
            //line = addVoiceMicrosoftZiraDesktopWithSilence(processLine(line));
            
            aduioTextListProcess.add(line);
        }
        aduioTextListProcess.add(end);

        //-- Create audio text file.
        UtilityFileFolder.writeTextFileWithBufferedWriter(fileAudioTxt, "UTF-8", StringUtils.join(aduioTextListProcess, "\n"), false);
        
        return procesMakeMp3(fileAudioTxt, fileAudioMp3);
    }
    
    private void processFileAss(String pathFileAss, String title) {
        List<String> assFileLines = UtilityFileFolder.readRowTextFileToListString(pathFileAss);
        List<String> assFileLinesProcess = new ArrayList<>();

        for (String assFileLine : assFileLines) {
            if (assFileLine.contains("PlayResX: ")) {
                assFileLine = "PlayResX: 1920";
            }
            
            if (assFileLine.contains("PlayResY: ")) {
                assFileLine = "PlayResY: 1080";
            }
            
            if (assFileLine.contains("Style: Default")) {
                //-- CENTER x MID
                //assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,33,33,25,0";
                //assFileLine = "Style: Default,Arial,160,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,77,77,25,0";
                //assFileLine = "Style: Default,Arial,160,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00FFFFFF,-1,0,0,0,100,100,0,0,1,2,3,2,77,77,25,0";
                //assFileLine = "Style: Default,Arial,140,&H00000000,&H00FFFFFF,&H00FFFFFF,&H002C2C2C,-1,0,0,0,100,100,0,0,1,1,3,5,77,77,25,0";
                assFileLine = "Style: Default,Arial,100,&H00000000,&H00FFFFFF,&H00FFFFFF,&H002C2C2C,-1,0,0,0,100,100,0,0,1,1,3,5,77,77,25,0";
                //assFileLine = "Style: Default,Arial,80,&H00000000,&H00FFFFFF,&H00FFFFFF,&H002C2C2C,-1,0,0,0,100,100,0,0,1,1,0,5,77,77,25,0";
                //-- CENTER x BOTTOM
                //assFileLine = "Style: Default,Arial,120,&H00232323,&H00FFFFFF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,33,33,25,0";
            }
            
            if (assFileLine.contains(title)) {
                assFileLine = assFileLine.replace(title, "{\\b1\\fs160}" + title);
                assFileLine = assFileLine.replace(" - ", "\\N");
            }
            
            if (assFileLine.contains("EngLives")) {
                //assFileLine = assFileLine.replace("EngLives", "{\\b1\\fs172}Eng{\\c&H0000FF&}Lives");
                assFileLine = assFileLine.replace("EngLives", "{\\b1\\fs172\\c&H000000&}Eng{\\c&H0000FF&}Lives");
                
            }

            assFileLinesProcess.add(assFileLine);
        }

        UtilityFileFolder.writeTextFileWithBufferedWriter(pathFileAss, "UTF-8", String.join("\n", assFileLinesProcess), false);        
    }
    
    private boolean procesMakeMp3(String fileAudioTxt, String fileAudioMp3) {
        try {
            ProcessBuilder process = new ProcessBuilder("cmd.exe", "/c", "start", "chcp", "65001", "&", BALABOLKA, "-msq", fileAudioTxt, fileAudioMp3);
            process.redirectErrorStream(true);
            System.out.println("process: " + process.command());
            Process p = process.start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("-- " + line);   
            }
            
            if (p.waitFor() == 0) {
                return true;
            }
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(EnglishV1.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
    
    private String processLine(String line) {
        String rs = StringUtils.trim(line);
        //--
        rs = processSpecialCharacter(rs);
        //--
        rs = rs + ".";
        rs = rs.replaceAll("[\\.]+$", ".");    
        //--
        rs = StringUtils.trim(rs);
        //--
        return rs;
    }
    
    private String processSpecialCharacter(String text) {
        String rs = StringUtils.trim(text);
        rs = rs.replace("’", "'");
        rs = rs.replace("…", "...");
        return rs;
    }
    
    
    private String addVoiceMicrosoftZiraDesktop(String str) {
        String rs;
        String lineUpdateVoice = "<voice required=\"Name=Microsoft Zira Desktop\">?1</voice>";
        rs = lineUpdateVoice.replace("?1", str);
        return rs;
    }    
    
    
    private String autoAddVocie(String line) {
        String rs = "";
        String person1 = "Sharon↕F1";
        String person2 = "Paola↕F1";
        String person3 = "Lan↕F2";
        String person4 = "Weatherman↕M1";
        String person5 = "Thuy↕F1";
        String person6 = "Grandma↕F2";

        String strSilentCustom1 = "<volume level=\"0\">?1</volume>?2";
        List<String> persons = new ArrayList<>();
        persons.add(person1);
        persons.add(person2);        
        persons.add(person3);
        persons.add(person4);
        persons.add(person5);
        persons.add(person6);
        
        for (String person : persons) {
            if (line.startsWith(person.split("↕")[0] + ":")) {
                String tmpPerson = line.split(":")[0] + ":";
                String tmpSpeak = line.replaceFirst(tmpPerson, "");
                String tmpLine = strSilentCustom1.replace("?1", tmpPerson).replace("?2", tmpSpeak);
                System.out.println("tmpLine: " + tmpLine);
                
                String gender = person.split("↕")[1];
                switch (gender) {
                    case "M1":
                        return addVoiceMicrosoftDavidDesktopWithSilence(tmpLine);
                    case "M2":
                        return addVoiceMicrosoftDavidDesktopWithSilence(tmpLine);
                    case "F1":
                        return addVoiceMicrosoftZiraDesktopWithSilence(tmpLine,0);
                    case "F2":
                        return addVoiceMicrosoftZiraDesktopWithSilence(tmpLine,10);
                    default:
                        System.out.println("Don't found voice");
                        System.exit(0);
                }
            }            
        }
        
        if (rs.isEmpty()) {
            return addVoiceMicrosoftZiraDesktopWithSilence(line,0);
        }
        
        return rs;
    }
    
    private String addVoiceGoogle2WithSilence(String str) {
        String rs;
        String lineUpdateVoice = "$1\n<voice required=\"Name=Microsoft Zira Desktop\"><volume level=\"0\">$1</volume></voice>";
        rs = lineUpdateVoice.replace("$1", str);
        return rs;
    }      
    
    private String addVoiceSilence(String str) {
        String rs;
        String lineUpdateVoice = "<voice required=\"Name=Microsoft Zira Desktop\"><volume level=\"0\">$1</volume></voice>";
        rs = lineUpdateVoice.replace("$1", str);
        return rs;
    }
    
    private String addVoiceMicrosoftZiraDesktopWithSilence(String str, int picth) {
        String rs;
        String lineUpdateVoice = "<voice required=\"Name=Microsoft Zira Desktop\"><pitch absmiddle=\"$c1\">$1</pitch></voice>\n"
                + "<voice required=\"Name=Microsoft Zira Desktop\"><volume level=\"0\">$1</volume></voice>";
        lineUpdateVoice = lineUpdateVoice.replace("$c1", String.valueOf(picth));
        
        rs = lineUpdateVoice.replace("$1", str);
        return rs;
    }     
    
    private String addVoiceMicrosoftDavidDesktopWithSilence(String str, int picth) {
        String rs;
        String lineUpdateVoice = "<voice required=\"Name=Microsoft David Desktop\"><pitch absmiddle=\"$c1\">$1</pitch></voice>\n"
                + "<voice required=\"Name=Microsoft David Desktop\"><volume level=\"0\">$1</volume></voice>";
        lineUpdateVoice = lineUpdateVoice.replace("$c1", String.valueOf(picth));
        
        rs = lineUpdateVoice.replace("$1", str);
        return rs;
    }     
    
    private String addVoiceMicrosoftDavidDesktopWithSilence(String str) {
        String rs;
        String lineUpdateVoice = "<voice required=\"Name=Microsoft David Desktop\">$1</voice>\n<volume level=\"0\">$1</volume>";
        rs = lineUpdateVoice.replace("$1", str);
        return rs;
    } 
    
    private void makeHtml(int templateType) {
        int type = 1;
        
        List<String> inputRoot = new ArrayList<>();
        List<String> inputProcess = new ArrayList<>();

        inputRoot.addAll(Arrays.asList(StringUtils.stripAll(taInput.getText().split("[\\r\\n]"))));
        inputRoot.removeAll(Collections.singleton(null));
        inputRoot.removeAll(Collections.singleton(""));
        
        List<String> lines = new ArrayList<>();
        lines.addAll(inputRoot);
        
        List<String> linesEn = new ArrayList<>();
        List<String> linesVn = new ArrayList<>();
        List<ObjText> listObjText = new ArrayList<>();

        //==
        String templateWords = "<div class=\"wordsTemplate col border p-2 mb-2 d-flex flex-wrap align-items-center\">\n" +
                                "	<span class=\"words-english\">$1</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-light font-italic\">$2</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-bold display-6 text-primary w-100\">$3</span>\n" +
                            "</div>";      
        
        String templateWordsBold = "<div class=\"wordsTemplate col border p-2 mb-2 d-flex flex-wrap align-items-center\">\n" +
                                "	<span class=\"words-english font-weight-bold\">$1</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-light font-italic\">$2</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-bold display-6 text-primary w-100\">$3</span>\n" +
                            "</div>"; 
        
        String templateWordsNote = "<div class=\"wordsTemplate col border p-2 mb-2 d-flex flex-wrap align-items-center\">\n" +
                                "	<span class=\"words-english font-weight-light font-italic\">$1</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-light font-italic\">$2</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-bold display-6 text-primary w-100\">$3</span>\n" +
                            "</div>";         
        //==
        String templateWords1 = "<div class=\"wordsTemplate1 col border p-2 mb-2 d-flex flex-wrap align-items-center\">\n" +
                                "	<span class=\"words-english\">$1</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-light font-italic\">$2</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-bold display-6 text-primary w-100\">$3</span>\n" +
                            "</div>";      
        
        String templateWords1Bold = "<div class=\"wordsTemplate1 col border p-2 mb-2 d-flex flex-wrap align-items-center\">\n" +
                                "	<span class=\"words-english font-weight-bold\">$1</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-light font-italic\">$2</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-bold display-6 text-primary w-100\">$3</span>\n" +
                            "</div>"; 
        
        String templateWords1Note = "<div class=\"wordsTemplate1 col border p-2 mb-2 d-flex flex-wrap align-items-center\">\n" +
                                "	<span class=\"words-english font-weight-light font-italic\">$1</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-light font-italic\">$2</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-bold display-6 text-primary w-100\">$3</span>\n" +
                            "</div>";      
         //==
         String separator1 = "<hr class=\"w-100 bg-info mt-4 mb-3\">";
         String separator2 = "<hr class=\"w-100 bg-secondary mt-2 mb-2\">";
         //==
        String templateCol2 = "<div class=\"col border p-2 m-1 d-flex flex-wrap align-items-center\">$1</div><div class=\"col border p-2 m-1 d-flex flex-wrap align-items-center\">$2</div><div class=\"w-100\"></div>\n";
        
        
        if (!taInput.getText().contains("↔")) {
            String dataHtml = "";
            for (String line : lines) {
                if (line.startsWith("[Col-2] ")) {
                    line = line.replaceFirst("\\[Col-2\\] ", "");
                    String[] tmpLine = line.split("↨", -1);
                    dataHtml += templateCol2.replace("$1", tmpLine[0]).replace("$2", tmpLine[1]);
                }
            }
            taOutput.setText(dataHtml);
        } else {
            boolean isEn = true;
            for (String line : lines) {
                if (line.trim().equalsIgnoreCase("↔")) {
                    isEn = false;
                } else {
                    line = processSpecialCharacter(line);
                    if (isEn) {
                        linesEn.add(line);
                    } else {
                        linesVn.add(line);
                    }
                }
            }

            if (linesEn.size() == linesVn.size()) {
                for (int i = 0; i < linesEn.size(); i++) {
                    ObjText objText = new ObjText();
                    objText.setEn(StringUtils.trim(linesEn.get(i)));
                    objText.getVn().add(StringUtils.trim(linesVn.get(i)));
                    listObjText.add(objText);
                }

//            if (listObjText.size() > 0) {
//                gson = new GsonBuilder().setPrettyPrinting().create();
//                String jsonData = gson.toJson(listObjText);
//                UtilityFileFolder.writeTextFileWithBufferedWriter(pahtFileJson, "UTF-8", jsonData, false);
//            }
                String dataHtml = "";
                for (ObjText objText : listObjText) {
                    String tmpEn = objText.getEn();
                    String tmpVn = objText.getVn().get(0);
                    
                    if (tmpEn.trim().equalsIgnoreCase("◄▬►")) {
                        dataHtml = dataHtml + separator1 + "\n";
                    } else if (tmpEn.trim().equalsIgnoreCase("◄▬▬►")) {
                        dataHtml = dataHtml + separator2 + "\n";
                    } else if (tmpEn.startsWith("◄Bold►")) {
                        tmpEn = tmpEn.replaceFirst("◄Bold►", "");
                        tmpVn = tmpVn.replaceFirst("◄Bold►", "");
                        
                        if (type == 1) {
                            tmpEn = StringUtils.trim(tmpEn.replaceFirst("(^[^:]+: )", "<b>$1</b> "));
                        }
                        
                        switch (templateType) {
                            case 1:
                                dataHtml = dataHtml + templateWords1Bold.replace("$1", tmpEn).replace("$3", tmpVn) + "\n";
                                break;
                            default:
                                dataHtml = dataHtml + templateWordsBold.replace("$1", tmpEn).replace("$3", tmpVn) + "\n";
                        }               
                        
                    } else if (tmpEn.startsWith("◄Note►")) {
                        tmpEn = tmpEn.replaceFirst("◄Note►", "");
                        tmpVn = tmpVn.replaceFirst("◄Note►", "");

                        if (type == 1) {
                            tmpEn = tmpEn.replaceFirst("(^[^:]+: )", "<b>$1</b> ");
                        }
                        
                        switch (templateType) {
                            case 1:
                                dataHtml = dataHtml + templateWords1Note.replace("$1", tmpEn).replace("$3", tmpVn) + "\n";
                                break;
                            default:
                                dataHtml = dataHtml + templateWordsNote.replace("$1", tmpEn).replace("$3", tmpVn) + "\n";
                        }                        
                        
                    } else {
                        if (type == 1) {
                            tmpEn = tmpEn.replaceFirst("(^[^:]+: )", "<b>$1</b> ");
                        }
                        
                        switch (templateType) {
                            case 1:
                                dataHtml = dataHtml + templateWords1.replace("$1", tmpEn).replace("$3", tmpVn) + "\n";
                                break;
                            default:
                                dataHtml = dataHtml + templateWords.replace("$1", tmpEn).replace("$3", tmpVn) + "\n";
                        }
                        
                    }

                }

                taOutput.setText(dataHtml);
                //UtilityFileFolder.writeTextFileWithBufferedWriter(pahtFileHtml, "UTF-8", dataHtml, false);

            } else {
                JOptionPane.showMessageDialog(this, "Lines EN and Lines VN don't same!");
            }
        }
        
    }
    
    private void makeHtml_bk(int templateType) {
        int type = 1;
        
        List<String> inputRoot = new ArrayList<>();
        List<String> inputProcess = new ArrayList<>();

        inputRoot.addAll(Arrays.asList(StringUtils.stripAll(taInput.getText().split("[\\r\\n]"))));
        inputRoot.removeAll(Collections.singleton(null));
        inputRoot.removeAll(Collections.singleton(""));
        
        List<String> lines = new ArrayList<>();
        lines.addAll(inputRoot);
        
        List<String> linesEn = new ArrayList<>();
        List<String> linesVn = new ArrayList<>();
        List<ObjText> listObjText = new ArrayList<>();

        //==
        String templateWords = "<div class=\"wordsTemplate col border p-2 mb-2 d-flex flex-wrap align-items-center\">\n" +
                                "	<span class=\"words-english\">$1</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-light font-italic\">$2</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-bold display-6 text-primary w-100\">$3</span>\n" +
                            "</div>";      
        
        String templateWordsBold = "<div class=\"wordsTemplate col border p-2 mb-2 d-flex flex-wrap align-items-center\">\n" +
                                "	<span class=\"words-english font-weight-bold\">$1</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-light font-italic\">$2</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-bold display-6 text-primary w-100\">$3</span>\n" +
                            "</div>"; 
        
        String templateWordsNote = "<div class=\"wordsTemplate col border p-2 mb-2 d-flex flex-wrap align-items-center\">\n" +
                                "	<span class=\"words-english font-weight-light font-italic\">$1</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-light font-italic\">$2</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-bold display-6 text-primary w-100\">$3</span>\n" +
                            "</div>";         
        //==
        String templateWords1 = "<div class=\"wordsTemplate1 col border p-2 mb-2 d-flex flex-wrap align-items-center\">\n" +
                                "	<span class=\"words-english\">$1</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-light font-italic\">$2</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-bold display-6 text-primary w-100\">$3</span>\n" +
                            "</div>";      
        
        String templateWords1Bold = "<div class=\"wordsTemplate1 col border p-2 mb-2 d-flex flex-wrap align-items-center\">\n" +
                                "	<span class=\"words-english font-weight-bold\">$1</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-light font-italic\">$2</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-bold display-6 text-primary w-100\">$3</span>\n" +
                            "</div>"; 
        
        String templateWords1Note = "<div class=\"wordsTemplate1 col border p-2 mb-2 d-flex flex-wrap align-items-center\">\n" +
                                "	<span class=\"words-english font-weight-light font-italic\">$1</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-light font-italic\">$2</span><span></span>\n" +
                                "	<span class=\"d-none font-weight-bold display-6 text-primary w-100\">$3</span>\n" +
                            "</div>";      
         //==
        String templateCol2 = "<div class=\"col border p-2 m-1 d-flex flex-wrap align-items-center\">$1</div><div class=\"col border p-2 m-1 d-flex flex-wrap align-items-center\">$2</div><div class=\"w-100\"></div>\n";
        
        
        if (!taInput.getText().contains("↔")) {
            String dataHtml = "";
            for (String line : lines) {
                if (line.startsWith("[Col-2] ")) {
                    line = line.replaceFirst("\\[Col-2\\] ", "");
                    String[] tmpLine = line.split("↨", -1);
                    dataHtml += templateCol2.replace("$1", tmpLine[0]).replace("$2", tmpLine[1]);
                }
            }
            taOutput.setText(dataHtml);
        } else {
            boolean isEn = true;
            for (String line : lines) {
                if (line.trim().equalsIgnoreCase("↔")) {
                    isEn = false;
                } else {
                    if (isEn) {
                        linesEn.add(line);
                    } else {
                        linesVn.add(line);
                    }
                }
            }

            if (linesEn.size() == linesVn.size()) {
                for (int i = 0; i < linesEn.size(); i++) {
                    ObjText objText = new ObjText();
                    objText.setEn(StringUtils.trim(linesEn.get(i)));
                    objText.getVn().add(StringUtils.trim(linesVn.get(i)));
                    listObjText.add(objText);
                }

//            if (listObjText.size() > 0) {
//                gson = new GsonBuilder().setPrettyPrinting().create();
//                String jsonData = gson.toJson(listObjText);
//                UtilityFileFolder.writeTextFileWithBufferedWriter(pahtFileJson, "UTF-8", jsonData, false);
//            }
                String dataHtml = "";
                for (ObjText objText : listObjText) {
                    String tmpEn = objText.getEn();

                    if (tmpEn.startsWith("[Bold] ")) {
                        tmpEn = objText.getEn().replaceFirst("\\[Bold\\] ", "");

                        if (type == 1) {
                            tmpEn = tmpEn.replaceFirst("(^[^:]+: )", "<b>$1</b> ");
                        }
                        
                        switch (templateType) {
                            case 1:
                                dataHtml = dataHtml + templateWords1Bold.replace("$1", tmpEn).replace("$3", objText.getVn().get(0)) + "\n";
                                break;
                            default:
                                dataHtml = dataHtml + templateWordsBold.replace("$1", tmpEn).replace("$3", objText.getVn().get(0)) + "\n";
                        }               
                        
                    } else if (tmpEn.startsWith("[Note] ")) {
                        tmpEn = objText.getEn().replaceFirst("\\[Note\\] ", "");

                        if (type == 1) {
                            tmpEn = tmpEn.replaceFirst("(^[^:]+: )", "<b>$1</b> ");
                        }
                        
                        switch (templateType) {
                            case 1:
                                dataHtml = dataHtml + templateWords1Note.replace("$1", tmpEn).replace("$3", objText.getVn().get(0)) + "\n";
                                break;
                            default:
                                dataHtml = dataHtml + templateWordsNote.replace("$1", tmpEn).replace("$3", objText.getVn().get(0)) + "\n";
                        }                        
                        
                    } else {
                        if (type == 1) {
                            tmpEn = tmpEn.replaceFirst("(^[^:]+: )", "<b>$1</b> ");
                        }
                        
                        switch (templateType) {
                            case 1:
                                dataHtml = dataHtml + templateWords1.replace("$1", tmpEn).replace("$3", objText.getVn().get(0)) + "\n";
                                break;
                            default:
                                dataHtml = dataHtml + templateWords.replace("$1", tmpEn).replace("$3", objText.getVn().get(0)) + "\n";
                        }
                        
                    }

                }

                taOutput.setText(dataHtml);
                //UtilityFileFolder.writeTextFileWithBufferedWriter(pahtFileHtml, "UTF-8", dataHtml, false);

            } else {
                JOptionPane.showMessageDialog(this, "Lines EN and Lines VN don't same!");
            }
        }
        
    }    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bgVoices = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        btRun = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        btMakeHtml = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        lbRegExRemove = new javax.swing.JLabel();
        tfRegExRemove = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        taInput = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        taOutput = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        tfPathFolder = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        cbSortByAlphabet = new javax.swing.JCheckBox();
        jPanel5 = new javax.swing.JPanel();
        btEngLives = new javax.swing.JButton();
        btMakeVideo = new javax.swing.JButton();
        btAddSubToVideo = new javax.swing.JButton();
        rbAuto = new javax.swing.JRadioButton();
        rbZira = new javax.swing.JRadioButton();
        rbDavid = new javax.swing.JRadioButton();
        btBilingual = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btRun.setText("Run");
        btRun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btRunActionPerformed(evt);
            }
        });

        jButton1.setText("Run Text");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Clear");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        btMakeHtml.setText("Make Html");
        btMakeHtml.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btMakeHtmlActionPerformed(evt);
            }
        });

        jButton3.setText("Make HTML Quiz");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("jButton4");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Split Words");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btRun)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2)
                        .addGap(41, 41, 41)
                        .addComponent(jButton4))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btMakeHtml)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton5)))
                .addContainerGap(54, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btRun)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btMakeHtml)
                    .addComponent(jButton3)
                    .addComponent(jButton5))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lbRegExRemove.setText(" RegExr Remove");

        tfRegExRemove.setText("^[-|⟹]");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lbRegExRemove)
                        .addGap(0, 275, Short.MAX_VALUE))
                    .addComponent(tfRegExRemove))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbRegExRemove)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfRegExRemove, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        taInput.setColumns(20);
        taInput.setRows(5);
        jScrollPane1.setViewportView(taInput);

        taOutput.setColumns(20);
        taOutput.setRows(5);
        jScrollPane2.setViewportView(taOutput);

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setText("Folder");

        tfPathFolder.setText("C:\\Users\\bnson\\Downloads\\Tmp");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(tfPathFolder))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfPathFolder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        cbSortByAlphabet.setSelected(true);
        cbSortByAlphabet.setText("Sort by alphabet");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cbSortByAlphabet)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cbSortByAlphabet)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btEngLives.setText("EngLives");
        btEngLives.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEngLivesActionPerformed(evt);
            }
        });

        btMakeVideo.setText("Make Video");
        btMakeVideo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btMakeVideoActionPerformed(evt);
            }
        });

        btAddSubToVideo.setText("Add Sub to Video");
        btAddSubToVideo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddSubToVideoActionPerformed(evt);
            }
        });

        bgVoices.add(rbAuto);
        rbAuto.setText("Auto");

        bgVoices.add(rbZira);
        rbZira.setSelected(true);
        rbZira.setText("Zira");

        bgVoices.add(rbDavid);
        rbDavid.setText("David");

        btBilingual.setText("Bilingual");
        btBilingual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btBilingualActionPerformed(evt);
            }
        });

        jButton6.setText("jButton6");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(btEngLives)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btMakeVideo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btAddSubToVideo))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(rbAuto)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(rbZira)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(rbDavid))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(btBilingual)
                        .addGap(53, 53, 53)
                        .addComponent(jButton6)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbAuto)
                    .addComponent(rbZira)
                    .addComponent(rbDavid))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btBilingual)
                    .addComponent(jButton6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btEngLives)
                    .addComponent(btMakeVideo)
                    .addComponent(btAddSubToVideo))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 438, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 439, Short.MAX_VALUE))
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 260, Short.MAX_VALUE)
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btRunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btRunActionPerformed
        processVocabulary();
    }//GEN-LAST:event_btRunActionPerformed

    private void btEngLivesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEngLivesActionPerformed
       //actionEnglives001();
       actionEnglives002();
    }//GEN-LAST:event_btEngLivesActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        processText();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        tfPathFolder.setText("");
        taInput.setText("");
        taOutput.setText("");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btMakeHtmlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btMakeHtmlActionPerformed
        makeHtml(1);
    }//GEN-LAST:event_btMakeHtmlActionPerformed

    private void btMakeVideoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btMakeVideoActionPerformed
        // TODO add your handling code here:
        String pathFolder       = tfPathFolder.getText().trim();
        String pathFileRoot     = pathFolder + "\\root.txt";
        String pahtFileJson     = pathFolder + "\\root.json";
        String pathFileHtml     = pathFolder + "\\root.html";
        String pathFileCover    = pathFolder + "\\cover.png";

        String fileAudioTxt = pathFileRoot.replaceAll("root.txt", "audio.txt");
        String fileAudioMp3 = pathFileRoot.replaceAll("root.txt", "audio.mp3");
        String fileAudioMp4 = pathFileRoot.replaceAll("root.txt", "audio.mp4");    
        String fileAudioSrt = pathFileRoot.replaceAll("root.txt", "audio.srt");
        String fileAudioAss = pathFileRoot.replaceAll("root.txt", "audio.ass");
        
        String title;
        
        List<String> audioTextList = UtilityFileFolder.readRowTextFileToListString(pathFileRoot);
        title = StringUtils.trim(audioTextList.get(0));
                
        if (makeMp3Template1(audioTextList, fileAudioTxt, fileAudioMp3)) {
            ffmpeg.convertSubSrtToAss(fileAudioSrt);
            processFileAss(fileAudioAss, title);
            
            ffmpeg.mergeImageAndMp3ToMp4_New_1(pathFileCover, fileAudioMp3);
        }
        
    }//GEN-LAST:event_btMakeVideoActionPerformed

    private void btAddSubToVideoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddSubToVideoActionPerformed
        String pathFolder       = tfPathFolder.getText().trim();
        String fileAudioMp4 = pathFolder + "\\audio.mp4";
        String fileAudioAss = pathFolder + "\\audio.ass";

        ffmpeg.writeSubToVideo2(fileAudioAss, fileAudioMp4);
    }//GEN-LAST:event_btAddSubToVideoActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        String templateQuiz1 = "<div class=\"col m-1\">\n" +
            "	<div class=\"quizTemplate1 row p-2 border rounded\">\n" +
            "		<div class=\"question col border p-2 m-1 font-weight-bold\">$1</div>\n" +
            "		<div class=\"w-100\"></div>\n" +
            "		<div class=\"answer col-auto border p-2 m-1\" answervalue=\"0\">$2</div>\n" +
            "		<div class=\"answer col-auto border p-2 m-1\" answervalue=\"1\">$3</div>\n" +
            "		<div class=\"w-100\"></div>\n" +
            "		<div class=\"explain row border p-2 m-1 align-items-center w-100\">\n" +
            "			<span>\n" +
            "				<u>*Explain:</u><br>\n" +
            "				<i>$4</i>\n" +
            "			</span>\n" +
            "		</div>\n" +
            "	</div>\n" +
            "</div>\n" +
            "<div class=\"w-100\"></div>";
        
        List<String> inputRoot = new ArrayList<>();
        inputRoot.addAll(Arrays.asList(StringUtils.stripAll(taInput.getText().split("[\\r\\n]"))));
        
        int index = 1;
        for (String str : inputRoot) {
            templateQuiz1 = templateQuiz1.replace("$" + index, str);
            index++;
        }
        
        taOutput.setText(templateQuiz1);
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void btBilingualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btBilingualActionPerformed
        try {
            String pathFolder = tfPathFolder.getText().trim();
            String pathFolderEnglish = pathFolder + "\\English";
            String pathFolderBilingual = pathFolder + "\\Bilingual";

            String pathFileRoot = pathFolderBilingual + "\\root.txt";
            String pahtFileJson = pathFolderBilingual + "\\root.json";
            String pathFileHtml = pathFolderBilingual + "\\root.html";
            String pathFileCover = pathFolderBilingual + "\\cover.png";

            String fileAudioTxt = pathFileRoot.replaceAll("root.txt", "audio.txt");
            String fileAudioMp3 = pathFileRoot.replaceAll("root.txt", "audio.mp3");
            String fileAudioMp4 = pathFileRoot.replaceAll("root.txt", "audio.mp4");
            String fileAudioSrt = pathFileRoot.replaceAll("root.txt", "audio.srt");
            String fileAudioAss = pathFileRoot.replaceAll("root.txt", "audio.ass");

            String jsonString;

            //================
            if (!UtilityFileFolder.isExistsFolder(pathFolderEnglish)) {
                UtilityFileFolder.createDirectory(pathFolderEnglish);
                UtilityFileFolder.createDirectory(pathFolderBilingual);
                
                File folder = new File(pathFolder);
                for (File file : folder.listFiles()) {
                    
                    if (file.isFile()) {
                        if (file.getName().equalsIgnoreCase("root.json") || file.getName().equalsIgnoreCase("cover.png")) {
                            String copyTo = pathFolderBilingual + "\\" + file.getName();
                            Files.copy(file.toPath(), new File(copyTo).toPath(), StandardCopyOption.REPLACE_EXISTING);                        
                        }                        
                        
                        String moveTo = pathFolderEnglish + "\\" + file.getName();
                        Files.move(file.toPath(), new File(moveTo).toPath(), StandardCopyOption.REPLACE_EXISTING);
                    }
                    
                }
                
                

                //move(new File(pathFolder), new File(pathFolderEnglish));
                
                //Files.move(new File(pathFolder).toPath(), new File(pathFolderEnglish).toPath(), StandardCopyOption.REPLACE_EXISTING);
                

                //UtilityFileFolder.copyDirectory(pathFolder, pathFolderEnglish);
                //UtilityFileFolder.copyDirectoryCompatibityMode(new File(pahtFileJson + "\\root.json"), new File(pathFolderBilingual));
            }
            //================
            jsonString = UtilityFileFolder.readTextFileToString_ReadAllBytes(pahtFileJson);
            
            Gson gson = new Gson();
            
            //java.lang.reflect.Type listType = new TypeToken<ArrayList<ObjWords>>() {}.getType();
            java.lang.reflect.Type listType = new TypeToken<ArrayList<ObjText>>() {}.getType();
            
            //ArrayList<ObjWords> listObjWords = new Gson().fromJson(jsonString, listType);
            ArrayList<ObjText> listObjWords = new Gson().fromJson(jsonString, listType);

            List<String> audioScript = new ArrayList<>();

            audioScript.add(addVoiceSilence(processLine("EngLives")));
            audioScript.add(addVoiceSilence(processLine("EngLives")));
            audioScript.add(addVoiceSilence(processLine("EngLives")));

            String[] arrPathFolder = pathFolderBilingual.split("\\\\");
            int arrPathFolderLen = arrPathFolder.length;
            String audioTitle = arrPathFolder[arrPathFolderLen - 4] + " ★ "
                    //+ arrPathFolder[arrPathFolderLen - 2].replaceFirst("\\d - ", "") + " ★ "
                    + arrPathFolder[arrPathFolderLen - 1];

            audioTitle = audioTitle.replaceAll("-", "★");
            audioTitle = audioTitle.replaceAll("Bilingual", "Bài Đọc 1 ★ Song Ngữ ★ Học tiếng anh lớp 12");
            
            //audioScript.add(addVoiceSilence(processLine(audioTitle)));
            //audioScript.add(addVoiceSilence(processLine(audioTitle)));
            //audioScript.add(addVoiceMicrosoftZiraDesktopWithSilence(processLine(audioTitle), 0));

            for (ObjText objWords : listObjWords) {
                //System.out.println("objWords: " + objWords.getEn());
                //System.out.println("objWords: " + objWords.getVn().get(0));
                
                if (rbZira.isSelected()) {
                    audioScript.add(addVoiceMicrosoftZiraDesktopWithSilence(processLine(objWords.getEn()), 0));
                    audioScript.add(addVoiceGoogle2WithSilence(processLine(objWords.getVn().get(0))));                    
                } else if (rbDavid.isSelected()) {
                    audioScript.add(addVoiceMicrosoftDavidDesktopWithSilence(processLine(objWords.getEn()), 0));
                    audioScript.add(addVoiceGoogle2WithSilence(processLine(objWords.getVn().get(0))));                                        
                }

            }

            audioScript.add(addVoiceSilence(processLine("EngLives")));
            audioScript.add(addVoiceSilence(processLine("EngLives")));
            audioScript.add(addVoiceSilence(processLine("EngLives")));

            for (String str : audioScript) {
                System.out.println(str);
            }

            //========================
            //========================
            if (makeMp3TemplateBasic(audioScript, fileAudioTxt, fileAudioMp3)) {
                ffmpeg.convertSubSrtToAss(fileAudioSrt);
                processFileAss(fileAudioAss, audioTitle);

                ffmpeg.mergeImageAndMp3ToMp4_New_1(pathFileCover, fileAudioMp3);
            }

            String fileVideoSub = pathFileRoot.replaceAll("root.txt", audioTitle + ".mp4");
            ffmpeg.writeSubToVideo2(fileAudioAss, fileAudioMp4, fileVideoSub);
        } catch (Exception ex) {
            Logger.getLogger(EnglishV1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btBilingualActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        String jsonStr = UtilityFileFolder.readTextFileToString_ReadAllBytes(tfPathFolder.getText() + "\\root.json");
        taOutput.setText("");
        //Gson GSON = new Gson();
        List<ObjWord> words = Arrays.asList(new GsonBuilder().create().fromJson(jsonStr, ObjWord[].class));

        for (ObjWord word : words) {
            taOutput.append(word.getEn() + " = " + word.getVn().get(0) + "\n");
        }

    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        String text = taInput.getText().trim();
        text = text.replaceAll("[\\r\\n]", " ");
        text = text.replaceAll("[\\?\\.,:]", " ");
        text = UtilityString.trimSpace(text);
        System.out.println("text: " + text);
        
        List<String> words = new ArrayList<>();
        words.addAll(Arrays.asList(StringUtils.stripAll(text.split(" "))));
        words.removeAll(Collections.singleton(null));
        words.removeAll(Collections.singleton(""));
        words.removeAll(Collections.singleton("-"));
        words.removeAll(Collections.singleton("–"));
        words.removeAll(Collections.singleton("…"));
        
        UtilityList.removeDuplication(words);
        
        words = words.stream().map(s -> s.replaceAll("[!]", "")).collect(Collectors.toList());

        //words.sort(Comparator.comparingInt(String::length));
        //Collections.sort(words);
        Collections.sort(words, Comparator.comparingInt(String::length));
        Collections.reverse(words);
        

        taOutput.append(StringUtils.join(words, "\n"));
        
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EnglishV1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EnglishV1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EnglishV1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EnglishV1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new EnglishV1().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup bgVoices;
    private javax.swing.JButton btAddSubToVideo;
    private javax.swing.JButton btBilingual;
    private javax.swing.JButton btEngLives;
    private javax.swing.JButton btMakeHtml;
    private javax.swing.JButton btMakeVideo;
    private javax.swing.JButton btRun;
    private javax.swing.JCheckBox cbSortByAlphabet;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbRegExRemove;
    private javax.swing.JRadioButton rbAuto;
    private javax.swing.JRadioButton rbDavid;
    private javax.swing.JRadioButton rbZira;
    private javax.swing.JTextArea taInput;
    private javax.swing.JTextArea taOutput;
    private javax.swing.JTextField tfPathFolder;
    private javax.swing.JTextField tfRegExRemove;
    // End of variables declaration//GEN-END:variables
}
