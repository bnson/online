/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package robot.data;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import object.dict.ObjWord;
import utility.UtilityFileFolder;
import utility.UtilityList;

/**
 *
 * @author Admin
 */
public class Import extends javax.swing.JFrame {

    private final String url = "jdbc:postgresql://localhost:5432/postgres";
    private final String user = "postgres";
    private final String password = "gemdark1986!";
    
    public Import() {
        initComponents();
    }

    public java.sql.Connection connect() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }    
    
    public List<String> getListPathFileNotYetImportEnSentences() {
        List<String> rsList = new ArrayList<>();
        String SQL = "select path_file from dictionary.management_imports where import_status = false;";

        try {
            // Step 1: Establishing a Connection
            java.sql.Connection conn = connect();
            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = conn.prepareStatement(SQL);            
            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            ResultSet rs = preparedStatement.executeQuery();

            // Step 4: Process the ResultSet object.
            while (rs.next()) {
                String pathFile = rs.getString("path_file").trim();
                rsList.add(pathFile);
            }
            
        } catch (SQLException e) {
            printSQLException(e);
            return null;
        }
        
        return rsList;
    }    
    
    public void insertDictionaryManagementImports(List<String> list, String importFrom) {
        try {
            String SQL = "INSERT INTO dictionary.management_imports(path_file, import_from, import_status) VALUES (?, ?, ?);";
            java.sql.Connection conn = connect();
            PreparedStatement statement = conn.prepareStatement(SQL);
            int count = 0;

            for (String item : list) {
                statement.setString(1, item);
                statement.setString(2, importFrom);
                statement.setBoolean(3, true);
                statement.addBatch();
                count++;
                // execute every 100 rows or less
                if (count % 100 == 0 || count == list.size()) {
                    statement.executeBatch();
                }
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
 
    public void insertDictionaryEnSentencesTmp(List<String> list) {
        String SQL = "INSERT INTO dictionary.en_sentences_raw(sentence_raw) VALUES (?);";
        try ( java.sql.Connection conn = connect();  PreparedStatement statement = conn.prepareStatement(SQL);) {
            UtilityList.trimSpace(list);
            list.removeAll(Arrays.asList("", null));
            UtilityList.removeDuplication(list);
            list.removeIf(s -> s.startsWith("►"));

            int count = 0;

            for (String item : list) {
                System.out.println("item: " + item);
                statement.setString(1, item);
                statement.addBatch();
                count++;
                // execute every 100 rows or less
                if (count % 100 == 0 || count == list.size()) {
                    statement.executeBatch();
                }
            }

//            conn.close();
//            statement.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }  
    
    public void updateStatusEnSentences(String path) {
        String SQL = "UPDATE dictionary.management_imports SET import_status = true WHERE path_file = ?;";
        try ( java.sql.Connection conn = connect();  PreparedStatement statement = conn.prepareStatement(SQL);) {

            statement.setString(1, path);
            statement.execute();

        } catch (SQLException ex) {
            Logger.getLogger(Import.class.getName()).log(Level.SEVERE, null, ex);
        }

    }   
  
    public static void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        tfPathFolderWorking = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        btScanImportPathFileData = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        taOutput = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Path folder working");

        tfPathFolderWorking.setText("D:\\Databases\\Raw\\Brittanica\\");

            jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

            btScanImportPathFileData.setText("Scan & Import Path File Data");
            btScanImportPathFileData.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    btScanImportPathFileDataActionPerformed(evt);
                }
            });

            jButton2.setText("EN Sentences Import");
            jButton2.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jButton2ActionPerformed(evt);
                }
            });

            jButton3.setText("Clear Empty File");
            jButton3.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jButton3ActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
            jPanel1.setLayout(jPanel1Layout);
            jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(btScanImportPathFileData, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );
            jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(btScanImportPathFileData)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jButton2)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jButton3)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );

            taOutput.setColumns(20);
            taOutput.setRows(5);
            jScrollPane1.setViewportView(taOutput);

            javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
            getContentPane().setLayout(layout);
            layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(tfPathFolderWorking, javax.swing.GroupLayout.DEFAULT_SIZE, 872, Short.MAX_VALUE))
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1))
                    .addContainerGap())
            );
            layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(tfPathFolderWorking, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 311, Short.MAX_VALUE)
                    .addContainerGap())
            );

            pack();
        }// </editor-fold>//GEN-END:initComponents

    private void btScanImportPathFileDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btScanImportPathFileDataActionPerformed
        String pathFolderWorking = tfPathFolderWorking.getText().trim();
        String[] tmpArr001 = pathFolderWorking.split("\\\\");
        String importFrom = tmpArr001[tmpArr001.length - 1];
        System.out.println("Import from: " + importFrom);
        List<String> listPathFile = UtilityFileFolder.getListPathFileInFolder(pathFolderWorking, ".txt", true);
        taOutput.setText(String.join("\n", listPathFile));
        insertDictionaryManagementImports(listPathFile, importFrom);
    }//GEN-LAST:event_btScanImportPathFileDataActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        List<String> listPathFileNotYetImportEnSentences = getListPathFileNotYetImportEnSentences();
        //UtilityList.print(listPathFileNotYetImportEnSentences);
        
        
        for (String pathFile : listPathFileNotYetImportEnSentences) {
            if (UtilityFileFolder.isExistsFile(pathFile)) {
                System.out.println("== " + pathFile);
                List<String> data = UtilityFileFolder.readRowTextFileToListString(pathFile);
                insertDictionaryEnSentencesTmp(data);
                updateStatusEnSentences(pathFile);
                //System.exit(0);
            } else {
                System.out.println("File don't exists: " + pathFile);
            }
        }
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        String pathFolderWorking = tfPathFolderWorking.getText().trim();
        String pathFolderEmpty = pathFolderWorking + "Empty\\";

        List<String> listPathFile = UtilityFileFolder.getListPathFileInFolder(pathFolderWorking, ".txt", true);

        for (String pathFile : listPathFile) {
            List<String> data = UtilityFileFolder.readRowTextFileToListString(pathFile);
            UtilityList.trimSpace(data);
            data.removeAll(Arrays.asList("", null));
            if (data.size() <= 2) {
                String pathFileMove = pathFolderEmpty + pathFile.split("\\\\")[pathFile.split("\\\\").length - 1];
                System.out.println("pathFile: " + pathFile);
                System.out.println("pathFile: " + pathFileMove);
                
                UtilityFileFolder.moveFile(pathFile, pathFileMove);
            }
        }
        
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Import.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Import.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Import.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Import.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Import().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btScanImportPathFileData;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea taOutput;
    private javax.swing.JTextField tfPathFolderWorking;
    // End of variables declaration//GEN-END:variables
}
